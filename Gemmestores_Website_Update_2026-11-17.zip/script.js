/* =========================================================
   GEMMESTORES — MAIN JAVASCRIPT
   Existing Supabase Auth, Phone Store, Wallet and Admin flows
   Enhanced catalogue, cart, reviews and product requests.
   ========================================================= */

'use strict';

// ---------------------------------------------------------
// SUPABASE
// ---------------------------------------------------------
const SUPABASE_URL = 'https://ozccbkoerwaqwgfhelzf.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_IufkeeVA3FaY-ST2qSwGng_by9wtLrK';

if (!window.supabase || typeof window.supabase.createClient !== 'function') {
  throw new Error('Supabase library did not load. Check the Supabase CDN script in index.html.');
}
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

let currentTrackingId = '';
let pendingService = null;
let phoneCart = [];
let currentPhoneCategory = 'phones';
let selectedAirtimeNetwork = '';
let confirmedAirtimeQuote = null;
let activeProductKey = '';
let activeProduct = null;
let lastLoadedOrders = [];
let verifiedElectricityMeter = null;

const sections = [
  'home', 'signup', 'login', 'dashboard', 'wallet', 'buy-data', 'buy-airtime',
  'bills', 'phones', 'checkout', 'tracking', 'settings', 'account'
];

const ORDER_STATUSES = ['Processing', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
const PROGRESS_STATUSES = ['Processing', 'Confirmed', 'Shipped', 'Delivered'];
const ADMIN_WHATSAPP_NUMBERS = ['2348170349252', '2347079210104'];
const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/0029Va7TxHNAzNbwXMfSoD0Q';

// ---------------------------------------------------------
// SMALL HELPERS
// ---------------------------------------------------------
function byId(id) { return document.getElementById(id); }

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

function normalizeText(value) {
  return String(value ?? '').trim().replace(/\s+/g, ' ');
}

function normalizeKey(value) {
  return normalizeText(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function formatMoney(value, decimals = 0) {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '₦0';
  return '₦' + amount.toLocaleString('en-NG', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  });
}

function parsePrice(value) {
  if (value === null || value === undefined || value === '') return null;
  const parsed = Number(String(value).replace(/[^\d.-]/g, ''));
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function setMessage(id, text, isError = false) {
  const element = byId(id);
  if (!element) return;
  element.textContent = text;
  element.classList.toggle('message-error', Boolean(isError));
  element.classList.toggle('message-success', Boolean(text) && !isError);
}

function safeOpen(url) {
  const win = window.open(url, '_blank', 'noopener,noreferrer');
  if (win) win.opener = null;
}

function getProductByKey(key) {
  return [...PHONE_PRODUCTS, ...LAPTOP_PRODUCTS, ...EARBUD_PRODUCTS, ...OTHER_ACCESSORIES]
    .find(product => product.key === key) || null;
}

async function getCurrentUser() {
  try {
    const { data, error } = await supabaseClient.auth.getSession();
    if (error) {
      console.error('Unable to get session:', error.message);
      return null;
    }
    return data?.session?.user || null;
  } catch (error) {
    console.error('Unable to get current user:', error);
    return null;
  }
}

// ---------------------------------------------------------
// CATALOGUE DATA — product variants, prices and specifications
// ---------------------------------------------------------
const PHONE_PRODUCTS = [];
function isTabletListing(brand, name) {
  const model = `${brand || ''} ${name || ''}`.trim();
  return /\b(?:m?pad(?:\s|$)|mega\s+pad|vista\s+tab|galaxy\s+tab)\b/i.test(model);
}

function addPhone(brand, name, variant, price, specs = '', options = {}) {
  const product = {
    key: options.key || normalizeKey(`${brand}-${name.replace(/\+/g, ' Plus')}-${variant}`),
    brand, name, variant, price: price == null ? null : Number(price), specs,
    colors: options.colors || '', image: options.image || '',
    category: options.category || (isTabletListing(brand, name) ? 'tablets' : 'phones'),
    priceNote: options.priceNote || '', pricingRule: options.pricingRule || '',
    modelCode: options.modelCode || '',
    pending: price == null
  };
  PHONE_PRODUCTS.push(product);
}

// JX — supplier price + ₦2,000. Do not duplicate the existing Note 14 Lite.
[
  ['17 Pro Max', '8GB / 128GB', 102000, '6.8-inch HD+ Incell; 32MP rear + 16MP front; 5000mAh; Android 14; 4G.'],
  ['Note 11', '4GB / 64GB', 79000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 11 Lite', '4GB / 32GB', 68000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 12', '4GB / 64GB', 80000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 13', '4GB / 64GB', 79000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 14', '4GB / 64GB', 80000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 14 Lite', '4GB / 32GB', 68000, '6.6-inch HD+ 720×1600; Unisoc SC7731E quad-core; 8MP rear; 5MP front; 5000mAh; Android 15; 3G; Face Unlock.', { colors: 'Blue, Gray' }],
  ['Note 15', '4GB / 64GB', 79000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Note 16', '4GB / 64GB', 79000, '6.6-inch HD+ Incell; 8MP AI rear; 5MP front; 5000mAh.'],
  ['Smart 6', '4GB / 64GB', 70000, 'White / Gold.']
].forEach(([name, variant, price, specs, opts]) => addPhone('JX', name, variant, price, specs, opts || {}));
addPhone('JX', 'Note 17 Lite', '4GB / 32GB', 102000, '6.6-inch HD+ display; 8MP rear camera; 5000mAh battery; face unlock. Orange, Dark Blue, Gold, Silver/White.', { colors: 'Orange, Dark Blue, Gold, Silver/White' });
addPhone('JX', 'Note 16 Lite', '4GB / 64GB', 120000, '6.6-inch display; 5000mAh battery; dual SIM 4G LTE; Android 14. Dark Blue / Gray.', { colors: 'Dark Blue, Gray' });
addPhone('JX', 'Note 15 Lite', '4GB / 32GB', 98000, '6.6-inch HD+ Incell; 5000mAh battery with Type-C fast charging; Android 14/15 depending on variant; face unlock; fingerprint scanner; dual SIM. Turquoise.', { colors: 'Turquoise' });
addPhone('JX', 'Note 15 Lite', '4GB / 64GB', 112000, '6.6-inch HD+ Incell; 5000mAh battery with Type-C fast charging; Android 14/15 depending on variant; face unlock; fingerprint scanner; dual SIM. Turquoise.', { colors: 'Turquoise' });

// M-HORSE — supplier price + ₦2,000. Only supplied specifications are listed.
[
  ['17 Pro', '4GB / 32GB', 70000, '6.6-inch display.'],
  ['17 Pro Max 4G', '8GB / 64GB', 98000, '6.6-inch display.'],
  ['17 Pro Max+', '12GB / 128GB', 105000, '6.6-inch display.'],
  ['17 Pro Max+ NFC', '12GB / 256GB', 127000, '6.6-inch display; NFC.'],
  ['A17', '4GB / 64GB', 79000, '6.8-inch display.'],
  ['A200', '4GB / 32GB', 70500, '6.8-inch HD+ Incell Waterdrop; 5MP front + 8MP rear AI; 5000mAh; dual speakers; Face ID; Android 15; Gray, Orange, Dark Blue.'],
  ['A56 Ultra', '8GB / 128GB', 98000, 'NFC; free TWS included.'],
  ['M16 Pro Max+ NFC', '12GB / 256GB', 130000, '6.6-inch display; NFC.'],
  ['MPad Mini', '12GB / 256GB', 107000, '8.8-inch tablet.'],
  ['Note 15 PRO', '8GB / 64GB', 87500, '6.8-inch display.'],
  ['Pad 17', '8GB / 64GB', 97000, '10.1-inch tablet; keyboard, mouse, stylus pen and clear case included; Orange.'],
  ['Pad 17 Pro', '12GB / 256GB', 107000, '10.1-inch tablet.'],
  ['S25 Ultra+', '8GB / 128GB', 100000, '6.6-inch display.'],
  ['S26 Ultra', '4GB / 64GB', 81000, '6.8-inch display.'],
  ['S26 Ultra 4G', '8GB / 64GB', 84000, '6.8-inch display.'],
  ['S26 Ultra+', '12GB / 128GB', 102000, '6.8-inch display.'],
  ['S26+', '4GB / 32GB', 70000, '6.8-inch display.']
].forEach(([name, variant, price, specs]) => addPhone('M-HORSE', name, variant, price, specs));
addPhone('M-HORSE', 'CAMON 50', '4GB / 32GB', 102000, '6.8-inch HD+ display; 5MP front + 8MP rear; 5000mAh battery.');
addPhone('M-HORSE', 'M18 Pro Max', '4GB / 64GB', 97000, '6.6-inch HD+ Incell Punch Hole; 5MP front + 8MP rear AI; Face ID; 5000mAh; Android 16; Light Blue / Purple; neckband earphone included.', { image: 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045672/IMG-20261007-WA0049.jpg', colors: 'Light Blue, Purple' });
addPhone('M-HORSE', 'CAMON 50+', '4GB / 64GB', 132000, '6.8-inch HD+ Incell 720×1600; 5MP front + 8MP rear; quad-core; 5000mAh; dual speakers; Android 15; 2G / 3G / 4G LTE; Orange, Green, Gray Titanium, Gray.', { colors: 'Orange, Green, Gray Titanium, Gray' });
addPhone('M-HORSE', 'SPARK 40', '4GB / 64GB', 112000, 'Side fingerprint; Gold, Dark Blue/Gray, Light Pink.', { colors: 'Gold, Dark Blue/Gray, Light Pink' });
addPhone('M-HORSE', 'Hot 30 Play+', '4GB / 64GB', 107000, '6.6-inch HD+ Incell waterdrop display; 5MP front + 8MP rear AI cameras; 5000mAh battery; side fingerprint sensor; Gray, Purple, Gold.', { colors: 'Gray, Purple, Gold', pricingRule: '', priceNote: '' });
addPhone('M-HORSE', 'M17 Pro Max', '8GB / 128GB', 107000, '6.8-inch HD+ display; octa-core processor; 8GB total RAM; 128GB internal storage; 5000mAh battery; free neckband gift.');
addPhone('M-HORSE', 'S22', '4GB / 64GB', 102000, '6.6-inch HD+ Incell/AMOLED display (720×1600); 5MP front camera; 8MP rear AI camera; 5000mAh battery; side-mounted fingerprint sensor; Face ID; Android 13/14 depending on batch.');
addPhone('M-HORSE', 'M16 Pro Max', '4GB / 64GB', 82000, '6.6-inch HD+ In-cell punch-hole LCD (720×1600); octa-core chipset; 4GB physical RAM; 64GB storage expandable via MicroSD; 13MP rear AI + 8MP front cameras; 5000mAh battery; dual SIM 4G VoLTE; Wi-Fi; Bluetooth; USB Type-C; Android 14; Face ID and side-mounted fingerprint sensor.');

// TECNO product listings
[
  ['POP 10C', '2GB / 64GB', 116638, 'BG6m'],
  ['POP 10', '3GB / 64GB', 121368, 'KM4'],
  ['POP 10', '3GB / 128GB', 132978, 'KM4'],
  ['POP 10 Pro', '4GB / 128GB', 144480, 'KM4K'],
  ['POP 20', '4GB / 64GB', 154700, 'KN3'],
  ['POP 20', '4GB / 128GB', 163500, 'KN3'],
  ['SPARK 50', '4GB / 128GB', 199500, 'KN4'],
  ['SPARK 50 Pro', '6GB / 128GB', 334800, 'KO5'],
  ['SPARK 40', '4GB / 128GB', 162755, 'KM5'],
  ['SPARK 40', '8GB / 256GB', 198445, 'KM5'],
  ['SPARK 40 Pro', '8GB / 128GB', 275630, 'KM6'],
  ['SPARK 40 Pro', '8GB / 256GB', 261978, 'KM6'],
  ['SPARK 40 Pro+', '8GB / 128GB', 283800, 'KM7'],
  ['SPARK 40 Pro+', '8GB / 256GB', 322285, 'KM7'],
  ['SPARK Slim', '8GB / 256GB', 354428, 'KM7k'],
  ['CAMON 50', '8GB / 128GB', 397643, 'CN5'],
  ['CAMON 50', '8GB / 256GB', 447523, 'CN5'],
  ['CAMON 50 Pro', '8GB / 256GB', 499230, 'CN5c'],
  ['CAMON 50 Ultra', '8GB / 512GB', 749920, 'CN7c'],
  ['PHANTOM V Flip 2', '8GB / 256GB', 1053285, 'AE11'],
  ['PHANTOM V Fold 2', '12GB / 512GB', 1799335, 'AE10'],
  ['MEGA PAD SE', '4GB / 128GB', 249615, 'T1102'],
  ['MEGA PAD SE', '8GB / 256GB', 285520, 'T1102'],
  ['MEGA PAD Pro', '8GB / 256GB', 344323, 'T1201']
].forEach(([name, variant, price, code]) => addPhone('TECNO', name, variant, price, `Model code: ${code}.`, { modelCode: code, pricingRule: '' }));

// HONOR product listings
[
  ['Choice T10', '4GB / 64GB', 133240], ['Choice T10', '3GB / 32GB', 114190],
  ['Play20C', '4GB / 64GB', 142760], ['X7c', '8GB / 256GB', 279180],
  ['X7d', '8GB / 256GB', 299900], ['X7e', '6GB / 128GB', 273480],
  ['X7e', '6GB / 256GB', 301780], ['X8c', '8GB / 512GB', 374750],
  ['X9c', '8GB / 256GB', 499900], ['X9c', '12GB / 256GB', 590710],
  ['X9d', '12GB / 256GB', 618000], ['600 Lite', '8GB / 128GB', 377260],
  ['600 Lite', '8GB / 256GB', 452740], ['600', '12GB / 256GB', 660260]
].forEach(([name, variant, price]) => addPhone('HONOR', name, variant, price, ''));

// INFINIX product listings
[
  ['SMART 20 HD', '3GB / 64GB', 152000], ['SMART 20', '3GB / 64GB', 152000],
  ['SMART 20', '4GB / 64GB', 160500], ['SMART 20', '4GB / 128GB', 179000],
  ['SMART 20E', '4GB / 64GB', 160500], ['HOT 70', '4GB / 128GB', 225000],
  ['HOT 70', '6GB / 256GB', 300000], ['HOT 70 Pro', '6GB / 128GB', 400000],
  ['HOT 70 Pro', '8GB / 256GB', 480000], ['NOTE 60 Pro', '', 590000],
  ['NOTE Edge', '8GB / 128GB', 440000], ['NOTE 60 Edge', '8GB / 256GB', 485000]
].forEach(([name, variant, price]) => addPhone('Infinix', name, variant, price, ''));

// itel product listings
[
  ['A06', '2GB / 32GB', 82000], ['A06', '2GB / 64GB', 99000], ['A50Cs', '2GB / 64GB', 102000],
  ['Power 80', '4GB / 128GB', 185000], ['A100cs', '2GB / 32GB', 100000], ['A100cs', '2GB / 64GB', 110000],
  ['A100c', '2GB / 64GB', 115000], ['A100c', '3GB / 64GB', 117000], ['A100c', '3GB / 128GB', 125000],
  ['A200+', '3GB / 128GB', 143000], ['A300C', '4GB / 64GB', 132000], ['A300+', '4GB / 64GB', 143500],
  ['A300+', '4GB / 128GB', 170000], ['A200+S', '3GB / 64GB', 125000], ['A200+S', '3GB / 128GB', 150000],
  ['City 200', '4GB / 128GB', 160000], ['City 200S', '4GB / 128GB', 170000], ['Vista Tab 30s', '3GB / 128GB', 230000]
].forEach(([name, variant, price]) => addPhone('itel', name, variant, price, ''));

// Redmi / Xiaomi product listings
[
  ['Redmi A7', '3GB / 64GB', 142000], ['Redmi A7 Pro', '4GB / 64GB', 158000], ['Redmi A7 Pro', '4GB / 128GB', 170000],
  ['Redmi 15C', '4GB / 128GB', 181000], ['Redmi 15C', '8GB / 256GB', 230000], ['Redmi 13', '8GB / 128GB', 185000],
  ['Redmi 15', '6GB / 128GB', 225000], ['Redmi 15', '8GB / 256GB', 270000],
  ['Redmi 17', '4GB / 128GB', 220000], ['Redmi 17', '6GB / 128GB', 270000], ['Redmi 17', '6GB / 256GB', 300000],
  ['Redmi Note 15 Pro', '8GB / 256GB', 450000], ['Redmi Note 15 Pro+', '256GB', 640000],
  ['Redmi Note 17', '6GB / 128GB', 380000], ['Redmi Note 17', '8GB / 256GB', 440000], ['Redmi Note 17 Pro', '8GB / 256GB', 570000]
].forEach(([name, variant, price]) => addPhone('Redmi', name, variant, price, ''));
const REDMI_NOTE_15_SPECS = 'MediaTek Helio G100-Ultra (6nm octa-core); 6.77-inch FHD+ AMOLED 120Hz, up to 3200 nits; 108MP main + 2MP depth rear cameras; 20MP front camera; 6000mAh battery; 33W Turbo Charging with 18W reverse wired charging; IP64 dust/water resistance; drop-resistant structural glass; Xiaomi HyperOS with Google Gemini AI; Dolby Atmos dual stereo speakers; MicroSD expansion up to 2TB.';
addPhone('Redmi', 'Redmi Note 15', '6GB / 128GB', 307000, REDMI_NOTE_15_SPECS);
addPhone('Redmi', 'Redmi Note 15', '8GB / 256GB', 352000, REDMI_NOTE_15_SPECS);
[
  ['Redmi 15C', '6GB / 128GB', 199300], ['Redmi 15C 5G', '4GB / 128GB', 187100],
  ['Redmi Note 17 Pro 5G', '8GB / 256GB', 559000], ['Redmi Note 17 Pro 5G', '8GB / 512GB', 639500],
  ['Redmi Note 17 Pro Max 5G', '8GB / 256GB', 699800], ['Redmi Note 17 Pro Max 5G', '8GB / 512GB', 766400],
  ['Xiaomi 15T', '12GB / 512GB', 769500], ['Xiaomi 14T', '12GB / 512GB', 745900],
  ['Xiaomi 17T', '12GB / 512GB', 870100], ['Xiaomi 17T Pro', '12GB / 1TB', 1234100]
].forEach(([name, variant, price]) => addPhone('Redmi / Xiaomi', name, variant, price, '', {}));

// Samsung phone listings; preserve W/O travel adapter variants.
[
  ['Galaxy Z Fold8 Ultra', '16GB / 1TB', 3437220], ['Galaxy Z Fold8 Ultra', '12GB / 512GB', 2925410], ['Galaxy Z Fold8 Ultra', '12GB / 256GB', 2669500],
  ['Galaxy Z Fold8', '16GB / 1TB', 3171720], ['Galaxy Z Fold8', '12GB / 512GB', 2659900], ['Galaxy Z Fold8', '12GB / 256GB', 2404000],
  ['Galaxy Z Fold7', '12GB / 256GB', 2042500, 'Promotional price'],
  ['Galaxy S26 Ultra', '16GB / 1TB · W/O travel adapter', 2489700], ['Galaxy S26 Ultra', '12GB / 512GB · W/O travel adapter', 2098400], ['Galaxy S26 Ultra', '12GB / 256GB · W/O travel adapter', 1837180],
  ['Galaxy S25 Ultra', '12GB / 512GB', 1316875],
  ['Galaxy S26+', '12GB / 512GB · W/O travel adapter', 1816750], ['Galaxy S26+', '12GB / 256GB · W/O travel adapter', 1557680],
  ['Galaxy S26', '12GB / 256GB · W/O travel adapter', 1321180], ['Galaxy S26 FE', '8GB / 128GB', 892250],
  ['Galaxy A57 5G', '8GB / 256GB', 707350], ['Galaxy A57 5G', '8GB / 128GB', 623500],
  ['Galaxy A37 5G', '8GB / 256GB', 637480], ['Galaxy A37 5G', '6GB / 128GB', 504180],
  ['Galaxy A27 5G', '8GB / 256GB', 557490], ['Galaxy A27 5G', '6GB / 128GB', 413880],
  ['Galaxy A18 LTE', '8GB / 256GB', 506670], ['Galaxy A18 LTE', '6GB / 128GB', 364010], ['Galaxy A18 LTE', '4GB / 128GB', 316520],
  ['Galaxy A17 5G', '4GB / 128GB', 330570], ['Galaxy A17 LTE', '8GB / 256GB', 470190], ['Galaxy A17 LTE', '6GB / 128GB', 327570], ['Galaxy A17 LTE', '4GB / 128GB', 280100],
  ['Galaxy A08', '4GB / 128GB', 275220], ['Galaxy A08', '4GB / 64GB', 228330],
  ['Galaxy A07s', '4GB / 128GB', 250210], ['Galaxy A07s', '4GB / 64GB', 203440]
].forEach(row => {
  const [name, variant, price, priceNote] = row;
  addPhone('Samsung', name, variant, price, '', { priceNote: '', pricingRule: '' });
});

// Samsung tablet listings. Keep one 12GB/512GB Tab S12 Ultra card until the conflicting source value is resolved.
[
  ['Galaxy Tab S12 Ultra 5G', '12GB / 512GB', 2320930],
  ['Galaxy Tab S12+ 5G', '12GB / 512GB', 2051100], ['Galaxy Tab S12+ 5G', '12GB / 256GB', 1780200],
  ['Galaxy Tab A11+ 5G', '8GB / 256GB', 503100], ['Galaxy Tab A11+ 5G', '6GB / 128GB', 417100],
  ['Galaxy Tab A11 LTE', '8GB / 128GB', 288100], ['Galaxy Tab A11 LTE', '4GB / 64GB', 212850]
] .forEach(([name, variant, price, note]) => addPhone('Samsung', name, variant, price, `${note || ''}`, {}));

const LAPTOP_PRODUCTS = [
  { key: 'laptop-hp-15-i3-10th-8-256', brand: 'HP', name: 'HP 15', variant: 'Intel Core i3 10th Gen · 8GB RAM / 256GB SSD', price: 240000, specs: '', image: 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046809/IMG-20261014-WA0027.jpg', category: 'laptops', pending: false },
  { key: 'laptop-hp-touchscreen-x360-4-128', brand: 'HP', name: 'HP Intel Touchscreen x360', variant: '4GB RAM / 128GB SSD', price: 150000, specs: 'Touchscreen; 360° convertible design. Processor generation not supplied.', image: 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046810/IMG-20261014-WA0026.jpg', category: 'laptops', pending: false },
  { key: 'laptop-hp-elitebook-840-g6', brand: 'HP', name: 'HP EliteBook 840 G6', variant: 'Intel Core i5 8th Gen · 8GB RAM / 256GB SSD', price: 340000, specs: 'Backlit keyboard; fingerprint reader.', image: 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046790/IMG-20261014-WA0003.jpg', category: 'laptops', pending: false },
];

// ---------------------------------------------------------
// ACCESSORIES — exact supplied catalogue prices and image URLs
// ---------------------------------------------------------
const EARBUD_PRODUCTS = [
  ['OWS101','JX OWS101 Earbuds','',null,'Open-ear hook design; 400mAh charging case; approximately 4.5 hours playback; Bluetooth 6.0; IPX4.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046208/IMG-20261012-WA0099.jpg'],
  ['OWS102','JX OWS102 Earbuds','',7300,'Silver/white open-ear design; 400mAh case; approximately 4.5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046211/IMG-20261012-WA0094.jpg'],
  ['OWS103','JX OWS103 Earbuds','',7800,'Open-ear hook design; 400mAh case; approximately 4.5 hours playback; Bluetooth 6.0.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046209/IMG-20261012-WA0097.jpg'],
  ['OWS104','JX OWS104 Earbuds','',7800,'Silver open-ear design; 400mAh case; approximately 4.5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046201/IMG-20261013-WA0004.jpg'],
  ['WOS105','JX WOS105 Earbuds','',8000,'Wireless earbuds with digital display charging case; 360mAh battery; approximately 5.5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046227/IMG-20261012-WA0079.jpg'],
  ['OWS201','JX OWS201 Earbuds','',6900,'White/black open-ear design; 350mAh case; approximately 5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046217/IMG-20261012-WA0090.jpg'],
  ['OWS202','JX OWS202 Earbuds','',10400,'Open-ear design with accent details; 400mAh case; approximately 7.5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046213/IMG-20261012-WA0092.jpg'],
  ['OWS204','JX OWS204 Earbuds','',7600,'Black/grey open-ear design; 400mAh case; approximately 7 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046217/IMG-20261012-WA0088.jpg'],
  ['TWS04','JX TWS04 Earbuds','',null,'White wireless earbuds; 300mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046219/IMG-20261012-WA0086.jpg'],
  ['TWS05','JX TWS05 Earbuds','',5100,'AirPods-style design; 300mAh case; approximately 4 hours playback; Bluetooth 6.0.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046210/IMG-20261012-WA0096.jpg'],
  ['TWS06','JX TWS06 Earbuds','',null,'White wireless earbuds; 300mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046222/IMG-20261012-WA0084.jpg'],
  ['TWS08','JX TWS08 Earbuds','',5000,'Panda-white design; 300mAh case; approximately 5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046202/IMG-20261012-WA0100.jpg'],
  ['TWS21','JX TWS21 Earbuds','',5000,'Orange design; 400mAh case; approximately 4.2 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046217/IMG-20261012-WA0089.jpg'],
  ['TWS22','JX TWS22 Earbuds','',5100,'Stem-style design; 400mAh case; approximately 4.2 hours playback; multiple colours; Bluetooth 6.0.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046209/IMG-20261012-WA0098.jpg'],
  ['TWS23','JX TWS23 Earbuds','',5500,'Black in-ear design; 250mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046216/IMG-20261012-WA0091.jpg'],
  ['TWS24','JX TWS24 Earbuds','',5600,'In-ear design; 250mAh case; approximately 4 hours playback; Bluetooth 6.0.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046202/IMG-20261012-WA0101.jpg'],
  ['TWS25','JX TWS25 Earbuds','',5800,'Pink wireless earbuds; 250mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046218/IMG-20261012-WA0087.jpg'],
  ['TWS26','JX TWS26 Earbuds','',6200,'White in-ear design; 300mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046211/IMG-20261012-WA0095.jpg'],
  ['TWS26PRO','JX TWS26 PRO Earbuds','',8900,'Screen charging case; 400mAh battery; approximately 5 hours playback; noise reduction.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046222/IMG-20261012-WA0083.jpg'],
  ['TWS27','JX TWS27 Earbuds','',5500,'In-ear design; 250mAh case; approximately 3.5 hours playback; Bluetooth 6.0; IPX4.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046202/IMG-20261013-WA0003.jpg'],
  ['TWS28ANC','JX TWS28 ANC Earbuds','',7500,'Active Noise Cancellation (ANC); 400mAh case; approximately 5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046223/IMG-20261012-WA0082.jpg'],
  ['TWS29','JX TWS29 Earbuds','',5500,'Black wireless earbuds; 300mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046224/IMG-20261012-WA0081.jpg'],
  ['TWS30','JX TWS30 Earbuds','',5500,'White entry-level wireless earbuds; approximately 2.5 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046226/IMG-20261012-WA0080.jpg'],
  ['TWS32ANC','JX TWS32 ANC Earbuds','',6600,'Black wireless earbuds with ANC; 300mAh case; approximately 6 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046229/IMG-20261012-WA0077.jpg'],
  ['TWS35','JX TWS35 Earbuds','',5000,'Peach-coloured wireless earbuds; 300mAh case; approximately 4.2 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046230/IMG-20261012-WA0076.jpg'],
  ['TWS100','JX TWS100 Earbuds','',8100,'Silver/grey wireless earbuds; 250mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046212/IMG-20261012-WA0093.jpg'],
  ['TWS200','JX TWS200 Earbuds','',8100,'Black/grey wireless earbuds; approximately 5 hours playback; Bluetooth 6.0.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046221/IMG-20261012-WA0085.jpg'],
  ['TWS300','JX TWS300 Earbuds','',9500,'Wireless earbuds with white charging case; 250mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046229/IMG-20261012-WA0078.jpg'],
  ['TWS400','JX TWS400 Earbuds','',10100,'Ribbed white/grey design; 250mAh case; approximately 4 hours playback.','https://res.cloudinary.com/j3rveiep/image/upload/v1793046230/IMG-20261012-WA0075.jpg']
].map(([code,name,variant,price,specs,image]) => ({ key:`earbud-${code.toLowerCase()}`, brand:'JX', name, variant, price, specs, image, category:'accessories', modelCode:code }));

const OTHER_ACCESSORIES = [
  {key:'jx-12usb-cable',brand:'JX',name:'JX 12USB Cable',variant:'USB-A to Type-C',price:4500,specs:'USB-A to Type-C charging cable. 2A charging output.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793372243/IMG_20261030_155420.jpg',category:'accessories'},
  {key:'jx-pd-20w-cable',brand:'JX',name:'JX PD 20W USB-C to USB-C Cable',variant:'20W PD',price:4500,specs:'USB-C to USB-C connector. Supports up to 20W PD charging.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793372243/IMG_20261030_155552.jpg',category:'accessories'},
  {key:'samsung-usbc-cable',brand:'Samsung',name:'Samsung USB-C Cable',variant:'USB-C',price:5000,specs:'USB-C charging cable for compatible Samsung devices.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793372244/IMG-20261023-WA0111.jpg',category:'accessories'},
  {key:'samsung-25w-adapter',brand:'Samsung',name:'Samsung 25W PD Power Adapter',variant:'25W',price:20430,specs:'25W power output. Adapter for compatible USB-C devices with supported fast charging.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046200/199476_1746558410.jpg',category:'accessories'},
  {key:'samsung-45w-adapter',brand:'Samsung',name:'Samsung 45W Power Adapter',variant:'45W',price:37630,specs:'45W power output. Low Standby Power Adapter for compatible Samsung devices.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046201/IMG-20261023-WA0103.jpg',category:'accessories'},
  {key:'samsung-15w-adapter',brand:'Samsung',name:'Samsung 15W PD Power Adapter',variant:'15W',price:14500,specs:'15W power output. Power adapter for compatible charging devices.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046200/s-l1600.webp',category:'accessories'},
  {key:'samsung-60w-adapter',brand:'Samsung',name:'Samsung 60W Power Adapter',variant:'60W',price:50000,specs:'60W power output. Power adapter for compatible USB-C charging devices.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046200/s-l1600_1.webp',category:'accessories'},
  {key:'galaxy-watch-charger',brand:'Samsung',name:'Galaxy Watch Fast Wireless Charger',variant:'USB-C',price:11000,specs:'Magnetic wireless charging design with USB-C connection for compatible Galaxy Watch models.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046201/IMG-20261023-WA0101.jpg',category:'accessories'},
  {key:'tab12-keyboard',brand:'Samsung',name:'Samsung Galaxy TAB12+ KBD SLIM US TYPE',variant:'US keyboard layout',price:143000,specs:'Slim keyboard accessory for compatible Galaxy Tab devices. US keyboard layout.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793374410/IMG-20261026-WA3533.jpg',category:'accessories'},
  {key:'tab-s12-ultra-keyboard',brand:'Samsung',name:'Samsung Galaxy Tab S12 Ultra KBD SLIM US',variant:'US keyboard layout',price:179000,specs:'Slim keyboard accessory with US keyboard layout for the compatible Galaxy Tab model.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793374410/IMG-20261026-WA0250.jpg',category:'accessories'},
  {key:'watch9-40mm',brand:'Samsung',name:'Watch 9 40mm BT',variant:'40mm Bluetooth',price:430000,specs:'Bluetooth smartwatch with a compact 40mm size.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046235/IMG-20261026-WA8753.jpg',category:'accessories'},
  {key:'watch9-44mm',brand:'Samsung',name:'Watch 9 44mm BT',variant:'44mm Bluetooth',price:466000,specs:'Bluetooth smartwatch with a larger 44mm size and bigger display.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046234/IMG-20261026-WA9760.jpg',category:'accessories'},
  {key:'galaxy-buds4-pro',brand:'Samsung',name:'Galaxy Buds 4 Pro',variant:'Wireless earbuds',price:260000,specs:'Samsung wireless Bluetooth earbuds for compatible devices.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046234/11438007iA7E3B1B00C1EDB90.png',category:'accessories'},
  {key:'ff8-carbon-magnet-case',brand:'FF8 Series',name:'FF8 Carbon Magnet Case',variant:'Magnetic case',price:82000,specs:'Carbon-style finish, built-in magnetic ring and protective phone case design.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046235/IMG-20261026-WA8111.jpg',category:'accessories'},
  {key:'ff8-carbon-standing-case',brand:'FF8 Series',name:'FF8 Carbon Standing Magnet Case',variant:'Magnetic case with kickstand',price:82000,specs:'Carbon-style finish, magnetic ring and built-in kickstand for hands-free viewing.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046236/IMG-20261026-WA1520.jpg',category:'accessories'},
  {key:'ff8-silicon-magnet-case',brand:'FF8 Series',name:'FF8 Silicon Magnet Case',variant:'Magnetic case',price:65000,specs:'Silicone-style protective case with a built-in magnetic ring.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793376257/IMG-20261030-WA6155.jpg',category:'accessories'},
  {key:'ff8-clear-magnet-case',brand:'FF8 Series',name:'FF8 Clear Magnet Case',variant:'Magnetic case',price:43000,specs:'Transparent protective case with a built-in magnetic ring.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046237/IMG-20261026-WA5271.jpg',category:'accessories'},
  {key:'ff8-clear-case',brand:'FF8 Series',name:'FF8 Clear Case',variant:'Non-magnetic case',price:35000,specs:'Lightweight transparent protective phone case. Non-magnetic design.',image:'https://res.cloudinary.com/j3rveiep/image/upload/v1793046237/IMG-20261026-WA9096.jpg',category:'accessories'}
];

// iPHONES — use the user's Product_Catalogue.pdf page 40 price table.
// The catalogue specifies base amount x 214. Prices below are the exact NGN
// results from that table. Each storage option is a separate selectable listing.
const IPHONE_REFERENCE_SPECS = {
  'iPhone 11': '6.1-inch Liquid Retina HD LCD; A13 Bionic; dual 12MP rear cameras; 12MP TrueDepth front camera; Face ID; Lightning.',
  'iPhone 11 Pro': '5.8-inch Super Retina XDR OLED; A13 Bionic; triple 12MP rear cameras; 12MP TrueDepth front camera; Face ID; Lightning.',
  'iPhone 11 Pro Max': '6.5-inch Super Retina XDR OLED; A13 Bionic; triple 12MP rear cameras; 12MP TrueDepth front camera; Face ID; Lightning.',
  'iPhone 12': '6.1-inch Super Retina XDR OLED; A14 Bionic; dual 12MP rear cameras; 12MP TrueDepth front camera; Face ID; 5G; Lightning.',
  'iPhone 12 Pro': '6.1-inch Super Retina XDR OLED; A14 Bionic; triple 12MP Pro cameras with LiDAR; Face ID; 5G; Lightning.',
  'iPhone 12 Pro Max': '6.7-inch Super Retina XDR OLED; A14 Bionic; triple 12MP Pro cameras with LiDAR; Face ID; 5G; Lightning.',
  'iPhone 13': '6.1-inch Super Retina XDR OLED; A15 Bionic; dual 12MP rear cameras; Face ID; 5G; Lightning.',
  'iPhone 13 Pro': '6.1-inch Super Retina XDR OLED with ProMotion; A15 Bionic; triple 12MP Pro cameras; Face ID; 5G; Lightning.',
  'iPhone 13 Pro Max': '6.7-inch Super Retina XDR OLED with ProMotion; A15 Bionic; triple 12MP Pro cameras; Face ID; 5G; Lightning.',
  'iPhone 14': '6.1-inch Super Retina XDR OLED; A15 Bionic; dual 12MP rear cameras; Face ID; 5G; Lightning.',
  'iPhone 14 Pro': '6.1-inch Super Retina XDR OLED with Always-On and Dynamic Island; A16 Bionic; 48MP main triple-camera system; Face ID; 5G; Lightning.',
  'iPhone 14 Pro Max': '6.7-inch Super Retina XDR OLED with Always-On and Dynamic Island; A16 Bionic; 48MP main triple-camera system; Face ID; 5G; Lightning.',
  'iPhone 15': '6.1-inch Super Retina XDR OLED with Dynamic Island; A16 Bionic; 48MP main dual-camera system; USB-C; Face ID; 5G.',
  'iPhone 15 Pro': '6.1-inch Super Retina XDR OLED with ProMotion and Always-On; A17 Pro; titanium design; 48MP Pro camera system; USB-C; 5G.',
  'iPhone 15 Pro Max': '6.7-inch Super Retina XDR OLED with ProMotion and Always-On; A17 Pro; titanium design; 48MP Pro camera system; USB-C; 5G.',
  'iPhone 16': '6.1-inch Super Retina XDR OLED with Dynamic Island; A18; 48MP Fusion dual-camera system; Camera Control; USB-C; Face ID; 5G.',
  'iPhone 16 Pro': '6.3-inch Super Retina XDR OLED with ProMotion; A18 Pro; 48MP Pro camera system; titanium design; USB-C; 5G.',
  'iPhone 16 Pro Max': '6.9-inch Super Retina XDR OLED with ProMotion; A18 Pro; 48MP Pro camera system; titanium design; USB-C; 5G.'
};

[
  ['iPhone 11', '64GB', 246100], ['iPhone 11', '128GB', 256800],
  ['iPhone 11 Pro', '64GB', 284620], ['iPhone 11 Pro', '256GB', 310300],
  ['iPhone 11 Pro Max', '64GB', 310300], ['iPhone 11 Pro Max', '256GB', 331700],
  ['iPhone 12', '64GB', 256800], ['iPhone 12', '256GB', 269640],
  ['iPhone 12 Pro', '128GB', 353100], ['iPhone 12 Pro', '256GB', 370220],
  ['iPhone 12 Pro Max', '128GB', 395900], ['iPhone 12 Pro Max', '256GB', 413020],
  ['iPhone 13', '128GB', 363800], ['iPhone 13', '256GB', 380920],
  ['iPhone 13 Pro', '128GB', 481500], ['iPhone 13 Pro', '256GB', 513600],
  ['iPhone 13 Pro Max', '128GB', 545700], ['iPhone 13 Pro Max', '256GB', 599200],
  ['iPhone 14', '128GB', 423720], ['iPhone 14', '256GB', 460100],
  ['iPhone 14 Pro', '128GB', 567100], ['iPhone 14 Pro', '256GB', 599200],
  ['iPhone 14 Pro Max', '128GB', 642000], ['iPhone 14 Pro Max', '256GB', 684800],
  ['iPhone 15', '128GB', 567100], ['iPhone 15', '256GB', 642000],
  ['iPhone 15 Pro', '128GB', 727600], ['iPhone 15 Pro', '256GB', 770400],
  ['iPhone 15 Pro Max', '256GB', 873120], ['iPhone 15 Pro Max', '512GB', 920200],
  ['iPhone 16', '128GB', 716900], ['iPhone 16', '256GB', 898800],
  ['iPhone 16 Pro', '128GB', 1005800], ['iPhone 16 Pro', '256GB', 1102100],
  ['iPhone 16 Pro Max', '256GB', 1219800], ['iPhone 16 Pro Max', '512GB', 1326800]
].forEach(([name, variant, price]) => addPhone(
  'Apple', name, variant, price, IPHONE_REFERENCE_SPECS[name],
  { pricingRule: '' }
));

// ---------------------------------------------------------
// PRODUCT IMAGES — user-supplied Cloudinary catalogue links
// Only exact model matches are assigned. Models that are not
// present in this catalogue are intentionally not invented.
// ---------------------------------------------------------
const PRODUCT_IMAGE_ASSIGNMENTS = [
  // JX phones
  ['JX', 'Note 11', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045700/JX-product-note11.webp'],
  ['JX', 'Note 12', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/2.jpg.jpg'],
  ['JX', 'Note 13', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/note13-02.webp'],
  ['JX', 'Note 14 Lite', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/1_note14-lite-06.webp'],
  ['JX', 'Note 15', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/note-15-02.webp'],
  ['JX', 'Note 16', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/note16-07.webp'],
  ['JX', 'Smart 6', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045694/IMG-20261012-WA0036.jpg'],
  ['JX', 'Note 17 Lite', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793042966/786775.jpg'],

  // M-HORSE phones and tablets
  ['M-HORSE', 'A17', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045701/8df4009fa891426199737d1e550a02b5.jpg'],
  ['M-HORSE', '17 Pro Max+ NFC', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045700/sg-11134201-81zwn-miwz8gjqls79b5.jpg'],
  ['M-HORSE', 'MPad Mini', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046630/IMG-20261012-WA0037.jpg'],
  ['M-HORSE', 'Pad 17', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046632/IMG-20261025-WA2407.jpg'],
  ['M-HORSE', 'Pad 17 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/c_pad,ar_1:1,b_white,w_800/v1793046630/IMG-20261007-WA0054.jpg'],
  ['M-HORSE', '40 SPARK', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045674/IMG-20261007-WA0051.jpg'],

  // TECNO phones
  ['TECNO', 'POP 10C', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045610/IMG_300b0453-6c56-4976-a987-3085903ca4cb.webp'],
  ['TECNO', 'POP 10', 'https://d13pvy8xd75yde.cloudfront.net/global/phones/pop-10/pop10%20%E7%BB%BF.png'],
  ['TECNO', 'POP 10 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045608/IMG_3565f3af-bd2e-4a9c-aa37-60e0725280b3.png'],
  ['TECNO', 'POP 20', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045623/IMG_7d0d65e2-0d52-4098-9400-3235fac29b41.jpg'],
  ['TECNO', 'SPARK 50 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045616/IMG_efabfc9d-6713-49ec-9d73-73e7bdd18688.jpg'],
  ['TECNO', 'SPARK 40', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045616/IMG_042406c3-3c2e-4124-a111-d198bbb935dc.jpg'],
  ['TECNO', 'SPARK 40 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045615/IMG_a9c7a310-084b-42f5-a339-3a1e25d5ec6f.jpg'],
  ['TECNO', 'SPARK 40 Pro+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045615/IMG_a8f952b7-e041-4ce7-8cb0-deedd7e510f3.jpg'],
  ['TECNO', 'SPARK Slim', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045615/IMG_162ca9fb-ff92-47f4-a712-4898770909cd.jpg'],
  ['TECNO', 'CAMON 50', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045615/IMG_badcc003-e6a7-4765-986e-e3783554591b.webp'],
  ['TECNO', 'CAMON 50 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045614/IMG_06714b6b-248f-4fec-975d-d7ba1c8bbe5c.jpg'],
  ['TECNO', 'CAMON 50 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045611/IMG_bbd13063-7ea2-4020-a974-35987062e7b4.jpg'],
  ['TECNO', 'PHANTOM V Flip 2', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045606/IMG_3d8d1584-e06b-4a1f-94a3-1af515da925f.jpg'],
  ['TECNO', 'PHANTOM V Fold 2', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045606/IMG_bbe10645-f861-4d7e-80b4-5a229651ee6d.jpg'],

  // HONOR phones and tablet
  ['HONOR', 'Play20C', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793047277/36991379d9a18dac6cfa22b4cd1fae32_edit_2617171481436071.png'],
  ['HONOR', 'Choice T10', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045600/OIP.NArQOzjLylBRGjf9iDUOAgHaEM.webp'],
  ['HONOR', 'X7c', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045601/honorx7c3.jpg'],
  ['HONOR', 'X7d', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045600/OIP.c2xmQnzWLfZPjTrH-ZoPaQHaEK.webp'],
  ['HONOR', 'X7e', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045674/IMG-20261007-WA0047.jpg'],
  ['HONOR', 'X8c', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045599/OIP.AQqKr8RFyR-TSBJ2VeE9nAHaE9.webp'],
  ['HONOR', 'X9c', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045599/71I8daDcZML._AC_SL1500_.jpg'],
  ['HONOR', 'X9d', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045599/Honor-X9d-Banner.jpg'],
  ['HONOR', '600 Lite', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045595/Honor-600-Lite-img.jpg'],

  // Infinix phones
  ['Infinix', 'SMART 20', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045624/IMG_35badcd9-6f50-472e-94b9-b985d9d44b0b.jpg'],
  ['Infinix', 'SMART 20E', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045629/FB_IMG_1793022292584.jpg'],
  ['TECNO', 'SPARK 50', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045624/IMG_6af3f951-57a0-44ee-8197-5b3fef0f9c48.jpg'],
  ['Infinix', 'HOT 70 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045624/IMG_12ff9b96-b66c-4560-8255-c04f184b55c8.jpg'],
  ['Infinix', 'NOTE 60 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045624/IMG_0e68121a-e53e-461f-9062-b7d360a4e645.jpg'],
  ['Infinix', 'NOTE Edge', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045623/IMG_579ad626-80ab-4bd2-a8d4-11af5a74c320.jpg'],

  // itel phones
  ['itel', 'A06', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045656/Screenshot_2024-11-28_at_14.20.39-800x800.png'],
  ['itel', 'A50Cs', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045653/ph-11134207-820ld-mp0ix0hso8az3c.jpg'],
  ['itel', 'Power 80', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045652/1000786628.webp'],
  ['itel', 'A100c', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045651/19495500_img20250825wa0002_jpeg20f343aeb7dc2fd13b77168d5a87c3d9.jpg'],
  ['itel', 'A100cs', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045646/id-11110105-6vff4-mowjtp5qx72984_cover.jpg'],
  ['itel', 'A200+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045646/rsz_a200-_kv_21_large.jpg'],
  ['itel', 'A300C', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045645/IMG-20261026-WA4487.jpg'],
  ['itel', 'A300+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045645/IMG-20261026-WA0718.jpg'],
  ['itel', 'City 200', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045643/1000411652-816x1024.webp'],
  ['itel', 'City 200S', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045643/itel-CITY-200s-1.webp'],

  // Redmi and Xiaomi phones
  ['Redmi', 'Redmi A7', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045684/IMG-20261012-WA0053.jpg'],
  ['Redmi', 'Redmi A7 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045669/Redmi-A7-Pro-Colors-1200x1500.webp'],
  ['Redmi', 'Redmi 15C', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045670/red-5-1024x1024.jpg'],
  ['Redmi', 'Redmi 15', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045684/IMG-20261012-WA0051.jpg'],
  ['Redmi', 'Redmi 17', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045683/IMG-20261012-WA0049.jpg'],
  ['Redmi', 'Redmi Note 15 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045670/REDMI-NOTE-15-Pro-4G-TAG.jpg'],
  ['Redmi', 'Redmi Note 17', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045654/Redmi-Note-17-A.jpg'],
  ['Redmi', 'Redmi Note 17 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045655/OIP.Z9fBc_qJTZrVbivODEAcLAAAAA.webp'],
  ['Redmi', 'Redmi Note 17 Pro 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793996224/e62790bfad91e6bb19ba762ebacead09.webp'],
  ['Redmi / Xiaomi', 'Redmi Note 17 Pro Max 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045688/IMG-20261012-WA0057.jpg'],
  ['Redmi / Xiaomi', 'Xiaomi 15T', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045659/OIP.JMSUcxMPz4ZYlI0roGGELgHaHa.webp'],
  ['Redmi / Xiaomi', 'Xiaomi 14T', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045659/xiaomi-14t-renders.jpg'],
  ['Redmi / Xiaomi', 'Xiaomi 17T', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045656/Xiaomi-17T-colors-leak-cn.webp'],
  ['Redmi / Xiaomi', 'Xiaomi 17T Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045655/Xiaomi-17T-Pro-colors-leak-cn.webp'],

  // Samsung phones and tablets
  ['Samsung', 'Galaxy Z Fold7', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793053537/Samsung-Galaxy-Z-Fold-7-Renders-Leak.jpg'],
  ['Samsung', 'Galaxy Z Fold8', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045630/maxresdefault-1-1024x576.jpg'],
  ['Samsung', 'Galaxy S26 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045701/Hd14ff0bbbe314a9f9019c4bc2749fbcae.jpg_960x960q80.jpg'],
  ['Samsung', 'Galaxy S25 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045630/Exciting-Leak-Reveals-Samsung-Galaxy-S25-Faster-Speeds-and-Advanced-Tech-in-Store-for-2025-1140x641.jpg'],
  ['Samsung', 'Galaxy S26 FE', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045631/IMG-20261026-WA9614.jpg'],
  ['Samsung', 'Galaxy A57 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045639/_20260331083653_448.jpg'],
  ['Samsung', 'Galaxy A37 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045642/OIP.aohVx9ONX-TF7odNt1HIfgHaHa.webp'],
  ['Samsung', 'Galaxy A27 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045642/OIP.eRQ_lwHb_-YeXFONe-sDSAAAAA.webp'],
  // Samsung A17 LTE and A17 5G are separate models. The supplied generic A17 photo
  // does not identify which version it depicts, so neither gets a guessed image.
  ['Samsung', 'Galaxy A08', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045638/oar2.jpg'],
  // The uploaded Samsung photo is labelled A07, while the catalogue entry is A07s.
  // Keep A07s unpictured until an exact A07s image is confirmed.
  ['Samsung', 'Galaxy Tab S12 Ultra 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046636/IMG-20261026-WA0519.jpg'],
  ['Samsung', 'Galaxy Tab S12+ 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046633/IMG-20261026-WA5904.jpg'],
  ['Samsung', 'Galaxy Tab A11+ 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793046632/_20251117110916_295.jpg'],

  // Apple iPhones — user-supplied images
  ['Apple', 'iPhone 11', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045606/IMG_b28f0026-1dc9-44b9-b07a-627b72d114f2.jpg'],
  ['Apple', 'iPhone 11 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045604/OIP._i38DZMzH4cmQZwiIHALDwHaIK.webp'],
  ['Apple', 'iPhone 11 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045605/gsmarena_009.jpg'],
  ['Apple', 'iPhone 12', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045594/IMG-20261026-WA0115_1.jpg'],
  ['Apple', 'iPhone 12 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045587/IMG-20261026-WA0118_1.jpg'],
  ['Apple', 'iPhone 12 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045586/IMG-20261026-WA0126_1.jpg'],
  ['Apple', 'iPhone 13', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045594/IMG-20261026-WA0114_1.jpg'],
  ['Apple', 'iPhone 13 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045593/IMG-20261026-WA0119_1__edit_2599278132581389.jpg'],
  ['Apple', 'iPhone 13 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045586/IMG-20261026-WA0128_1.jpg'],
  ['Apple', 'iPhone 14', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045585/IMG-20261026-WA0130_1.jpg'],
  ['Apple', 'iPhone 14 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045586/IMG-20261026-WA0122.jpg'],
  ['Apple', 'iPhone 14 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045585/IMG-20261026-WA0131_1.jpg'],
  ['Apple', 'iPhone 15', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045586/IMG-20261026-WA0127_1.jpg'],
  ['Apple', 'iPhone 15 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045594/IMG-20261026-WA0116_1__edit_2599216285928078.jpg'],
  ['Apple', 'iPhone 16', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045586/IMG-20261026-WA0121.jpg'],
  ['Apple', 'iPhone 16 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045585/IMG-20261026-WA0129_1.jpg'],
  ['Apple', 'iPhone 16 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045593/IMG-20261026-WA0113_1.jpg'],
  ['M-HORSE', 'Hot 30 Play+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793043386/IMG-20261012-WA0033.jpg'],

  // Newly supplied user images — exact model assignments.
  ['JX', '17 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793973853/260111140003_61cbfd6d4f3a73dc32935e55169df812.png'],
  ['JX', 'Note 11 Lite', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793973852/1_note11-lite-02.webp'],
  ['JX', 'Note 14', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793974046/note-14-06.webp'],

  ['M-HORSE', 'A56 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045689/IMG-20261012-WA0030.jpg'],
  ['M-HORSE', 'M17 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992406/OIP.LrlgJo_-yXV3NeXCpymDHAHaKs.webp'],
  ['M-HORSE', '17 Pro Max 4G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992408/174669640131b96c.jpg'],
  ['M-HORSE', '17 Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992408/ebb69f64d62f0ee_1.png'],
  ['M-HORSE', '17 Pro Max+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992406/OIP.webp'],
  ['M-HORSE', 'S22', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045695/IMG-20261012-WA0040.jpg'],
  ['M-HORSE', 'S26 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992407/3.jpg.jpg'],
  ['M-HORSE', 'S26 Ultra 4G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992407/3.jpg.jpg'],
  ['M-HORSE', 'S26 Ultra+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992407/OIP.zO0LuDGlKHKxLGuZvbMBgAAAAA.webp'],
  ['M-HORSE', 'S26+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992404/1.jpg_1.jpg'],
  ['M-HORSE', 'Note 15 PRO', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992404/OIP.7O7ddRKnMAbt6Ahv5_AfIAAAAA.webp'],
  ['M-HORSE', 'M16 Pro Max+ NFC', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992406/1746695910a2b248.jpg'],

  ['TECNO', 'MEGA PAD Pro', 'https://res.cloudinary.com/j3rveiep/image/upload/c_pad,ar_1:1,b_white,w_800,h_800/v1793992408/TECNO-MEGAPAD-Pro-1024x443.jpg'],
  ['TECNO', 'MEGA PAD SE', 'https://res.cloudinary.com/j3rveiep/image/upload/c_pad,ar_1:1,b_white,w_800,h_800/v1793992406/PRODUCT-PAGE-BANNER_MEGAPAD-SE_VERTICAL.webp'],

  ['Samsung', 'Galaxy A17 LTE', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045631/sm-a175_galaxy-a17_lte_00_1.png'],
  ['Samsung', 'Galaxy A17 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992415/714xFEnatFL._AC_UF894_1000_QL80_FMwebp_.webp'],
  ['Samsung', 'Galaxy A07s', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045637/5795189i3D78BD1334F95786.jpg'],
  ['Samsung', 'Galaxy A18 LTE', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992416/large_samsung-galaxy-a18_9.png'],
  ['Samsung', 'Galaxy Z Fold8 Ultra', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992415/galaxy-z-fold8-ultra-features-kv-mo.jpg'],
  ['Samsung', 'Galaxy S26', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992415/large_samsung-galaxy-s26_10.jpg'],
  ['Samsung', 'Galaxy S26+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992415/large_samsung-galaxy-s26_10.jpg'],
  ['Samsung', 'Galaxy Tab A11 LTE', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992408/Main.png'],

  ['HONOR', '600', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992409/Honor-600-phones.jpg'],
  ['Infinix', 'SMART 20 HD', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992409/infinix-smart-20-hd-front-back.png'],
  ['Infinix', 'HOT 70', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992409/OIP.IpH7k93crO2BQQBMZclrngAAAA.webp'],
  ['Infinix', 'NOTE 60 Edge', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992407/Infinix-NOTE-60-Pro.jpg'],
  ['itel', 'A200+S', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992409/81103-itel-a200-plus-11.jpg'],
  ['itel', 'Vista Tab 30s', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992409/f4b9f4b5c78f1b3fb522f201aaed9ba7.png'],
  ['Redmi', 'Redmi 13', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992410/large_xiaomi-redmi-13_7.jpg'],
  ['Redmi', 'Redmi 15C 5G', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793992410/f752bf20ddb6e46633a4c156af9b2b8e.webp'],
  ['Redmi', 'Redmi Note 15 Pro+', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045688/IMG-20261012-WA0056.jpg'],

  ['Apple', 'iPhone 15 Pro Max', 'https://res.cloudinary.com/j3rveiep/image/upload/v1793045587/IMG-20261026-WA0120_1__edit_2599320367832161.jpg']
];

// Preserve model punctuation in image keys. Stripping '+' caused product photos to
// collide between Pro and Pro+ models.
function productImageKey(brand, modelName) {
  return `${canonicalPhoneBrand(brand, modelName)}|${normalizeModelToken(modelName)}`;
}

const PRODUCT_IMAGE_MAP = new Map(
  PRODUCT_IMAGE_ASSIGNMENTS.map(([brand, name, image]) => [productImageKey(brand, name), image])
);

let productImagesApplied = 0;
for (const product of PHONE_PRODUCTS) {
  const image = PRODUCT_IMAGE_MAP.get(productImageKey(product.brand, product.name));
  if (image && !product.image) {
    product.image = image;
    productImagesApplied += 1;
  }
}

// Model-specific local crops from the supplied product catalogue sheets.
// These are only used on the exact model shown in each crop.
const LOCAL_PRODUCT_IMAGE_FALLBACKS = [
  ['JX', 'Note 15 Lite', 'images/product-cards/JX_Note_15_Lite.jpg'],
  ['JX', 'Note 16 Lite', 'images/product-cards/JX_Note_16_Lite.jpg'],
  ['JX', 'Note 17 Lite', 'images/product-cards/JX_Note_17_Lite.jpg'],
  // JX Smart 6's local crop was a J4 stock image, not the correct handset.
  // Keep only the supplied model image URL; no unrelated fallback is used.
  // M18 Pro Max has a supplied remote image; its catalogue crop is incomplete,
  // so avoid showing that cropped/black fallback if the remote image fails.
  ['M-HORSE', 'A200', 'images/product-cards/MHORSE_A200.jpg'],
  ['M-HORSE', 'M16 Pro Max', 'images/product-cards/MHORSE_M16_Pro_Max.jpg'],
  ['M-HORSE', 'CAMON 50', 'images/product-cards/MHORSE_CAMON_50.jpg'],
  ['M-HORSE', 'CAMON 50+', 'images/product-cards/MHORSE_CAMON_50_Plus.jpg'],
  ['M-HORSE', 'S25 Ultra+', 'images/product-cards/MHORSE_S25_Ultra_Plus.jpg'],
  ['M-HORSE', 'Hot 30 Play+', 'images/product-cards/MHORSE_Hot_30_Play_Plus.jpg'],
  ['M-HORSE', 'Pad 17', 'images/product-cards/MHORSE_Pad_17.jpg'],
  ['M-HORSE', 'SPARK 40', 'images/product-cards/MHORSE_SPARK_40.jpg'],
  ['Redmi', 'Redmi A7', 'images/product-cards/Redmi_A7.jpg'],
  ['Redmi', 'Redmi A7 Pro', 'images/product-cards/Redmi_A7_Pro.jpg'],
  ['Redmi', 'Redmi 15C', 'images/product-cards/Redmi_15C.jpg'],
  ['Redmi', 'Redmi Note 15', 'images/product-cards/Redmi_Note_15.jpg']
];

const LOCAL_IMAGE_MAP = new Map(
  LOCAL_PRODUCT_IMAGE_FALLBACKS.map(([brand, name, image]) => [productImageKey(brand, name), image])
);
for (const product of PHONE_PRODUCTS) {
  const localImage = LOCAL_IMAGE_MAP.get(productImageKey(product.brand, product.name));
  if (localImage) {
    product.imageFallback = localImage;
    if (!product.image) product.image = localImage;
  }
}

const PRODUCT_ADDITIONAL_IMAGES = {
  [productImageKey('Redmi', 'Redmi Note 17')]: [
    'https://res.cloudinary.com/j3rveiep/image/upload/v1793045684/IMG-20261012-WA0046.jpg'
  ],
  [productImageKey('Samsung', 'Galaxy S26 Ultra')]: [
    'https://res.cloudinary.com/j3rveiep/image/upload/v1793045629/galaxy-s26-ultra-camera-system-closeup.webp'
  ]
};
for (const product of PHONE_PRODUCTS) {
  const extraImages = PRODUCT_ADDITIONAL_IMAGES[productImageKey(product.brand, product.name)];
  if (extraImages) product.additionalImages = extraImages;
}

const ALL_PRODUCTS = [...PHONE_PRODUCTS, ...LAPTOP_PRODUCTS, ...EARBUD_PRODUCTS, ...OTHER_ACCESSORIES];

// Phone/tablet storage configurations are displayed as selectable variants
// on one model card. Each configuration remains a separate record internally
// so its own price, image, and cart/order key are preserved.
// Preserve separate model brands even where supplier records used a combined label.
function canonicalPhoneBrand(brand, modelName = '') {
  const model = normalizeText(modelName).toLowerCase();
  if (/^xiaomi\b/.test(model)) return 'xiaomi';
  if (/^redmi\b/.test(model)) return 'redmi';
  const normalized = normalizeModelToken(brand);
  return normalized.includes('redmi') ? 'redmi' : normalized;
}

function displayPhoneBrand(brand, modelName = '') {
  const model = normalizeText(modelName).toLowerCase();
  if (/^xiaomi\b/.test(model)) return 'Xiaomi';
  if (/^redmi\b/.test(model)) return 'Redmi';
  return brand;
}

// Keep plus signs meaningful in model names (e.g. SPARK 40 Pro+ and Galaxy S26+).
function normalizeModelToken(value) {
  return normalizeText(value).toLowerCase()
    .replace(/\+/g, ' plus ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, '-');
}

function getVariantMemoryOrder(variant) {
  const text = normalizeText(variant);
  const ramMatch = text.match(/(\d+(?:\.\d+)?)\s*GB\s*\//i);
  const storageMatch = text.match(/\/\s*(\d+(?:\.\d+)?)\s*(GB|TB)/i) ||
    text.match(/(\d+(?:\.\d+)?)\s*(GB|TB)/i);
  const ram = ramMatch ? Number(ramMatch[1]) : -1;
  let storage = storageMatch ? Number(storageMatch[1]) : Number.POSITIVE_INFINITY;
  if (storageMatch && String(storageMatch[2]).toUpperCase() === 'TB') storage *= 1024;
  return { ram, storage, text };
}

function displayPhoneVariant(productOrVariant) {
  const raw = typeof productOrVariant === 'string'
    ? productOrVariant
    : (productOrVariant?.variant || '');
  const value = normalizeText(raw);
  if (!value || /^(?:variant details to confirm|ram\s*\/\s*storage not supplied)$/i.test(value)) return '';
  return value;
}

function sortPhoneVariants(products) {
  return [...products].sort((a, b) => {
    const av = getVariantMemoryOrder(a.variant);
    const bv = getVariantMemoryOrder(b.variant);
    if (av.ram !== bv.ram) return av.ram - bv.ram;
    if (av.storage !== bv.storage) return av.storage - bv.storage;
    return av.text.localeCompare(bv.text, undefined, { numeric: true, sensitivity: 'base' });
  });
}

function getPhoneProductGroups(category = null) {
  const groups = new Map();
  PHONE_PRODUCTS.forEach(product => {
    if (category && product.category !== category) return;
    const brandKey = canonicalPhoneBrand(product.brand, product.name);
    const groupKey = `${brandKey}-${normalizeModelToken(product.name)}-${product.category}`;
    if (!groups.has(groupKey)) {
      groups.set(groupKey, {
        key: groupKey,
        brand: displayPhoneBrand(product.brand, product.name),
        name: product.name,
        category: product.category,
        products: []
      });
    }
    groups.get(groupKey).products.push(product);
  });
  return [...groups.values()].map(group => {
    const products = sortPhoneVariants(group.products);
    return {
      ...group,
      products,
      image: products.find(product => product.image)?.image || '',
      imageFallback: products.find(product => product.imageFallback)?.imageFallback || '',
      additionalImages: [...new Set(products.flatMap(product => product.additionalImages || []))],
      prices: products.map(product => parsePrice(product.price)).filter(price => price !== null),
      hasUnpricedVariants: products.some(product => parsePrice(product.price) === null),
      specs: products.find(product => normalizeText(product.specs))?.specs || ''
    };
  });
}

function getPhoneProductGroupByKey(groupKey) {
  return getPhoneProductGroups().find(group => group.key === groupKey) || null;
}

function getGroupSearchText(group) {
  return [group.brand, group.name, ...group.products.flatMap(product => [
    product.variant, product.specs, product.modelCode, product.colors
  ])].join(' ').toLowerCase();
}

// ---------------------------------------------------------
// NAVIGATION & AUTHENTICATION
// ---------------------------------------------------------
function hideAllSections() {
  sections.forEach(id => { const section = byId(id); if (section) section.style.display = 'none'; });
}

function showSection(id) {
  if (!sections.includes(id)) return;
  hideAllSections();
  const section = byId(id);
  if (section) section.style.display = 'block';

  // Remember the last page in this browser tab so refresh restores it.
  // Login and signup are intentionally excluded so they don't replace
  // the customer's last page while authentication is in progress.
  if (id !== 'login' && id !== 'signup') {
    try { sessionStorage.setItem('gemmestores_last_page', id); }
    catch (error) { console.warn('Unable to save current page:', error); }
  }

  closeDashboardMenu();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function restoreLastPage(user) {
  if (!user) {
    showHome();
    return;
  }

  let lastPage = 'dashboard';
  try { lastPage = sessionStorage.getItem('gemmestores_last_page') || 'dashboard'; }
  catch (error) { console.warn('Unable to retrieve saved page:', error); }

  if (!sections.includes(lastPage) || ['home', 'login', 'signup'].includes(lastPage)) {
    lastPage = 'dashboard';
  }

  // Checkout is deliberately not restored: its form is temporary and
  // the cart is not persisted as an unfinished payment/order.
  if (lastPage === 'checkout') lastPage = 'phones';

  if (byId('userEmail')) {
    byId('userEmail').textContent = 'Logged in as: ' + (user.email || 'Customer');
  }

  switch (lastPage) {
    case 'dashboard':
      await showDashboard();
      break;
    case 'wallet':
      await showWallet();
      break;
    case 'phones':
      openService('phones');
      break;
    case 'account':
      await showAccount();
      break;
    case 'settings':
      showSettings();
      break;
    case 'tracking': {
      let trackingId = '';
      try { trackingId = sessionStorage.getItem('gemmestores_tracking_id') || ''; }
      catch (error) { console.warn('Unable to retrieve tracking ID:', error); }
      if (trackingId) {
        showSection('tracking');
        if (byId('trackingInput')) byId('trackingInput').value = trackingId;
        await trackOrder();
      } else {
        await showDashboard();
      }
      break;
    }
    default:
      // Data, Airtime and Bills pages can be restored directly.
      showSection(lastPage);
      break;
  }
}

function showHome() {
  pendingService = null;
  showSection('home');
}

// Keep navigation functions available to the HTML onclick handlers.
window.showHome = showHome;
window.showSection = showSection;

function showSignup() { pendingService = null; showSection('signup'); }
function showLogin() { showSection('login'); }

async function showDashboard() {
  const user = await getCurrentUser();
  if (!user) { pendingService = null; showLogin(); return; }
  const userEmail = byId('userEmail');
  if (userEmail) userEmail.textContent = 'Logged in as: ' + (user.email || 'Customer');
  showSection('dashboard');
  await Promise.all([loadWalletBalance(), loadPaymintVirtualAccount()]);
}

async function showWallet() {
  const user = await getCurrentUser();
  if (!user) { pendingService = null; showLogin(); return; }
  const overview = byId('walletOverviewContent');
  const historyPage = byId('walletTransactionsDetailPage');
  if (overview) overview.style.display = '';
  if (historyPage) historyPage.style.display = 'none';
  showSection('wallet');
  populateWalletGreeting(user);
  await loadWalletOverview();
}

function populateWalletGreeting(user) {
  const name = normalizeText(user?.user_metadata?.full_name || user?.user_metadata?.name || user?.email?.split('@')[0] || 'there');
  ['walletGreetingName','walletWelcomeName'].forEach(id => { const el = byId(id); if (el) el.textContent = id === 'walletWelcomeName' ? `${name} 👋` : name; });
}

async function openProtectedService(service) {
  const user = await getCurrentUser();
  if (user) { pendingService = null; openService(service); }
  else { pendingService = service; showLogin(); }
}

function openService(service) {
  const map = { data: 'buy-data', airtime: 'buy-airtime', bills: 'bills', phones: 'phones' };
  if (map[service]) {
    showSection(map[service]);
    if (service === 'phones') { renderProductCatalog(); showPhoneCategory('phones'); }
    return;
  }
  showDashboard();
}

function showBuyData() { return openProtectedService('data'); }
function showBuyAirtime() { return openProtectedService('airtime'); }
function showBills() { return openProtectedService('bills'); }
function showPhones() { return openProtectedService('phones'); }

async function createAccount() {
  const name = normalizeText(byId('fullName')?.value);
  const email = normalizeText(byId('email')?.value).toLowerCase();
  const password = byId('password')?.value || '';
  const message = byId('signupMessage');
  if (!name || !email || !password) { if (message) message.textContent = 'Please fill in all fields.'; return; }
  if (password.length < 6) { if (message) message.textContent = 'Password must be at least 6 characters.'; return; }
  if (message) message.textContent = 'Creating your account...';
  try {
    const { data, error } = await supabaseClient.auth.signUp({ email, password, options: { data: { full_name: name } } });
    if (error) throw error;
    if (data.session) { if (message) message.textContent = 'Account created successfully!'; setTimeout(showDashboard, 700); }
    else if (message) message.textContent = 'Account created. Please check your email to confirm your account before logging in.';
  } catch (error) {
    console.error('Signup error:', error);
    if (message) message.textContent = error.message || 'Unable to create your account. Please try again.';
  }
}

async function loginUser() {
  const email = normalizeText(byId('loginEmail')?.value).toLowerCase();
  const password = byId('loginPassword')?.value || '';
  const message = byId('loginMessage');
  if (!email || !password) { if (message) message.textContent = 'Please enter your email and password.'; return; }
  if (message) message.textContent = 'Logging in...';
  try {
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) throw error;
    const userEmail = byId('userEmail');
    if (userEmail && data.user) userEmail.textContent = 'Logged in as: ' + (data.user.email || 'Customer');
    const service = pendingService;
    pendingService = null;
    if (service) openService(service); else await showDashboard();
  } catch (error) {
    console.error('Login error:', error);
    if (message) message.textContent = error.message || 'Login failed. Please try again.';
  }
}

async function logoutUser() {
  try {
    const { error } = await supabaseClient.auth.signOut();
    if (error) throw error;
  } catch (error) { console.error('Logout error:', error); alert('Unable to sign out completely. Please try again.'); return; }
  phoneCart = [];
  updatePhoneCart();
  pendingService = null;
  try {
    sessionStorage.removeItem('gemmestores_last_page');
    sessionStorage.removeItem('gemmestores_tracking_id');
  } catch (error) { console.warn('Unable to clear saved page:', error); }
  closeDashboardMenu();
  showHome();
}

// ---------------------------------------------------------
// PASSWORD SHOW / HIDE CONTROLS
// ---------------------------------------------------------
function addPasswordToggle(input) {
  if (!input || input.dataset.passwordToggle === 'ready') return;
  input.dataset.passwordToggle = 'ready';
  const wrapper = document.createElement('div');
  wrapper.className = 'password-toggle-wrap';
  input.parentNode.insertBefore(wrapper, input);
  wrapper.appendChild(input);
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'password-toggle-button';
  button.textContent = '👁 Show';
  button.setAttribute('aria-label', 'Show password');
  button.addEventListener('click', () => {
    const reveal = input.type === 'password';
    input.type = reveal ? 'text' : 'password';
    button.textContent = reveal ? '🙈 Hide' : '👁 Show';
    button.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
  });
  wrapper.appendChild(button);
}

function initializePasswordToggles() {
  ['password','loginPassword','newAccountPassword','confirmAccountPassword'].forEach(id => addPasswordToggle(byId(id)));
}

// ---------------------------------------------------------
// DASHBOARD MENU
// ---------------------------------------------------------
function toggleDashboardMenu() {
  const sidebar = document.querySelector('.dashboard-sidebar');
  const overlay = document.querySelector('.dashboard-menu-overlay');
  if (!sidebar) return;
  const open = sidebar.classList.toggle('menu-open');
  if (overlay) overlay.classList.toggle('active', open);
}
function closeDashboardMenu() {
  document.querySelector('.dashboard-sidebar')?.classList.remove('menu-open');
  document.querySelector('.dashboard-menu-overlay')?.classList.remove('active');
}

// ---------------------------------------------------------
// WALLET — PayMint bank-transfer funding + wallet history
// ---------------------------------------------------------
async function loadWalletBalance() {
  const displays = ['walletBalance', 'walletPageBalance', 'withdrawalAvailableBalance'];
  displays.forEach(id => { if (byId(id)) byId(id).textContent = 'Loading...'; });
  const user = await getCurrentUser();
  if (!user) {
    displays.forEach(id => { if (byId(id)) byId(id).textContent = 'Please log in'; });
    return;
  }
  try {
    const { data, error } = await supabaseClient
      .from('wallets')
      .select('balance')
      .eq('user_id', user.id)
      .maybeSingle();
    if (error) throw error;
    const balance = data ? Number(data.balance) : 0;
    if (!Number.isFinite(balance)) throw new Error('Wallet balance is not a valid number.');
    const formatted = formatMoney(balance, 2);
    displays.forEach(id => { if (byId(id)) byId(id).textContent = formatted; });
  } catch (error) {
    console.error('Wallet balance loading error:', error);
    displays.forEach(id => { if (byId(id)) byId(id).textContent = 'Unable to load'; });
  }
}

function createWalletTransactionRow(item) {
  const row = document.createElement('article');
  row.className = 'wallet-transaction-item';

  const details = document.createElement('div');
  details.className = 'wallet-transaction-details';

  const typeLabels = {
    deposit: 'Wallet funding',
    withdrawal: 'Wallet withdrawal',
    purchase: 'Wallet purchase',
    refund: 'Refund'
  };
  const title = document.createElement('strong');
  title.textContent = typeLabels[item.transaction_type] || 'Wallet transaction';

  const description = document.createElement('small');
  description.textContent = item.description || 'Gemmestores wallet transaction';

  const date = document.createElement('small');
  const parsedDate = item.created_at ? new Date(item.created_at) : null;
  date.textContent = parsedDate && !Number.isNaN(parsedDate.getTime())
    ? parsedDate.toLocaleString('en-NG', { dateStyle: 'medium', timeStyle: 'short' })
    : 'Date unavailable';
  details.append(title, description, date);

  const amountBox = document.createElement('div');
  amountBox.className = 'wallet-transaction-amount';
  const amount = document.createElement('strong');
  const isCredit = ['deposit', 'refund'].includes(item.transaction_type);
  amount.textContent = `${isCredit ? '+' : '−'}${formatMoney(item.amount, 2)}`;
  amount.classList.add(isCredit ? 'is-credit' : 'is-debit');

  const status = document.createElement('small');
  const safeStatus = String(item.status || 'unknown').toLowerCase();
  status.textContent = safeStatus.replace(/^./, ch => ch.toUpperCase());
  status.className = `wallet-transaction-status status-${safeStatus.replace(/[^a-z0-9_-]/g, '')}`;
  amountBox.append(amount, status);
  row.append(details, amountBox);
  return row;
}

function renderWalletTransactionList(container, transactions, emptyMessage) {
  if (!container) return;
  container.replaceChildren();
  if (!transactions.length) {
    container.className = 'wallet-empty-transactions';
    const icon = document.createElement('div');
    icon.className = 'empty-icon';
    icon.textContent = '▤';
    const heading = document.createElement('h4');
    heading.textContent = 'No transactions yet';
    const message = document.createElement('p');
    message.textContent = emptyMessage;
    container.append(icon, heading, message);
    return;
  }
  container.className = 'wallet-transaction-list';
  transactions.forEach(item => container.appendChild(createWalletTransactionRow(item)));
}

async function loadWalletHistory() {
  const preview = byId('walletTransactionsPreview');
  const historyContainer = byId('walletPageTransactions');
  const fundedDisplay = byId('walletTotalFunded');
  const withdrawnDisplay = byId('walletTotalWithdrawn');
  if (fundedDisplay) fundedDisplay.textContent = 'Loading...';
  if (withdrawnDisplay) withdrawnDisplay.textContent = 'Loading...';
  if (preview) {
    preview.className = 'wallet-transactions-preview wallet-transactions-preview-empty';
    preview.textContent = 'Loading your recent transactions...';
  }
  if (historyContainer) {
    historyContainer.className = 'wallet-empty-transactions';
    historyContainer.textContent = 'Loading wallet transactions...';
  }

  const user = await getCurrentUser();
  if (!user) {
    if (fundedDisplay) fundedDisplay.textContent = '—';
    if (withdrawnDisplay) withdrawnDisplay.textContent = '—';
    if (preview) preview.textContent = 'Please log in to view recent transactions.';
    if (historyContainer) historyContainer.textContent = 'Please log in to view wallet transactions.';
    return;
  }

  try {
    // Read the signed-in user's complete history for lifetime totals and View All.
    // The Wallet overview separately renders only the three newest transactions.
    const pageSize = 1000;
    const allTransactions = [];
    let pageStart = 0;
    while (true) {
      const { data, error } = await supabaseClient
        .from('wallet_transactions')
        .select('transaction_type, amount, status, reference, description, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .range(pageStart, pageStart + pageSize - 1);
      if (error) throw error;
      const page = data || [];
      allTransactions.push(...page);
      if (page.length < pageSize) break;
      pageStart += pageSize;
    }

    const successful = allTransactions.filter(item => String(item.status || '').toLowerCase() === 'successful');
    const funded = successful
      .filter(item => item.transaction_type === 'deposit')
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const withdrawn = successful
      .filter(item => item.transaction_type === 'withdrawal')
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    if (fundedDisplay) fundedDisplay.textContent = formatMoney(funded, 2);
    if (withdrawnDisplay) withdrawnDisplay.textContent = formatMoney(withdrawn, 2);

    // Always show the latest three records on the Wallet overview.
    // View All opens the separate page containing the complete history.
    if (preview) {
      preview.replaceChildren();
      if (!allTransactions.length) {
        preview.className = 'wallet-transactions-preview wallet-transactions-preview-empty';
        const icon = document.createElement('span');
        icon.className = 'wallet-preview-icon';
        icon.textContent = '◷';
        const copy = document.createElement('div');
        const heading = document.createElement('p');
        heading.textContent = 'No wallet activity yet';
        const helper = document.createElement('small');
        helper.textContent = 'Your deposits, purchases and withdrawals will appear here.';
        copy.append(heading, helper);
        preview.append(icon, copy);
      } else {
        preview.className = 'wallet-transactions-preview wallet-transaction-preview-list';
        allTransactions.slice(0, 3).forEach(item => preview.appendChild(createWalletTransactionRow(item)));
      }
    }

    renderWalletTransactionList(
      historyContainer,
      allTransactions,
      'Your wallet funding, purchases and withdrawals will appear here.'
    );
  } catch (error) {
    console.error('Wallet history loading error:', error);
    if (fundedDisplay) fundedDisplay.textContent = 'Unable to load';
    if (withdrawnDisplay) withdrawnDisplay.textContent = 'Unable to load';
    if (preview) {
      preview.className = 'wallet-transactions-preview wallet-transactions-preview-empty';
      preview.textContent = 'Recent transactions could not be loaded. Please refresh and try again.';
    }
    if (historyContainer) {
      historyContainer.className = 'wallet-empty-transactions';
      historyContainer.textContent = 'Unable to load wallet transactions. Please refresh and try again.';
    }
  }
}

async function loadWalletOverview() {
  await Promise.all([loadWalletBalance(), loadWalletHistory(), loadPaymintVirtualAccount()]);
}

// Load one saved PayMint account and render that same record in Dashboard and My Wallet.
// This function is read-only and never creates an account or credits a wallet.
async function loadPaymintVirtualAccount() {
  const containers = [byId('dashboardVirtualAccount'), byId('walletVirtualAccount')].filter(Boolean);
  const feeNotices = [byId('dashboardPaymintFeeNotice'), byId('walletPaymintFeeNotice')].filter(Boolean);
  feeNotices.forEach(el => { el.hidden = true; });
  if (!containers.length) return;
  containers.forEach(el => { el.textContent = 'Loading your account details...'; });
  const form = byId('paymintCreateAccountForm');
  try {
    const user = await getCurrentUser();
    if (!user) {
      containers.forEach(el => { el.textContent = 'Please log in to view your virtual account.'; });
      if (form) form.hidden = true;
      return;
    }
    const { data, error } = await supabaseClient
      .from('paymint_virtual_accounts')
      .select('bank_name, account_name, account_number, preferred_bank, status, environment')
      .eq('user_id', user.id)
      .eq('environment', 'live')
      .maybeSingle();
    if (error) throw error;

    const status = String(data?.status || '').toLowerCase();
    if (data?.account_number && status === 'active') {
      containers.forEach(container => {
        container.replaceChildren();
        const rows = [
          ['Bank', data.bank_name || data.preferred_bank || 'Not available'],
          ['Account Name', data.account_name || 'Not available'],
          ['Account Number', data.account_number || 'Not available']
        ];
        rows.forEach(([label, value]) => {
          const row = document.createElement('p');
          row.className = 'virtual-account-row';
          const strong = document.createElement('strong');
          strong.textContent = label + ': ';
          const valueText = document.createElement('span');
          valueText.className = 'virtual-account-value';
          valueText.textContent = String(value);
          row.append(strong, valueText);
          if (label === 'Account Number') {
            const copy = document.createElement('button');
            copy.type = 'button';
            copy.className = 'virtual-account-copy-icon';
            copy.textContent = '⧉';
            copy.title = 'Copy account number';
            copy.setAttribute('aria-label', 'Copy account number');
            copy.addEventListener('click', async event => {
              event.stopPropagation();
              try {
                if (!navigator.clipboard?.writeText) throw new Error('Clipboard API unavailable');
                await navigator.clipboard.writeText(String(data.account_number));
                copy.textContent = '✓';
                copy.title = 'Account number copied';
                setTimeout(() => { copy.textContent = '⧉'; copy.title = 'Copy account number'; }, 1800);
              } catch (_) {
                window.prompt('Copy your account number:', String(data.account_number));
              }
            });
            row.appendChild(copy);
          }
          container.appendChild(row);
        });
      });
      // Only customers with an active Live PayMint account see the fee notice.
      feeNotices.forEach(el => { el.hidden = false; });
      if (form) form.hidden = true;
      return;
    }

    const pending = data && status && status !== 'failed';
    containers.forEach(container => {
      container.replaceChildren();
      const message = document.createElement('p');
      message.textContent = pending
        ? `Your virtual account request is currently ${data.status}. Please wait or contact Gemmestores Admin; do not submit another request.`
        : 'You do not have a virtual bank account yet.';
      container.appendChild(message);
      if (!pending) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'virtual-account-request-button';
        button.textContent = '＋ Request Live Virtual Account';
        button.addEventListener('click', event => {
          event.stopPropagation();
          openPaymintAccountRequest();
        });
        container.appendChild(button);
      }
    });
    if (form) form.hidden = true;
  } catch (error) {
    console.error('PayMint virtual account loading error:', error);
    containers.forEach(el => { el.textContent = 'Unable to load your virtual account. Please refresh and try again.'; });
    if (form) form.hidden = true;
  }
}

async function openPaymintAccountRequest() {
  const user = await getCurrentUser();
  if (!user) { showLogin(); return; }

  // The request form is inside My Wallet. Wait for Wallet's account refresh
  // to finish before revealing it, so the loading refresh cannot hide it again.
  await showWallet();
  const form = byId('paymintCreateAccountForm');
  if (form) {
    form.hidden = false;
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    byId('paymintCreateAccountButton')?.focus({ preventScroll: true });
  }
}

function setWalletPaymentNotice(message, isError = false) {
  const notice = byId('walletPaymentNotice');
  if (!notice) return;
  notice.textContent = message;
  notice.hidden = !message;
  notice.classList.toggle('is-error', Boolean(isError));
  notice.classList.toggle('is-success', Boolean(message) && !isError);
}

async function topUpWallet() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      showLogin();
      return;
    }

    // Live customer funding is currently through the dedicated PayMint bank account.
    // Keep the Flutterwave checkout in Test Mode and do not route customers into it.
    await showWallet();
    const accountCard = document.querySelector('#wallet .wallet-inline-virtual-account');
    if (accountCard) {
      accountCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      accountCard.classList.add('wallet-funding-highlight');
      setTimeout(() => accountCard.classList.remove('wallet-funding-highlight'), 1800);
    }
  } catch (error) {
    console.error('Wallet funding navigation error:', error);
    alert('Unable to open your PayMint funding details. Please refresh and try again.');
  }
}

function closeWalletFundModal() {
  const modal = byId('walletFundModal');
  if (!modal) return;
  modal.hidden = true;
  modal.setAttribute('aria-hidden', 'true');
}

async function submitWalletTopUp(event) {
  event?.preventDefault();
  const input = byId('walletFundAmount');
  const button = byId('walletFundSubmitButton');
  const amount = Number(input?.value);

  if (!Number.isInteger(amount) || amount < 50 || amount > 10000000) {
    setMessage('walletFundMessage', 'Enter a whole-number amount between ₦50 and ₦10,000,000.', true);
    input?.focus();
    return;
  }

  const user = await getCurrentUser();
  if (!user) {
    closeWalletFundModal();
    showLogin();
    return;
  }

  if (button) {
    button.disabled = true;
    button.textContent = 'Connecting to Flutterwave...';
  }
  setMessage('walletFundMessage', 'Creating your secure payment. Please do not close this page...', false);

  try {
    // Explicitly attach the current Supabase access token. This avoids a
    // missing Authorization header when the customer returns from checkout.
    let { data: sessionData, error: sessionError } = await supabaseClient.auth.getSession();
    let accessToken = sessionData?.session?.access_token;
    if (!accessToken) {
      const refreshed = await supabaseClient.auth.refreshSession();
      accessToken = refreshed?.data?.session?.access_token;
      sessionError = refreshed?.error || sessionError;
    }
    if (!accessToken) {
      throw new Error(sessionError?.message || 'Your login session has expired. Please log in again before starting payment.');
    }

    const { data, error } = await supabaseClient.functions.invoke('flutterwave-api', {
      headers: { Authorization: `Bearer ${accessToken}` },
      body: { action: 'create', amount }
    });

    if (error || !data?.success || !data?.checkout_url) {
      let detail = data?.error || error?.message || 'Unable to start Flutterwave checkout.';
      try {
        const body = error?.context?.body;
        if (typeof body === 'string') detail = JSON.parse(body)?.error || detail;
        else if (body && typeof body === 'object') detail = body.error || detail;
      } catch (_) { /* Keep the readable fallback message. */ }
      throw new Error(detail);
    }

    // Flutterwave hosts the payment page; no card or bank details are collected here.
    window.location.assign(data.checkout_url);
  } catch (error) {
    console.error('Flutterwave checkout error:', error);
    setMessage('walletFundMessage', error.message || 'Unable to start payment. Please try again.', true);
    if (button) {
      button.disabled = false;
      button.textContent = 'Continue to Flutterwave Test Mode';
    }
  }
}

async function handleFlutterwaveReturn() {
  const params = new URLSearchParams(window.location.search);
  const hasReturnData = params.get('payment') === 'flutterwave' || params.has('transaction_id') || params.has('tx_ref');
  if (!hasReturnData) return;

  await showWallet();
  const status = String(params.get('status') || '').toLowerCase();
  const txRef = params.get('tx_ref') || '';
  const transactionId = params.get('transaction_id') || '';

  if (status !== 'successful') {
    setWalletPaymentNotice('Payment was not completed. No money was added to your Gemmestores wallet.', true);
    window.history.replaceState({}, document.title, window.location.pathname);
    return;
  }

  if (!txRef || !transactionId) {
    setWalletPaymentNotice('Flutterwave returned an incomplete payment reference. Please contact Gemmestores Admin before trying to pay again.', true);
    window.history.replaceState({}, document.title, window.location.pathname);
    return;
  }

  setWalletPaymentNotice('Payment returned successfully. We are verifying it securely with Flutterwave...', false);
  try {
    // Re-read/refresh the session after the Flutterwave redirect and send
    // the access token explicitly to the authenticated Edge Function.
    let { data: sessionData, error: sessionError } = await supabaseClient.auth.getSession();
    let accessToken = sessionData?.session?.access_token;
    if (!accessToken) {
      const refreshed = await supabaseClient.auth.refreshSession();
      accessToken = refreshed?.data?.session?.access_token;
      sessionError = refreshed?.error || sessionError;
    }
    if (!accessToken) {
      setWalletPaymentNotice(
        sessionError?.message || 'Your login session has expired. Please log in again, then return to this page to retry verification. Do not pay again.',
        true
      );
      return; // Keep Flutterwave's transaction references in the URL for retry.
    }

    const { data, error } = await supabaseClient.functions.invoke('flutterwave-api', {
      headers: { Authorization: `Bearer ${accessToken}` },
      body: {
        action: 'verify',
        tx_ref: txRef,
        transaction_id: transactionId
      }
    });

    if (error || !data?.success) {
      const detail = data?.error || error?.message || 'Payment could not be confirmed.';
      setWalletPaymentNotice(`${detail} No wallet balance has been added yet. Please refresh this page to retry verification, or contact Admin.`, true);
      // Keep the callback reference in the URL so the customer can retry by refreshing.
      return;
    }

    await loadWalletOverview();
    const amountText = formatMoney(data.amount, 2);
    setWalletPaymentNotice(
      data.already_credited
        ? `This payment of ${amountText} was already added to your wallet. Your balance has been refreshed.`
        : `Wallet funded successfully! ${amountText} has been added to your Gemmestores wallet.`,
      false
    );
    window.history.replaceState({}, document.title, window.location.pathname);
  } catch (error) {
    console.error('Flutterwave return verification error:', error);
    setWalletPaymentNotice('We could not reach the payment verification service. Your wallet has not been changed by this page. Refresh to retry verification.', true);
  }
}

async function showWalletWithdrawal() {
  const user = await getCurrentUser();
  if (!user) { showLogin(); return; }
  await showWallet();
  showWithdrawSection();
}
function showWithdrawSection() {
  const section = byId('walletWithdrawSection');
  if (!section) { alert('Wallet withdrawal section was not found.'); return; }
  section.style.display = 'block';
  loadWalletBalance();
  setTimeout(() => section.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}
function closeWithdrawSection() { if (byId('walletWithdrawSection')) byId('walletWithdrawSection').style.display = 'none'; }
async function returnToDashboard() { closeWithdrawSection(); closeDashboardMenu(); await showDashboard(); }
async function showWalletTransactions() {
  const user = await getCurrentUser();
  if (!user) { showLogin(); return; }
  await showWallet();
  const overview = byId('walletOverviewContent');
  const historyPage = byId('walletTransactionsDetailPage');
  if (overview) overview.style.display = 'none';
  if (historyPage) historyPage.style.display = 'block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function closeWalletTransactions() {
  const overview = byId('walletOverviewContent');
  const historyPage = byId('walletTransactionsDetailPage');
  if (historyPage) historyPage.style.display = 'none';
  if (overview) overview.style.display = '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------------------------------------------------------
// DATA PLANS — ABS ORDINARY DATA PURCHASE
// ---------------------------------------------------------
async function showPlans(network) {
  const container = byId('plans');
  const networkGrid = byId('dataNetworkGrid');
  if (!container) return;
  if (networkGrid) networkGrid.style.display = 'none';
  container.replaceChildren(Object.assign(document.createElement('p'), { textContent: 'Loading plans...' }));
  try {
    const { data, error } = await supabaseClient
      .from('data_plans')
      .select('id,network,data_type,data_size,validity,price,active,abs_network_id,abs_plan_id')
      .eq('network', network)
      .eq('active', true)
      .order('price', { ascending: true });
    if (error) throw error;

    const ordinaryPlans = (data || []).filter(plan =>
      normalizeText(plan.data_type || '').toLowerCase() !== 'broadband internet'
    );
    if (!ordinaryPlans.length) {
      container.textContent = `No ordinary ${network} data plans are currently available.`;
      return;
    }

    const categories = [...new Set(ordinaryPlans.map(plan => normalizeText(plan.data_type || 'Regular')))]
      .filter(Boolean);
    const header = document.createElement('div');
    header.className = 'data-flow-heading';
    const changeNetwork = document.createElement('button');
    changeNetwork.type = 'button';
    changeNetwork.className = 'back-to-categories';
    changeNetwork.textContent = '← Change network';
    changeNetwork.addEventListener('click', () => {
      container.replaceChildren(Object.assign(document.createElement('p'), { textContent: 'Select a network to view plans.' }));
      if (networkGrid) networkGrid.style.display = '';
    });
    const heading = document.createElement('div');
    heading.innerHTML = `<h3>${network} data plans</h3><p>Select the data bundle you want to buy.</p>`;
    header.append(changeNetwork, heading);
    container.replaceChildren(header);

    if (categories.length > 1) {
      const categoryList = document.createElement('div');
      categoryList.className = 'data-category-list';
      categories.forEach(category => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'data-category-button';
        button.textContent = category;
        button.addEventListener('click', () => showCategoryPlans(network, category, ordinaryPlans));
        categoryList.appendChild(button);
      });
      container.appendChild(categoryList);
    } else {
      showCategoryPlans(network, categories[0], ordinaryPlans);
    }
  } catch (error) {
    console.error('Plans error:', error);
    container.textContent = 'Unable to load plans. Please try again later.';
  }
}

function showCategoryPlans(network, category, allPlans) {
  const container = byId('plans');
  if (!container) return;
  const plans = allPlans.filter(plan => normalizeText(plan.data_type || 'Regular') === category);
  container.replaceChildren();
  const flowHeader = document.createElement('div');
  flowHeader.className = 'data-flow-heading';
  const changeNetwork = document.createElement('button');
  changeNetwork.type = 'button';
  changeNetwork.className = 'back-to-categories';
  changeNetwork.textContent = '← Change network';
  changeNetwork.addEventListener('click', () => {
    container.replaceChildren(Object.assign(document.createElement('p'), { textContent: 'Select a network to view plans.' }));
    const networkGrid = byId('dataNetworkGrid');
    if (networkGrid) networkGrid.style.display = '';
  });
  flowHeader.appendChild(changeNetwork);
  container.appendChild(flowHeader);

  const title = document.createElement('h3');
  title.className = 'data-plan-category-title';
  title.textContent = `${network} · ${category}`;
  container.appendChild(title);

  const grid = document.createElement('div');
  grid.className = 'data-plans-grid';
  plans.forEach(plan => {
    const price = parsePrice(plan.price);
    const mappedNetwork = ({ MTN: 'MTN56TFD', Airtel: 'AIRYU78TFD', Glo: 'GLO536TFD' })[network];
    const mapped = Boolean(mappedNetwork && plan.abs_network_id === mappedNetwork && plan.abs_plan_id);
    const card = document.createElement('article');
    card.className = 'data-plan-card';
    const name = document.createElement('h4');
    name.textContent = normalizeText(plan.data_size || 'Data Plan');
    const validity = document.createElement('p');
    validity.textContent = `Validity: ${normalizeText(plan.validity || 'Not specified')}`;
    const cost = document.createElement('strong');
    cost.className = 'data-plan-price';
    cost.textContent = formatMoney(price || 0);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'data-plan-select-button';
    button.textContent = mapped ? 'Select plan' : 'Unavailable';
    button.disabled = !mapped || !price;
    button.addEventListener('click', () => showDataPurchasePortal(network, category, plan));
    card.append(name, validity, cost, button);
    grid.appendChild(card);
  });
  container.appendChild(grid);
}

function showDataPurchasePortal(network, category, plan) {
  const container = byId('plans');
  if (!container) return;
  const price = parsePrice(plan.price);
  container.replaceChildren();

  const back = document.createElement('button');
  back.type = 'button';
  back.className = 'back-to-categories';
  back.textContent = '← Back to data plans';
  back.addEventListener('click', () => showPlans(network).then(() => {
    if (category) {
      // Return directly to the selected plan category when it is available.
      const heading = container.querySelector('.data-flow-heading');
      if (heading) {
        const categoryButtons = [...container.querySelectorAll('.data-category-button')];
        const match = categoryButtons.find(button => button.textContent === category);
        if (match) match.click();
      }
    }
  }));

  const portal = document.createElement('section');
  portal.className = 'data-number-portal';
  const eyebrow = document.createElement('span');
  eyebrow.className = 'data-portal-eyebrow';
  eyebrow.textContent = 'ORDER DETAILS';
  const title = document.createElement('h3');
  title.textContent = 'Where should we send your data?';
  const intro = document.createElement('p');
  intro.textContent = 'Confirm your selected bundle and enter the recipient phone number.';
  const summary = document.createElement('div');
  summary.className = 'data-order-summary';
  summary.innerHTML = `<span>${network} · ${normalizeText(plan.data_size || 'Data Plan')}</span><strong>${formatMoney(price)}</strong><small>Validity: ${normalizeText(plan.validity || 'Not specified')}</small>`;
  const label = document.createElement('label');
  label.htmlFor = 'dataPurchasePhone';
  label.textContent = 'Recipient phone number';
  const input = document.createElement('input');
  input.id = 'dataPurchasePhone';
  input.type = 'tel';
  input.inputMode = 'numeric';
  input.autocomplete = 'tel-national';
  input.maxLength = 11;
  input.placeholder = '08012345678';
  input.setAttribute('aria-describedby', 'dataPurchaseMessage dataSandboxNotice');
  const message = document.createElement('p');
  message.id = 'dataPurchaseMessage';
  message.className = 'data-purchase-message';
  message.setAttribute('aria-live', 'polite');
  const notice = document.createElement('small');
  notice.id = 'dataSandboxNotice';
  notice.className = 'data-sandbox-notice';
  notice.textContent = 'Your wallet is charged only after you proceed. Processing orders must not be submitted a second time.';
  const proceed = document.createElement('button');
  proceed.type = 'button';
  proceed.className = 'data-proceed-button';
  proceed.textContent = 'Proceed to Buy Data';
  proceed.addEventListener('click', () => buyData(price, plan, proceed));
  portal.append(eyebrow, title, intro, summary, label, input, message, notice, proceed);
  container.append(back, portal);
  input.focus({ preventScroll: true });
  portal.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function buyData(amount, plan, button) {
  const phone = normalizeText(byId('dataPurchasePhone')?.value);
  const messageId = 'dataPurchaseMessage';
  const cost = parsePrice(amount);

  if (!/^0\d{10}$/.test(phone)) {
    setMessage(messageId, 'Enter a valid 11-digit Nigerian phone number.', true);
    byId('dataPurchasePhone')?.focus();
    return;
  }
  if (!cost || !Number.isFinite(cost)) {
    setMessage(messageId, 'This data plan has an invalid price.', true);
    return;
  }

  const user = await getCurrentUser();
  if (!user) {
    setMessage(messageId, 'Please log in before buying a data plan.', true);
    showLogin();
    return;
  }

  const originalText = button?.textContent || 'Proceed to Buy Data';
  const requestId = `GEMME-ABS-DATA-${crypto.randomUUID()}`;

  try {
    if (button) { button.disabled = true; button.textContent = 'Submitting secure order...'; }
    setMessage(messageId, 'Checking your wallet and submitting the data order securely. Please do not tap again.');

    const { data: sessionData, error: sessionError } = await supabaseClient.auth.getSession();
    if (sessionError) throw sessionError;
    let session = sessionData?.session;
    if (!session) throw new Error('Please log in again.');

    if (!session.access_token && session.refresh_token) {
      const refreshed = await supabaseClient.auth.refreshSession();
      if (refreshed.error) throw refreshed.error;
      session = refreshed.data?.session;
    }
    if (!session?.access_token) throw new Error('Your login session has expired. Please log in again.');

    const { data, error } = await supabaseClient.functions.invoke('abs-api', {
      body: {
        action: 'data_purchase',
        plan_id: Number(plan.id),
        mobile_number: phone,
        request_id: requestId
      },
      headers: { Authorization: `Bearer ${session.access_token}` }
    });

    if (error) {
      console.error('ABS data purchase request error:', error);
      const httpStatus = error.context?.status;
      const detail = httpStatus === 401
        ? 'Your login could not be verified. Please log out and log in again.'
        : 'The purchase response could not be confirmed. Do not repeat it until its status is checked.';
      setMessage(messageId, `${detail} Reference: ${requestId}`, true);
      if (httpStatus !== 401 && button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Awaiting status — do not repeat'; }
      return;
    }

    const status = String(data?.provider_status || data?.status || 'unknown').toLowerCase();
    const reference = data?.request_id || requestId;
    if (data?.sandbox === true) {
      setMessage(messageId,
        `${data?.message || 'ABS sandbox response received.'} Status: ${status}. Reference: ${reference}. This was a sandbox request; no customer wallet was debited and no live data was delivered.`,
        !data?.success
      );
      return;
    }
    if (data?.success === true && status === 'successful') {
      setMessage(messageId, `Data purchase successful. ${data.message || ''} Reference: ${reference}. Your Gemmestores wallet has been charged.`, false);
      if (button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Purchase successful'; }
      return;
    }
    if (data?.pending === true || ['processing','unknown','pending'].includes(status)) {
      setMessage(messageId, `Your data purchase is ${status}. Reference: ${reference}. Do not submit this order again. Status updates will be reconciled through ABS or Admin.`, true);
      if (button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Order pending — do not repeat'; }
      return;
    }
    setMessage(messageId,
      `${data?.error || data?.message || 'ABS did not confirm the data purchase.'} Status: ${status}. Reference: ${reference}. Check the transaction status before trying again.`,
      true
    );
  } catch (error) {
    console.error('ABS data purchase error:', error);
    setMessage(messageId,
      `${error?.message || 'The ABS data purchase could not be confirmed.'} Check the purchase reference before trying again.`,
      true
    );
  } finally {
    if (button && button.dataset.absLocked !== 'true') { button.disabled = false; button.textContent = originalText; }
  }
}

// ---------------------------------------------------------
// AIRTIME
// ---------------------------------------------------------
function selectAirtimeNetwork(network) {
  selectedAirtimeNetwork = network;
  confirmedAirtimeQuote = null;
  const form = byId('airtimeForm');
  if (form) form.style.display = 'block';
  if (byId('airtimeNetworkTitle')) byId('airtimeNetworkTitle').textContent = `${network} Airtime`;
  setMessage('airtimeMessage', '');
  const purchaseButton = byId('absAirtimePurchaseButton');
  if (purchaseButton) purchaseButton.hidden = true;
  ['airtimePhone','airtimeAmount'].forEach(id => {
    const input = byId(id);
    if (input && input.dataset.absQuoteListener !== 'ready') {
      input.dataset.absQuoteListener = 'ready';
      input.addEventListener('input', () => {
        confirmedAirtimeQuote = null;
        const liveButton = byId('absAirtimePurchaseButton');
        if (liveButton) liveButton.hidden = true;
      });
    }
  });
  form?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function showAirtimePurchaseButton() {
  const message = byId('airtimeMessage');
  const form = byId('airtimeForm');
  if (!message || !form) return;
  let button = byId('absAirtimePurchaseButton');
  if (!button) {
    button = document.createElement('button');
    button.id = 'absAirtimePurchaseButton';
    button.type = 'button';
    button.className = 'airtime-continue-button';
    button.style.cssText = 'display:block;width:100%;margin-top:12px;padding:13px 16px;border:0;border-radius:10px;background:#4f1bb5;color:#fff;font-weight:700;cursor:pointer;';
    button.textContent = 'Buy Airtime Now';
    button.addEventListener('click', runLiveAirtimePurchase);
    message.insertAdjacentElement('afterend', button);
  }
  button.hidden = false;
}

async function runLiveAirtimePurchase() {
  const phone = normalizeText(byId('airtimePhone')?.value);
  const amount = Number(byId('airtimeAmount')?.value);
  const network = normalizeText(selectedAirtimeNetwork);
  const button = byId('absAirtimePurchaseButton');
  if (!network || !/^0\d{10}$/.test(phone) || !Number.isSafeInteger(amount) || amount < 50) {
    setMessage('airtimeMessage', 'Please check the network, 11-digit phone number and amount (minimum ₦50).', true);
    return;
  }
  if (!confirmedAirtimeQuote || confirmedAirtimeQuote.network !== network || confirmedAirtimeQuote.phone !== phone || confirmedAirtimeQuote.amount !== amount) {
    setMessage('airtimeMessage', 'The details have changed since the quote. Tap Continue to check the price again before purchasing.', true);
    if (button) button.hidden = true;
    return;
  }
  const user = await getCurrentUser();
  if (!user) { setMessage('airtimeMessage', 'Please log in before buying airtime.', true); showLogin(); return; }

  const requestId = `GEMME-ABS-AIRTIME-${crypto.randomUUID()}`;
  try {
    if (button) { button.disabled = true; button.textContent = 'Processing Airtime...'; }
    setMessage('airtimeMessage', 'Submitting your airtime order. Please do not close this page or tap again.');
    const { data: sessionData, error: sessionError } = await supabaseClient.auth.getSession();
    if (sessionError) throw sessionError;
    let session = sessionData?.session;
    if (!session) throw new Error('Please log in again.');
    if (!session.access_token && session.refresh_token) {
      const refreshed = await supabaseClient.auth.refreshSession();
      if (refreshed.error) throw refreshed.error;
      session = refreshed.data?.session;
    }
    if (!session?.access_token) throw new Error('Your login session has expired. Please log in again.');

    const { data, error } = await supabaseClient.functions.invoke('abs-api', {
      body: { action: 'airtime_purchase', network, phone, amount, request_id: requestId },
      headers: { Authorization: `Bearer ${session.access_token}` }
    });
    if (error) {
      const statusCode = error.context?.status;
      setMessage('airtimeMessage', statusCode === 401
        ? 'Your login session could not be verified. Please log in again.'
        : `The airtime result could not be confirmed. Do not submit again until checked. Reference: ${requestId}.`, true);
      if (statusCode !== 401 && button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Awaiting status — do not repeat'; }
      return;
    }
    const status = String(data?.provider_status || data?.status || 'unknown').toLowerCase();
    const reference = data?.request_id || requestId;
    if (data?.sandbox === true) {
      setMessage('airtimeMessage', `ABS sandbox response: ${status}. Reference: ${reference}. No Gemmestores wallet debit or live airtime delivery occurred.`, !data?.success);
      return;
    }
    if (data?.success === true && status === 'successful') {
      setMessage('airtimeMessage', `Airtime recharge successful. ${formatMoney(amount)} was sent to ${phone}. Gemmestores wallet charge: ${formatMoney(data.customer_charge ?? amount - 1)}. Reference: ${reference}.`, false);
      if (button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Airtime successful'; button.hidden = true; }
      return;
    }
    if (data?.pending === true || ['processing','unknown','pending'].includes(status)) {
      setMessage('airtimeMessage', `Your airtime recharge is ${status}. Reference: ${reference}. Do not submit it again. Status updates will be reconciled through ABS or Admin.`, true);
      if (button) { button.dataset.absLocked = 'true'; button.disabled = true; button.textContent = 'Order pending — do not repeat'; }
      return;
    }
    setMessage('airtimeMessage', `${data?.error || data?.message || 'ABS did not confirm the airtime recharge.'} Status: ${status}. Reference: ${reference}. Check status before retrying.`, true);
  } catch (error) {
    console.error('ABS airtime purchase error:', error);
    setMessage('airtimeMessage', `The airtime result could not be confirmed. Check the reference before trying again: ${requestId}.`, true);
  } finally {
    if (button && !button.hidden && button.dataset.absLocked !== 'true') { button.disabled = false; button.textContent = 'Buy Airtime Now'; }
  }
}

async function prepareAirtimePurchase() {
  const phone = normalizeText(byId('airtimePhone')?.value);
  const amount = Number(byId('airtimeAmount')?.value);
  const network = normalizeText(selectedAirtimeNetwork);

  if (!network) { setMessage('airtimeMessage', 'Please select a network.', true); return; }
  if (!/^0\d{10}$/.test(phone)) { setMessage('airtimeMessage', 'Enter a valid 11-digit Nigerian phone number.', true); return; }
  if (!Number.isSafeInteger(amount) || amount < 50) { setMessage('airtimeMessage', 'Enter an amount of at least ₦50.', true); return; }

  const form = byId('airtimeForm');
  const button = form?.querySelector('.airtime-continue-button');
  const originalButtonText = button?.textContent || 'Continue';

  confirmedAirtimeQuote = null;
  const existingPurchaseButton = byId('absAirtimePurchaseButton');
  if (existingPurchaseButton) existingPurchaseButton.hidden = true;
  try {
    if (button) {
      button.disabled = true;
      button.textContent = 'Checking quote...';
    }
    setMessage('airtimeMessage', 'Verifying your login and checking the Airtime price...');

    // Read the current signed-in Supabase session. Refresh it once if needed.
    const { data: sessionData, error: sessionError } = await supabaseClient.auth.getSession();
    if (sessionError) throw sessionError;

    let session = sessionData?.session;
    if (!session) {
      setMessage('airtimeMessage', 'Please log in to check the Airtime price.', true);
      return;
    }

    if (!session.access_token && session.refresh_token) {
      const refreshed = await supabaseClient.auth.refreshSession();
      if (refreshed.error) throw refreshed.error;
      session = refreshed.data?.session;
    }

    if (!session?.access_token) {
      setMessage('airtimeMessage', 'Your login session has expired. Please log in again.', true);
      return;
    }

    const { data, error } = await supabaseClient.functions.invoke('abs-api', {
      body: {
        action: 'airtime_quote',
        network,
        phone,
        amount
      },
      headers: {
        Authorization: `Bearer ${session.access_token}`
      }
    });

    if (error) {
      console.error('ABS Airtime quote request failed:', error);
      const status = error.context?.status;
      if (status === 401) {
        setMessage('airtimeMessage', 'Your login could not be verified. Please log out and log in again.', true);
      } else {
        setMessage('airtimeMessage', 'We could not check the Airtime price right now. Please try again.', true);
      }
      return;
    }

    if (!data?.success || data.action !== 'airtime_quote') {
      setMessage('airtimeMessage', data?.error || 'ABS could not provide an Airtime quote. Please try again.', true);
      return;
    }

    const faceValue = Number(data.airtime_value);
    const customerCharge = Number(data.customer_charge);
    const quoteMatchesRequest =
      data.network === network &&
      data.phone === phone &&
      faceValue === amount &&
      customerCharge === amount - 1 &&
      data.currency === 'NGN' &&
      typeof data.network_trackid === 'string' &&
      data.network_trackid.length > 0 &&
      typeof data.purchase_enabled === 'boolean';

    if (!quoteMatchesRequest) {
      setMessage('airtimeMessage', 'The Airtime quote could not be verified. No charge has been made.', true);
      return;
    }

    if (data.purchase_enabled === true) {
      confirmedAirtimeQuote = { network, phone, amount };
      setMessage('airtimeMessage', `Quote confirmed: ${formatMoney(faceValue)} airtime. Gemmestores wallet charge: ${formatMoney(customerCharge)}. Tap Buy Airtime Now to confirm the purchase.`, false);
      showAirtimePurchaseButton();
    } else {
      setMessage('airtimeMessage', `Quote confirmed: ${formatMoney(faceValue)} airtime. Customer charge would be ${formatMoney(customerCharge)}. Live Airtime is not enabled yet; no wallet debit has occurred.`, false);
    }
  } catch (error) {
    console.error('Airtime quote error:', error);
    setMessage('airtimeMessage', 'We could not verify your login or check the Airtime price. Please try again.', true);
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = originalButtonText;
    }
  }
}

// ---------------------------------------------------------
// BILLS — electricity meter verification is mandatory before purchase
// ---------------------------------------------------------
function clearVerifiedElectricityMeter(message = '') {
  verifiedElectricityMeter = null;
  const details = byId('meterVerifiedDetails');
  if (details) { details.hidden = true; details.textContent = ''; }
  const verifyMessage = byId('meterVerificationMessage');
  if (verifyMessage) { verifyMessage.textContent = message; verifyMessage.className = 'form-message'; }
  const purchaseFields = byId('billPurchaseFields');
  if (purchaseFields && byId('billForm')?.dataset.billType === 'electricity') purchaseFields.hidden = true;
}

function backToBillServices() {
  const grid = document.querySelector('#bills .service-grid');
  const form = byId('billForm');
  const broadband = byId('broadbandPage');
  if (grid) grid.style.display = 'grid';
  if (form) form.style.display = 'none';
  if (broadband) broadband.style.display = 'none';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetBroadbandSubpages() {
  ['broadbandCategoryArea', 'broadbandPlanArea', 'broadbandAccountArea'].forEach(id => {
    const el = byId(id); if (el) el.hidden = true;
  });
  const status = byId('broadbandStatus');
  if (status) status.textContent = '';
}

function backToBroadbandProviders() {
  resetBroadbandSubpages();
  const grid = byId('broadbandProviderGrid'); if (grid) grid.style.display = 'grid';
  const title = byId('broadbandPageTitle'); if (title) title.textContent = 'Choose an Internet Provider';
  const subtitle = byId('broadbandPageSubtitle'); if (subtitle) subtitle.textContent = 'Select a provider to view available broadband plans.';
}

function backToBroadbandCategories() {
  const plans = byId('broadbandPlanArea'); if (plans) plans.hidden = true;
  const account = byId('broadbandAccountArea'); if (account) account.hidden = true;
  const categories = byId('broadbandCategoryArea'); if (categories) categories.hidden = false;
}

function backToBroadbandPlans() {
  const account = byId('broadbandAccountArea'); if (account) account.hidden = true;
  const plans = byId('broadbandPlanArea'); if (plans) plans.hidden = false;
}

let selectedBroadbandProvider = '';
let selectedBroadbandCategory = '';
let selectedBroadbandPlans = [];

function broadbandCategoryForPlan(provider, plan) {
  const text = `${plan.data_size || ''} ${plan.data_type || ''}`.toLowerCase();
  if (text.includes('fibre') || text.includes('fiber')) return 'FibreX Plans';
  if (text.includes('odu')) return 'ODU Plans';
  if (text.includes('router')) return 'Router Plans';
  if (text.includes('mifi') || text.includes('mi-fi')) return 'MiFi Plans';
  if (text.includes('unlimited') || text.includes('gold') || text.includes('diamond') || text.includes('ruby') || text.includes('silver')) return 'Unlimited Plans';
  return provider === 'MTN' ? 'Other Broadband Plans' : 'Other Plans';
}

async function selectBroadbandProvider(provider) {
  selectedBroadbandProvider = provider;
  selectedBroadbandCategory = '';
  selectedBroadbandPlans = [];
  resetBroadbandSubpages();
  const providerGrid = byId('broadbandProviderGrid'); if (providerGrid) providerGrid.style.display = 'none';
  const title = byId('broadbandPageTitle'); if (title) title.textContent = `${provider} Broadband`;
  const subtitle = byId('broadbandPageSubtitle'); if (subtitle) subtitle.textContent = 'Choose a plan category to continue.';
  const status = byId('broadbandStatus');
  if (provider === 'Smile' || provider === 'Spectranet' || provider === 'Starlink') {
    const categoryTitle = byId('broadbandCategoryTitle');
    if (categoryTitle) categoryTitle.textContent = `${provider} service information`;
    const categoryGrid = byId('broadbandCategoryGrid');
    if (categoryGrid) categoryGrid.replaceChildren();
    if (byId('broadbandCategoryArea')) byId('broadbandCategoryArea').hidden = false;
    if (status) status.textContent = `${provider} is listed on Gemmestores, but its provider catalogue and purchase integration have not been connected yet. No plans or prices are being displayed until they are verified.`;
    return;
  }

  if (status) status.textContent = 'Loading available plans…';
  try {
    const { data, error } = await supabaseClient
      .from('data_plans')
      .select('id,network,data_type,data_size,validity,price,active,abs_network_id,abs_plan_id')
      .eq('network', provider)
      .eq('data_type', 'Broadband Internet')
      .eq('active', true)
      .order('price', { ascending: true });
    if (error) throw error;
    selectedBroadbandPlans = (data || []).filter(plan => Number(plan.price) > 0 && plan.abs_plan_id);
    const groups = new Map();
    selectedBroadbandPlans.forEach(plan => {
      const category = broadbandCategoryForPlan(provider, plan);
      if (!groups.has(category)) groups.set(category, []);
      groups.get(category).push(plan);
    });
    const order = provider === 'MTN'
      ? ['ODU Plans', 'Router Plans', 'FibreX Plans', 'Unlimited Plans', 'Other Broadband Plans']
      : ['ODU Plans', 'Router Plans', 'MiFi Plans', 'Unlimited Plans', 'Other Plans'];
    const categories = [...groups.keys()].sort((a, b) => order.indexOf(a) - order.indexOf(b));
    const grid = byId('broadbandCategoryGrid');
    if (grid) {
      grid.replaceChildren();
      categories.forEach(category => {
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'broadband-category-card';
        const strong = document.createElement('strong'); strong.textContent = category;
        const small = document.createElement('small'); small.textContent = `${groups.get(category).length} available plan${groups.get(category).length === 1 ? '' : 's'}`;
        button.append(strong, small);
        button.addEventListener('click', () => showBroadbandPlans(category));
        grid.appendChild(button);
      });
    }
    const categoryTitle = byId('broadbandCategoryTitle');
    if (categoryTitle) categoryTitle.textContent = `${provider} plan categories`;
    if (status) status.textContent = categories.length ? '' : `No active ${provider} broadband plans were found in the Gemmestores catalogue.`;
    byId('broadbandCategoryArea').hidden = false;
  } catch (error) {
    console.error('Unable to load broadband plans:', error);
    if (status) status.textContent = 'We could not load broadband plans right now. Please try again later.';
  }
}

function showBroadbandPlans(category) {
  selectedBroadbandCategory = category;
  const plans = selectedBroadbandPlans.filter(plan => broadbandCategoryForPlan(selectedBroadbandProvider, plan) === category);
  const grid = byId('broadbandPlanGrid');
  if (!grid) return;
  grid.replaceChildren();
  plans.forEach(plan => {
    const card = document.createElement('article'); card.className = 'broadband-plan-card';
    const name = document.createElement('strong'); name.textContent = plan.data_size || 'Broadband Plan';
    const validity = document.createElement('span'); validity.textContent = plan.validity ? `${plan.validity} validity` : 'Validity not specified';
    const price = document.createElement('b'); price.textContent = formatMoney(Number(plan.price));
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Select Plan';
    button.addEventListener('click', () => selectBroadbandPlan(plan));
    card.append(name, validity, price, button); grid.appendChild(card);
  });
  const title = byId('broadbandPlanTitle'); if (title) title.textContent = `${selectedBroadbandProvider} — ${category}`;
  byId('broadbandCategoryArea').hidden = true;
  byId('broadbandPlanArea').hidden = false;
  const status = byId('broadbandStatus'); if (status) status.textContent = '';
}

function selectBroadbandPlan(plan) {
  const title = byId('broadbandSelectedPlan');
  if (title) title.textContent = `${selectedBroadbandProvider} · ${plan.data_size} · ${formatMoney(Number(plan.price))}`;
  const account = byId('broadbandAccountNumber'); if (account) account.value = '';
  byId('broadbandPlanArea').hidden = true;
  byId('broadbandAccountArea').hidden = false;
  const status = byId('broadbandStatus'); if (status) status.textContent = 'Plan selected. Purchase is not enabled until the provider integration is completed.';
}

function showBillForm(type) {
  const grid = document.querySelector('#bills .service-grid');
  const form = byId('billForm');
  const broadband = byId('broadbandPage');
  if (grid) grid.style.display = 'none';
  if (form) form.style.display = 'none';
  if (broadband) broadband.style.display = 'none';

  if (type === 'internet') {
    if (broadband) broadband.style.display = 'block';
    backToBroadbandProviders();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }

  const title = byId('billTitle'); const provider = byId('billProvider');
  if (!form || !title || !provider) return;
  const options = {
    electricity: ['Pay Electricity Bill', [
      ['AEDC','Abuja Electricity Distribution Company'], ['BEDC','Benin Electricity Distribution Company'], ['EEDC','Enugu Electricity Distribution Company'],
      ['EKEDC','Eko Electricity Distribution Company'], ['IBEDC','Ibadan Electricity Distribution Company'], ['IKEDC','Ikeja Electric Distribution Company'],
      ['JED','Jos Electricity Distribution Company'], ['KEDCO','Kano Electricity Distribution Company'], ['KAEDCO','Kaduna Electric'],
      ['PHED','Port Harcourt Electricity Distribution Company'], ['ABA','Aba Electricity Distribution Company'], ['YEDC','Yola Electricity Distribution Company']
    ]],
    cable: ['Pay Cable TV', [['DSTV','DStv'],['GOtv','GOtv'],['Startimes','Startimes']]],
    education: ['Education & Exam PINs', [['JAMB','JAMB'],['WAEC','WAEC']]]
  };
  const selected = options[type]; if (!selected) { if (grid) grid.style.display = 'grid'; return; }
  title.textContent = selected[0];
  provider.replaceChildren();
  const first = document.createElement('option'); first.value = ''; first.textContent = 'Select provider'; provider.appendChild(first);
  selected[1].forEach(([value, label]) => { const option = document.createElement('option'); option.value = value; option.textContent = label; provider.appendChild(option); });
  const electricityFields = byId('electricityVerificationFields');
  if (electricityFields) electricityFields.hidden = type !== 'electricity';
  const meterPanel = byId('meterVerificationPanel');
  if (meterPanel) meterPanel.hidden = type !== 'electricity';
  const meterLabel = byId('customerNumberLabel');
  const numberInput = byId('customerNumber');
  if (meterLabel) meterLabel.textContent = type === 'electricity' ? 'Meter Number' : (type === 'cable' ? 'Smartcard / IUC Number' : 'Customer / Profile Number (where required)');
  if (numberInput) numberInput.placeholder = type === 'electricity' ? 'Enter electricity meter number' : (type === 'cable' ? 'Enter Smartcard / IUC number' : 'Enter customer number');
  form.dataset.billType = type;
  const purchaseFields = byId('billPurchaseFields');
  if (purchaseFields) purchaseFields.hidden = type === 'electricity';
  clearVerifiedElectricityMeter(type === 'electricity' ? 'Enter the meter details, then verify the meter before continuing.' : '');
  form.style.display = 'block';
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  setMessage('billMessage', type === 'electricity'
    ? 'Electricity meter verification is required before a purchase can proceed. Payment is not connected yet.'
    : 'Bill payment integration is not connected yet. No payment will be taken from this form.');

  if (provider.dataset.verifyListener !== 'ready') {
    provider.dataset.verifyListener = 'ready';
    provider.addEventListener('change', () => clearVerifiedElectricityMeter('Provider changed. Verify the meter again.'));
  }
  if (numberInput && numberInput.dataset.verifyListener !== 'ready') {
    numberInput.dataset.verifyListener = 'ready';
    numberInput.addEventListener('input', () => clearVerifiedElectricityMeter('Meter/customer number changed. Verify again before purchase.'));
  }
  const meterType = byId('meterType');
  if (meterType && meterType.dataset.verifyListener !== 'ready') {
    meterType.dataset.verifyListener = 'ready';
    meterType.addEventListener('change', () => clearVerifiedElectricityMeter('Meter type changed. Verify the meter again.'));
  }
}

async function verifyElectricityMeter() {
  const provider = normalizeText(byId('billProvider')?.value);
  const meterNumber = normalizeText(byId('customerNumber')?.value);
  const meterType = normalizeText(byId('meterType')?.value);
  if (!provider) { setMessage('meterVerificationMessage', 'Select your electricity distribution company first.', true); return; }
  if (!/^[0-9]{6,20}$/.test(meterNumber)) { setMessage('meterVerificationMessage', 'Enter a valid meter number (6–20 digits).', true); return; }
  if (!['prepaid', 'postpaid'].includes(meterType.toLowerCase())) { setMessage('meterVerificationMessage', 'Select Prepaid or Postpaid.', true); return; }

  const button = byId('verifyMeterButton');
  if (button) { button.disabled = true; button.textContent = 'Verifying…'; }
  clearVerifiedElectricityMeter('Contacting the secure meter verification service…');
  try {
    // This must be implemented as a Supabase Edge Function. Provider credentials
    // must remain server-side; never put VTpass or other provider secrets in this JS.
    const { data, error } = await supabaseClient.functions.invoke('verify-electricity-meter', {
      body: { provider, meter_number: meterNumber, meter_type: meterType.toLowerCase() }
    });
    if (error) throw error;
    const verified = data?.verified === true;
    const customerName = normalizeText(data?.customer_name || data?.customerName);
    const returnedMeter = normalizeText(data?.meter_number || data?.meterNumber || meterNumber);
    if (!verified || !customerName || returnedMeter !== meterNumber) {
      throw new Error(data?.message || 'The provider did not confirm this meter and its customer name.');
    }
    verifiedElectricityMeter = {
      provider, meterNumber, meterType: meterType.toLowerCase(), customerName,
      address: normalizeText(data?.address || data?.customer_address || ''),
      verifiedAt: Date.now()
    };
    const details = byId('meterVerifiedDetails');
    if (details) {
      details.textContent = `Verified ✓  ${customerName}${verifiedElectricityMeter.address ? ' · ' + verifiedElectricityMeter.address : ''} · ${meterType} · ${provider}`;
      details.hidden = false;
    }
    const purchaseFields = byId('billPurchaseFields');
    if (purchaseFields) purchaseFields.hidden = false;
    setMessage('meterVerificationMessage', `Meter verified successfully for ${customerName}. You may continue to the purchase step.`, false);
  } catch (error) {
    console.error('Electricity meter verification failed:', error);
    clearVerifiedElectricityMeter('Meter verification is not available or the meter could not be confirmed. No purchase is allowed. Connect and deploy the secure verify-electricity-meter Supabase Edge Function, then try again.');
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Verify Meter'; }
  }
}

function payBill() {
  const type = byId('billForm')?.dataset.billType || '';
  const provider = normalizeText(byId('billProvider')?.value);
  const customerNumber = normalizeText(byId('customerNumber')?.value);
  const amount = Number(byId('billAmount')?.value);
  if (!provider) { setMessage('billMessage', 'Please select a bill provider.', true); return; }
  if (!customerNumber) { setMessage('billMessage', 'Please enter your customer, meter or IUC number.', true); return; }
  if (!Number.isFinite(amount) || amount <= 0) { setMessage('billMessage', 'Please enter a valid amount.', true); return; }
  if (type === 'electricity') {
    const meterType = normalizeText(byId('meterType')?.value).toLowerCase();
    const verified = verifiedElectricityMeter &&
      verifiedElectricityMeter.provider === provider &&
      verifiedElectricityMeter.meterNumber === customerNumber &&
      verifiedElectricityMeter.meterType === meterType &&
      Date.now() - Number(verifiedElectricityMeter.verifiedAt || 0) < 10 * 60 * 1000;
    if (!verified) {
      setMessage('billMessage', 'You must successfully verify this electricity meter before purchase. Please press Verify Meter first.', true);
      return;
    }
    setMessage('billMessage', `Meter verified for ${verifiedElectricityMeter.customerName}. Amount: ${formatMoney(amount)}. Electricity payment processing is not connected yet, so no charge or token has been issued.`);
    return;
  }
  setMessage('billMessage', `Details checked: ${provider}, ${customerNumber}, ${formatMoney(amount)}. Payment is not connected; no charge has been made.`);
}

// ---------------------------------------------------------
// PRODUCT CATALOGUE RENDERING
// ---------------------------------------------------------
function productCardMarkup(product, type) {
  const pending = product.price == null || product.price <= 0;
  const image = product.image
    ? `<img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy">`
    : `<div class="image-coming-soon">${type === 'laptop' ? '💻' : '📱'} <span>Image coming soon</span></div>`;
  const specs = [product.variant, product.specs, product.modelCode ? `Model code: ${product.modelCode}` : ''].filter(Boolean).join(' · ');
  if (type === 'accessory') {
    return `<article class="accessory-card" data-product-key="${escapeHtml(product.key)}">
      <div class="accessory-image">${image}</div><div class="accessory-details">
      <span class="accessory-brand">${escapeHtml(product.brand)}</span><h3>${escapeHtml(product.name)}</h3>
      <p class="accessory-specs">${escapeHtml(specs)}</p>
      <div class="accessory-price">${pending ? 'Price to be confirmed' : formatMoney(product.price)}</div>
      <div class="accessory-action-buttons"><button type="button" class="accessory-view-details" data-action="details">View Details</button>
      ${pending ? '<button type="button" class="accessory-add-to-cart" data-action="request">Request Price</button>' : '<button type="button" class="accessory-add-to-cart" data-action="add">Add to Cart</button>'}</div></div></article>`;
  }
  return `<article class="phone-product-card" data-product-key="${escapeHtml(product.key)}">
    <div class="phone-image-placeholder">${image}</div><div class="phone-product-info">
    <span class="phone-brand">${escapeHtml(product.brand)}</span><h3>${escapeHtml(product.name)}</h3>
    <p class="phone-variant">${escapeHtml(displayPhoneVariant(product))}</p><p class="phone-specs">${escapeHtml(specs)}</p>
    <p class="phone-price">${pending ? 'Price to be confirmed' : formatMoney(product.price)}</p>
    <div class="product-card-actions"><button type="button" data-action="details">View Details</button>
    ${pending ? '<button type="button" class="add-to-cart-button" data-action="request">Request Availability</button>' : '<button type="button" class="add-to-cart-button" data-action="add">Add to Cart</button>'}</div></div></article>`;
}

function phoneProductGroupCardMarkup(group) {
  // Choose the smallest available RAM/storage configuration by default.
  // Never select a larger configuration merely because its price is lower.
  const variantOptions = sortPhoneVariants(group.products);
  const defaultProduct = variantOptions[0] || group.products[0];
  const isMultiVariant = variantOptions.length > 1;
  const imageFallback = defaultProduct.imageFallback || group.imageFallback || '';
  const imageUrl = defaultProduct.image || group.image || imageFallback;
  const image = imageUrl
    ? `<img src="${escapeHtml(imageUrl)}" ${imageFallback && imageFallback !== imageUrl ? `data-fallback-src="${escapeHtml(imageFallback)}"` : ''} alt="${escapeHtml(group.name)} product image" loading="lazy">`
    : `<div class="image-coming-soon">📱 <span>Product image coming soon</span></div>`;
  const variantSummary = displayPhoneVariant(defaultProduct);
  const priceText = parsePrice(defaultProduct.price) === null
    ? 'Price to be confirmed'
    : formatMoney(defaultProduct.price);
  const hasRamChoices = variantOptions.some(product => /^\s*\d+(?:\.\d+)?\s*GB\s*\//i.test(String(product.variant || '')));
  const variantChoiceLabel = hasRamChoices ? 'Choose RAM / Storage' : 'Choose Storage';
  const variantSelector = isMultiVariant
    ? `<div class="phone-card-variant-wrap">
        <label class="phone-card-variant-label" for="variant-${escapeHtml(group.key)}">${variantChoiceLabel}</label>
        <select class="phone-card-variant-select" id="variant-${escapeHtml(group.key)}" aria-label="${variantChoiceLabel} for ${escapeHtml(group.name)}">
          ${variantOptions.map(product => `<option value="${escapeHtml(product.key)}" ${product.key === defaultProduct.key ? 'selected' : ''}>${escapeHtml(displayPhoneVariant(product) || 'Configuration')}</option>`).join('')}
        </select>
      </div>`
    : '';
  const pending = parsePrice(defaultProduct.price) === null;
  const allPending = !variantOptions.some(product => parsePrice(product.price) !== null);
  const specs = group.specs || (defaultProduct.modelCode ? `Model code: ${defaultProduct.modelCode}` : '');
  return `<article class="phone-product-card phone-model-card" data-product-group-key="${escapeHtml(group.key)}" data-product-key="${escapeHtml(defaultProduct.key)}">
    <div class="phone-image-placeholder">${image}</div>
    <div class="phone-product-info">
      <span class="phone-brand">${escapeHtml(group.brand)}</span>
      <h3>${escapeHtml(group.name)}</h3>
      ${!isMultiVariant && variantSummary ? `<p class="phone-variant">${escapeHtml(variantSummary)}</p>` : ''}
      ${variantSelector}
      <p class="phone-specs">${escapeHtml(specs)}</p>
      <p class="phone-price" data-group-price>${escapeHtml(priceText)}</p>
      <div class="product-card-actions">
        <button type="button" data-action="details">View Details</button>
        <button type="button" class="add-to-cart-button" data-action="${allPending || pending ? 'request' : 'add'}">${allPending || pending ? 'Request Availability' : 'Add to Cart'}</button>
      </div>
    </div>
  </article>`;
}

function updatePhoneModelCardSelection(card, group, selectedProduct) {
  if (!card || !group || !selectedProduct) return;
  card.dataset.productKey = selectedProduct.key;
  const variantSummary = card.querySelector('.phone-variant');
  if (variantSummary) { variantSummary.textContent = displayPhoneVariant(selectedProduct); variantSummary.style.display = displayPhoneVariant(selectedProduct) ? '' : 'none'; }
  const priceElement = card.querySelector('[data-group-price]');
  if (priceElement) {
    priceElement.textContent = parsePrice(selectedProduct.price) === null
      ? 'Price to be confirmed'
      : formatMoney(selectedProduct.price);
  }
  const actionButton = card.querySelector('.add-to-cart-button');
  if (actionButton) {
    const needsRequest = parsePrice(selectedProduct.price) === null;
    actionButton.dataset.action = needsRequest ? 'request' : 'add';
    actionButton.textContent = needsRequest ? 'Request Availability' : 'Add to Cart';
    actionButton.disabled = false;
  }
  const imageWrap = card.querySelector('.phone-image-placeholder');
  const selectedImage = selectedProduct.image || group.image || selectedProduct.imageFallback || group.imageFallback || '';
  const selectedFallback = selectedProduct.imageFallback || group.imageFallback || '';
  if (imageWrap && selectedImage) {
    let imageElement = imageWrap.querySelector('img');
    if (!imageElement) {
      imageElement = document.createElement('img');
      imageElement.alt = `${group.name} product image`;
      imageElement.loading = 'lazy';
      imageWrap.replaceChildren(imageElement);
      attachProductImageFallbacks(imageWrap);
    }
    imageElement.dataset.fallbackSrc = selectedFallback && selectedFallback !== selectedImage ? selectedFallback : '';
    delete imageElement.dataset.fallbackTried;
    imageWrap.dataset.failedImage = '';
    imageElement.alt = `${group.name} product image`;
    if (imageElement.getAttribute('src') !== selectedImage) imageElement.src = selectedImage;
  } else if (imageWrap && !selectedImage) {
    imageWrap.replaceChildren();
    const placeholder = document.createElement('div');
    placeholder.className = 'image-coming-soon';
    placeholder.textContent = '📱 Product image coming soon';
    imageWrap.appendChild(placeholder);
  }
}

let catalogRendered = false;
function renderProductCatalog() {
  const phones = byId('phoneProducts');
  const tablets = byId('tabletProducts');
  const earbuds = byId('accessoryGrid');
  const accessories = byId('accessoryProducts');
  const laptops = byId('laptopProducts');
  if (!phones || !tablets || !earbuds || !accessories || !laptops) {
    console.error('Phone Store catalogue containers were not found. Check the category grids in index.html.');
    return;
  }

  phones.innerHTML = getPhoneProductGroups('phones').map(phoneProductGroupCardMarkup).join('');
  tablets.innerHTML = getPhoneProductGroups('tablets').map(phoneProductGroupCardMarkup).join('');
  earbuds.innerHTML = EARBUD_PRODUCTS.map(product => productCardMarkup(product, 'accessory')).join('');
  accessories.innerHTML = OTHER_ACCESSORIES.map(product => productCardMarkup(product, 'accessory')).join('');
  laptops.innerHTML = LAPTOP_PRODUCTS.map(product => productCardMarkup(product, 'laptop')).join('');
  catalogRendered = true;
  enableProductCardEvents();
  updatePhoneCart();
}

function categoryElements() {
  return {
    phones: [byId('phoneProducts')].filter(Boolean),
    tablets: [byId('tabletProducts')].filter(Boolean),
    accessories: [byId('accessoryGrid'), byId('accessoryProducts')].filter(Boolean),
    laptops: [byId('laptopProducts')].filter(Boolean)
  };
}

function showPhoneCategory(category) {
  const valid = ['phones', 'tablets', 'accessories', 'laptops'];
  currentPhoneCategory = valid.includes(category) ? category : 'phones';
  if (!catalogRendered) renderProductCatalog();
  const groups = categoryElements();
  Object.entries(groups).forEach(([key, elements]) => {
    elements.forEach(grid => { grid.style.display = key === currentPhoneCategory ? 'grid' : 'none'; });
  });

  const buttons = {
    phones: byId('smartphonesCategoryButton'),
    tablets: byId('tabletsCategoryButton'),
    accessories: byId('accessoriesCategoryButton'),
    laptops: byId('laptopsCategoryButton')
  };
  Object.entries(buttons).forEach(([key, button]) => button?.classList.toggle('active', key === currentPhoneCategory));

  const search = byId('productSearch');
  if (search) search.value = '';
  Object.values(groups).flat().forEach(group => {
    group.querySelectorAll('[data-product-key],[data-product-group-key]').forEach(card => { card.style.display = ''; });
  });
  if (byId('noProductsMessage')) byId('noProductsMessage').style.display = 'none';
}

function searchProducts() {
  if (!catalogRendered) renderProductCatalog();
  const term = normalizeText(byId('productSearch')?.value).toLowerCase();
  const groups = [
    { id: 'phones', elements: [byId('phoneProducts')].filter(Boolean) },
    { id: 'tablets', elements: [byId('tabletProducts')].filter(Boolean) },
    { id: 'accessories', elements: [byId('accessoryGrid'), byId('accessoryProducts')].filter(Boolean) },
    { id: 'laptops', elements: [byId('laptopProducts')].filter(Boolean) }
  ];
  let matchesTotal = 0;
  groups.forEach(group => {
    let matches = 0;
    group.elements.forEach(element => {
      element.querySelectorAll('[data-product-group-key],[data-product-key]').forEach(card => {
        const productGroupKey = card.dataset.productGroupKey;
        const searchable = productGroupKey
          ? getGroupSearchText(getPhoneProductGroupByKey(productGroupKey) || { brand: '', name: '', products: [] })
          : (() => {
              const product = getProductByKey(card.dataset.productKey);
              return product ? [product.brand, product.name, product.variant, product.specs, product.modelCode, product.colors].join(' ').toLowerCase() : card.textContent.toLowerCase();
            })();
        const match = !term || searchable.includes(term);
        card.style.display = match ? '' : 'none';
        if (match) { matches++; matchesTotal++; }
      });
    });
    group.elements.forEach(element => {
      element.style.display = (group.id === currentPhoneCategory || (Boolean(term) && matches > 0)) ? 'grid' : 'none';
    });
  });
  const noResults = byId('noProductsMessage');
  if (noResults) noResults.style.display = term && matchesTotal === 0 ? 'block' : 'none';
}

function attachProductImageFallbacks(container) {
  container.querySelectorAll('img').forEach(img => {
    if (img.dataset.fallbackReady === 'true') return;
    img.dataset.fallbackReady = 'true';
    img.addEventListener('error', () => {
      const wrapper = img.closest('.phone-image-placeholder, .accessory-image, .product-details-image');
      if (!wrapper) return;
      const fallbackUrl = img.dataset.fallbackSrc || '';
      if (fallbackUrl && !img.dataset.fallbackTried && img.src !== fallbackUrl) {
        img.dataset.fallbackTried = 'true';
        img.src = fallbackUrl;
        return;
      }
      wrapper.dataset.failedImage = img.currentSrc || img.src;
      const fallback = document.createElement('div');
      fallback.className = 'image-coming-soon';
      fallback.textContent = '📱 Product image unavailable';
      img.replaceWith(fallback);
    });
  });
}

function enableProductCardEvents() {
  document.querySelectorAll('#phoneProducts,#tabletProducts,#accessoryGrid,#accessoryProducts,#laptopProducts').forEach(container => {
    attachProductImageFallbacks(container);
    if (container.dataset.eventsReady === 'true') return;
    container.dataset.eventsReady = 'true';

    container.addEventListener('change', event => {
      const selector = event.target.closest('.phone-card-variant-select');
      if (!selector) return;
      const card = selector.closest('[data-product-group-key]');
      if (!card) return;
      const group = getPhoneProductGroupByKey(card.dataset.productGroupKey);
      const selectedProduct = group?.products.find(item => item.key === selector.value);
      updatePhoneModelCardSelection(card, group, selectedProduct);
      attachProductImageFallbacks(card);
    });

    container.addEventListener('click', event => {
      // A storage dropdown should remain usable without opening the product popup.
      if (event.target.closest('.phone-card-variant-select')) return;
      const groupCard = event.target.closest('[data-product-group-key]');
      const card = groupCard || event.target.closest('[data-product-key]');
      if (!card) return;
      const productGroup = groupCard ? getPhoneProductGroupByKey(groupCard.dataset.productGroupKey) : null;
      const selectedKey = productGroup
        ? (card.querySelector('.phone-card-variant-select')?.value || card.dataset.productKey)
        : card.dataset.productKey;
      const product = productGroup
        ? (productGroup.products.find(item => item.key === selectedKey) || productGroup.products[0])
        : getProductByKey(selectedKey);
      if (!product) return;

      const actionButton = event.target.closest('[data-action]');
      if (actionButton) {
        event.preventDefault();
        event.stopPropagation();
        if (actionButton.dataset.action === 'details') {
          productGroup ? openProductDetails(productGroup.key, product.key) : openProductDetails(product.key);
        }
        if (actionButton.dataset.action === 'add') {
          if (product.colors) {
            productGroup ? openProductDetails(productGroup.key, product.key) : openProductDetails(product.key);
          } else {
            const added = addProductToCart(product.key, 1);
            if (added) showAddedButtonFeedback(actionButton);
          }
        }
        if (actionButton.dataset.action === 'request') requestProductFromCard(product);
        return;
      }
      const image = event.target.closest('img');
      if (image) {
        openProductImage(product.image || productGroup?.image || image.src, productGroup?.name || product.name);
        return;
      }
      productGroup ? openProductDetails(productGroup.key, product.key) : openProductDetails(product.key);
    });
  });
}

// ---------------------------------------------------------
// PRODUCT DETAILS / IMAGE VIEWER / COLOURS / REVIEWS
// ---------------------------------------------------------
function closeProductDetails() {
  byId('productDetailsPopup')?.remove();
  document.body.style.overflow = '';
  activeProduct = null;
  activeProductKey = '';
}

function openProductDetails(productKey, preferredVariantKey = '') {
  const group = getPhoneProductGroupByKey(productKey);
  const preferredVariant = group?.products.find(item => item.key === preferredVariantKey);
  const product = group
    ? (preferredVariant || group.products.filter(item => parsePrice(item.price) !== null)
        .sort((a, b) => parsePrice(a.price) - parsePrice(b.price))[0] || group.products[0])
    : getProductByKey(productKey);
  if (!product) return;
  closeProductDetails();
  let selectedProduct = product;
  activeProduct = selectedProduct;
  activeProductKey = selectedProduct.key;

  const popup = document.createElement('div'); popup.id = 'productDetailsPopup';
  popup.className = 'product-details-popup';
  const overlay = document.createElement('div'); overlay.className = 'product-details-overlay';
  overlay.addEventListener('click', event => { if (event.target === overlay) closeProductDetails(); });
  const box = document.createElement('div'); box.className = 'product-details-box'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true');
  const close = document.createElement('button'); close.type = 'button'; close.className = 'product-details-close'; close.textContent = '×'; close.setAttribute('aria-label', 'Close product details'); close.addEventListener('click', closeProductDetails);
  const imageWrap = document.createElement('div'); imageWrap.className = 'product-details-image';
  const content = document.createElement('div'); content.className = 'product-details-content';
  const brand = document.createElement('span'); brand.className = 'product-details-brand'; brand.textContent = group?.brand || product.brand;
  const title = document.createElement('h2'); title.textContent = group?.name || product.name;
  const variantLabel = document.createElement('label');
  variantLabel.className = 'product-variant-select-label';
  const variantsHaveRam = (group?.products || [product]).some(item => /^\s*\d+(?:\.\d+)?\s*GB\s*\//i.test(String(item.variant || '')));
  variantLabel.textContent = group && group.products.length > 1
    ? (variantsHaveRam ? 'Choose RAM / Storage' : 'Choose Storage')
    : 'Selected option';
  const variantSelect = document.createElement('select'); variantSelect.id = 'productDetailVariant'; variantSelect.className = 'product-variant-select';
  const variant = document.createElement('p'); variant.className = 'product-details-variant';
  const price = document.createElement('div'); price.className = 'product-details-price';
  const specsTitle = document.createElement('h3'); specsTitle.textContent = 'Specifications';
  const specs = document.createElement('p');
  const colourTitle = document.createElement('h3'); colourTitle.textContent = 'Available Colours';
  const colourWrap = document.createElement('div'); colourWrap.className = 'product-colour-options';
  const quantityLabel = document.createElement('label'); quantityLabel.htmlFor = 'productDetailQuantity'; quantityLabel.textContent = 'Quantity';
  const quantity = document.createElement('input'); quantity.type = 'number'; quantity.id = 'productDetailQuantity'; quantity.value = '1'; quantity.min = '1'; quantity.max = '10';
  const add = document.createElement('button'); add.type = 'button'; add.className = 'product-details-add-button';
  const requestButton = document.createElement('button'); requestButton.type = 'button'; requestButton.className = 'product-details-request-button'; requestButton.textContent = 'Request this product';
  requestButton.style.display = 'none';

  const variants = group?.products || [product];
  if (variants.length > 1) {
    variants.forEach(optionProduct => {
      const option = document.createElement('option');
      option.value = optionProduct.key;
      option.textContent = displayPhoneVariant(optionProduct) || 'Configuration';
      variantSelect.appendChild(option);
    });
    variantSelect.value = selectedProduct.key;
  }

  function updateProductImage() {
    const imageUrl = selectedProduct.image || group?.image || selectedProduct.imageFallback || group?.imageFallback || '';
    const fallbackUrl = selectedProduct.imageFallback || group?.imageFallback || '';
    imageWrap.replaceChildren();
    if (imageUrl) {
      const img = document.createElement('img');
      img.src = imageUrl;
      img.alt = `${group?.name || selectedProduct.name} product image`;
      img.dataset.fallbackSrc = fallbackUrl && fallbackUrl !== imageUrl ? fallbackUrl : '';
      img.addEventListener('click', () => openProductImage(img.currentSrc || img.src, group?.name || selectedProduct.name));
      img.addEventListener('error', () => {
        if (img.dataset.fallbackSrc && !img.dataset.fallbackTried && img.src !== img.dataset.fallbackSrc) {
          img.dataset.fallbackTried = 'true';
          img.src = img.dataset.fallbackSrc;
          return;
        }
        imageWrap.replaceChildren();
        const placeholder = document.createElement('div');
        placeholder.className = 'image-coming-soon';
        placeholder.textContent = '📱 Product image unavailable';
        imageWrap.appendChild(placeholder);
      });
      imageWrap.appendChild(img);
    } else {
      const placeholder = document.createElement('div'); placeholder.className = 'product-details-placeholder';
      placeholder.textContent = selectedProduct.category === 'laptops' ? '💻' : '📱';
      imageWrap.appendChild(placeholder);
    }
  }

  function updateColourOptions() {
    colourWrap.replaceChildren();
    const available = String(selectedProduct.colors || '').split(',').map(value => value.trim()).filter(Boolean);
    colourTitle.style.display = available.length ? '' : 'none';
    colourWrap.style.display = available.length ? 'flex' : 'none';
    available.forEach(color => {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'product-colour-button';
      button.textContent = color; button.dataset.colour = color;
      button.addEventListener('click', () => {
        colourWrap.querySelectorAll('button').forEach(item => item.classList.remove('selected'));
        button.classList.add('selected');
      });
      colourWrap.appendChild(button);
    });
  }

  function updateSelectedVariant() {
    if (variantSelect.options.length) {
      selectedProduct = variants.find(item => item.key === variantSelect.value) || selectedProduct;
    }
    activeProduct = selectedProduct;
    activeProductKey = selectedProduct.key;
    variant.textContent = displayPhoneVariant(selectedProduct);
    variant.style.display = displayPhoneVariant(selectedProduct) ? '' : 'none';
    price.textContent = parsePrice(selectedProduct.price) === null ? 'Price to be confirmed' : formatMoney(selectedProduct.price);
    specs.textContent = [selectedProduct.specs, selectedProduct.modelCode ? `Model code: ${selectedProduct.modelCode}` : ''].filter(Boolean).join(' ');
    add.disabled = parsePrice(selectedProduct.price) === null;
    add.textContent = add.disabled ? 'Price to be confirmed' : '🛒 Add to Cart';
    requestButton.style.display = add.disabled ? '' : 'none';
    updateProductImage();
    updateColourOptions();
    loadProductReviews(selectedProduct, reviewSection);
  }

  if (variants.length > 1) {
    variantSelect.addEventListener('change', updateSelectedVariant);
    content.append(brand, title, variantLabel, variantSelect, variant, price, specsTitle, specs, colourTitle, colourWrap);
  } else {
    content.append(brand, title, variant, price, specsTitle, specs, colourTitle, colourWrap);
  }

  add.addEventListener('click', () => {
    const count = Number(quantity.value);
    if (!Number.isInteger(count) || count < 1 || count > 10) { alert('Please select a quantity between 1 and 10.'); return; }
    const selectedColour = colourWrapSelected(content);
    if (selectedProduct.colors && !selectedColour) { alert('Please choose a colour before adding this product.'); return; }
    const added = addProductToCart(selectedProduct.key, count, selectedColour);
    if (added) {
      add.textContent = 'Added ✓';
      add.classList.add('product-added-confirmation');
      window.setTimeout(closeProductDetails, 450);
    }
  });
  requestButton.addEventListener('click', () => { closeProductDetails(); requestProductFromCard(selectedProduct); });

  content.append(quantityLabel, quantity, add, requestButton);
  const reviewSection = document.createElement('section'); reviewSection.className = 'product-review-section';
  reviewSection.innerHTML = '<h3>Customer Ratings &amp; Reviews</h3><p class="review-loading">Loading reviews...</p>';
  content.appendChild(reviewSection);
  updateProductImage();
  box.append(close, imageWrap, content); overlay.appendChild(box); popup.appendChild(overlay); document.body.appendChild(popup);
  document.body.style.overflow = 'hidden';
  updateSelectedVariant();
}

function requestProductFromCard(product) {
  const modelInput = byId('requestModelName');
  if (modelInput) modelInput.value = `${product.brand} ${product.name} ${displayPhoneVariant(product)}`.trim();
  byId('productRequestPanel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  modelInput?.focus({ preventScroll: true });
}

function colourWrapSelected(content) { return content.querySelector('.product-colour-button.selected')?.dataset.colour || ''; }

function openProductImage(imageUrl, productName) {
  if (!imageUrl) return;
  byId('accessoryImageViewer')?.remove();
  const viewer = document.createElement('div'); viewer.id = 'accessoryImageViewer'; viewer.className = 'accessory-image-viewer';
  const overlay = document.createElement('div'); overlay.className = 'accessory-image-overlay'; overlay.addEventListener('click', event => { if (event.target === overlay) closeAccessoryImage(); });
  const close = document.createElement('button'); close.type = 'button'; close.className = 'accessory-image-close'; close.textContent = '×'; close.setAttribute('aria-label', 'Close image'); close.addEventListener('click', closeAccessoryImage);
  const box = document.createElement('div'); box.className = 'accessory-image-viewer-box';
  const img = document.createElement('img'); img.src = imageUrl; img.alt = productName;
  const caption = document.createElement('p'); caption.textContent = productName;
  box.append(img, caption); overlay.append(close, box); viewer.appendChild(overlay); document.body.appendChild(viewer); document.body.style.overflow = 'hidden';
}
function closeAccessoryImage() { byId('accessoryImageViewer')?.remove(); document.body.style.overflow = byId('productDetailsPopup') ? 'hidden' : ''; }

async function loadProductReviews(product, container) {
  try {
    const { data, error } = await supabaseClient.from('product_reviews').select('rating,review_text,customer_name,created_at').eq('product_key', product.key).order('created_at', { ascending: false }).limit(30);
    if (error) throw error;
    const reviews = data || [];
    const total = reviews.length;
    const average = total ? reviews.reduce((sum, row) => sum + Number(row.rating || 0), 0) / total : 0;
    container.replaceChildren();
    const heading = document.createElement('h3'); heading.textContent = 'Customer Ratings & Reviews';
    const summary = document.createElement('p'); summary.className = 'review-summary'; summary.textContent = total ? `${average.toFixed(1)} / 5 stars · ${total} review${total === 1 ? '' : 's'}` : 'No customer reviews yet.';
    container.append(heading, summary);
    const list = document.createElement('div'); list.className = 'product-review-list';
    reviews.forEach(row => {
      const item = document.createElement('article'); item.className = 'product-review-item';
      const top = document.createElement('strong'); top.textContent = `${'★'.repeat(Math.max(0, Math.min(5, Number(row.rating))))}${'☆'.repeat(5 - Math.max(0, Math.min(5, Number(row.rating))))} · ${row.customer_name || 'Customer'}`;
      const text = document.createElement('p'); text.textContent = row.review_text || '';
      const date = document.createElement('small'); date.textContent = row.created_at ? new Date(row.created_at).toLocaleDateString('en-NG') : '';
      item.append(top, text, date); list.appendChild(item);
    });
    if (total) container.appendChild(list);
    const form = document.createElement('form'); form.className = 'product-review-form';
    form.innerHTML = `<label for="reviewRating">Your rating</label><select id="reviewRating" required><option value="">Choose stars</option><option value="5">★★★★★ — Excellent</option><option value="4">★★★★☆ — Very good</option><option value="3">★★★☆☆ — Good</option><option value="2">★★☆☆☆ — Fair</option><option value="1">★☆☆☆☆ — Poor</option></select><label for="reviewText">Your review</label><textarea id="reviewText" rows="3" maxlength="1000" placeholder="Share your experience with this product" required></textarea><button type="submit" class="form-button">Submit Review</button><p class="review-message" role="status" aria-live="polite"></p>`;
    form.addEventListener('submit', event => submitProductReview(event, product, form));
    container.appendChild(form);
  } catch (error) {
    console.warn('Product reviews are not configured yet:', error.message || error);
    container.replaceChildren();
    const heading = document.createElement('h3'); heading.textContent = 'Customer Ratings & Reviews';
    const note = document.createElement('p'); note.textContent = 'Review storage is not set up yet. Run the supplied Gemmestores product-features SQL setup in Supabase to enable shared customer reviews.';
    container.append(heading, note);
  }
}

async function submitProductReview(event, product, form) {
  event.preventDefault();
  const message = form.querySelector('.review-message');
  const rating = Number(form.querySelector('#reviewRating')?.value);
  const reviewText = normalizeText(form.querySelector('#reviewText')?.value);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5 || !reviewText) { if (message) message.textContent = 'Choose a star rating and enter a review.'; return; }
  const user = await getCurrentUser();
  if (!user) { pendingService = 'phones'; showLogin(); return; }
  const button = form.querySelector('button[type="submit"]'); if (button) { button.disabled = true; button.textContent = 'Submitting...'; }
  try {
    const { error } = await supabaseClient.from('product_reviews').insert({
      product_key: product.key, product_name: product.name, user_id: user.id,
      customer_name: normalizeText(user.user_metadata?.full_name || user.email?.split('@')[0] || 'Customer'),
      rating, review_text: reviewText
    });
    if (error) throw error;
    await loadProductReviews(product, form.parentElement);
  } catch (error) {
    console.error('Review submit error:', error);
    if (message) message.textContent = error.code === '23505' ? 'You have already reviewed this product.' : (error.message || 'Unable to save your review. Check the Supabase SQL setup.');
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Submit Review'; }
  }
}

// ---------------------------------------------------------
// CART — one product row with separate quantities per colour
// ---------------------------------------------------------
function cartItemName(product) {
  const visibleVariant = displayPhoneVariant(product);
  return `${product.name}${visibleVariant ? ' — ' + visibleVariant : ''}`;
}

function getColourEntries(item) {
  const map = item?.colourQuantities;
  if (!map || typeof map !== 'object' || Array.isArray(map)) return [];
  return Object.entries(map).filter(([colour, quantity]) => normalizeText(colour) && Number(quantity) > 0);
}

function syncCartItemQuantity(item) {
  const entries = getColourEntries(item);
  if (entries.length) item.quantity = entries.reduce((sum, [, quantity]) => sum + Number(quantity), 0);
  return Math.max(0, Number(item.quantity) || 0);
}

function getPhoneCartGroupKey(product) {
  const brandKey = canonicalPhoneBrand(product.brand, product.name);
  return `${brandKey}-${normalizeModelToken(product.name)}-${product.category || 'phones'}`;
}

function getVariantCartQuantity(line) {
  const colours = getColourEntries(line);
  return colours.length ? colours.reduce((sum, [, quantity]) => sum + Number(quantity || 0), 0) : Math.max(0, Number(line?.quantity) || 0);
}

function syncVariantGroupCartEntry(entry) {
  if (!entry || !Array.isArray(entry.variantItems)) return 0;
  entry.variantItems = entry.variantItems.filter(line => getVariantCartQuantity(line) > 0);
  entry.quantity = entry.variantItems.reduce((sum, line) => sum + getVariantCartQuantity(line), 0);
  return entry.quantity;
}

function getCartEntryQuantity(entry) {
  if (Array.isArray(entry?.variantItems)) return syncVariantGroupCartEntry(entry);
  return getColourEntries(entry).length ? syncCartItemQuantity(entry) : Math.max(0, Number(entry?.quantity) || 0);
}

function getCartEntryTotal(entry) {
  if (Array.isArray(entry?.variantItems)) {
    return entry.variantItems.reduce((sum, line) => sum + (parsePrice(line.price) || 0) * getVariantCartQuantity(line), 0);
  }
  return (parsePrice(entry?.price) || 0) * getCartEntryQuantity(entry);
}

function addProductToCart(productKey, quantity = 1, colour = '') {
  const product = getProductByKey(productKey);
  if (!product || product.price == null || product.price <= 0) {
    alert('The price for this product has not been confirmed yet.');
    return false;
  }
  const count = Number(quantity);
  if (!Number.isInteger(count) || count < 1 || count > 10) {
    alert('Please select a quantity between 1 and 10.');
    return false;
  }

  const availableColours = String(product.colors || '').split(',').map(value => value.trim()).filter(Boolean);
  let selectedColour = '';
  if (availableColours.length) {
    selectedColour = availableColours.find(value => value.toLowerCase() === normalizeText(colour).toLowerCase()) || '';
    if (!selectedColour) {
      const group = PHONE_PRODUCTS.includes(product) ? getPhoneProductGroupByKey(getPhoneCartGroupKey(product)) : null;
      group ? openProductDetails(group.key, product.key) : openProductDetails(product.key);
      alert('Please choose a colour before adding this product.');
      return false;
    }
  }

  // Phones/tablets are grouped by model; each RAM/storage option stays as a
  // separate priced line inside that one model entry in the shopping cart.
  if (PHONE_PRODUCTS.includes(product)) {
    const groupKey = getPhoneCartGroupKey(product);
    let entry = phoneCart.find(item => item.groupKey === groupKey && Array.isArray(item.variantItems));
    if (!entry) {
      entry = { cartKey: groupKey, groupKey, productKey: '', name: `${displayPhoneBrand(product.brand, product.name)} ${product.name}`, brand: product.brand, variantItems: [], quantity: 0 };
      phoneCart.push(entry);
    }
    let line = entry.variantItems.find(item => item.productKey === product.key);
    if (!line) {
      line = { productKey: product.key, variant: displayPhoneVariant(product), price: product.price, quantity: 0 };
      entry.variantItems.push(line);
    }
    line.price = product.price;
    line.variant = displayPhoneVariant(product);
    const modelQuantity = entry.variantItems.reduce((sum, item) => sum + getVariantCartQuantity(item), 0);
    if (modelQuantity + count > 10) {
      alert('Maximum total quantity for one model is 10 across all RAM/storage options.');
      return false;
    }
    if (selectedColour) {
      if (!line.colourQuantities || typeof line.colourQuantities !== 'object' || Array.isArray(line.colourQuantities)) line.colourQuantities = {};
      line.colourQuantities[selectedColour] = (Number(line.colourQuantities[selectedColour]) || 0) + count;
      line.quantity = getVariantCartQuantity(line);
    } else {
      line.quantity = (Number(line.quantity) || 0) + count;
    }
    syncVariantGroupCartEntry(entry);
    updatePhoneCart();
    showCartNotice(`${count} ${count === 1 ? 'item' : 'items'} added: ${entry.name}${line.variant ? ' · ' + line.variant : ''}${selectedColour ? ' · ' + selectedColour : ''}`);
    return true;
  }

  // Accessories and laptops remain individual cart entries.
  let item = phoneCart.find(entry => entry.productKey === product.key || entry.cartKey === product.key);
  if (!item) {
    item = { cartKey: product.key, productKey: product.key, name: cartItemName(product), price: product.price, quantity: 0, brand: product.brand };
    phoneCart.push(item);
  }
  item.price = product.price;
  item.name = cartItemName(product);
  if (selectedColour) {
    if (!item.colourQuantities || typeof item.colourQuantities !== 'object' || Array.isArray(item.colourQuantities)) item.colourQuantities = {};
    const nextTotal = getCartEntryQuantity(item) + count;
    if (nextTotal > 10) { alert('Maximum total quantity for this product is 10 across all colours.'); return false; }
    item.colourQuantities[selectedColour] = (Number(item.colourQuantities[selectedColour]) || 0) + count;
    syncCartItemQuantity(item);
  } else {
    const nextTotal = getCartEntryQuantity(item) + count;
    if (nextTotal > 10) { alert('Maximum quantity for one product is 10.'); return false; }
    item.quantity = nextTotal;
  }
  updatePhoneCart();
  showCartNotice(`${count} ${count === 1 ? 'item' : 'items'} added: ${item.name}${selectedColour ? ' · ' + selectedColour : ''}`);
  return true;
}

function buyPhone(productName, amount) {
  const wanted = normalizeKey(productName);
  const match = PHONE_PRODUCTS.find(product => normalizeKey(`${product.brand} ${product.name} ${product.variant}`) === wanted)
    || PHONE_PRODUCTS.find(product => normalizeKey(`${product.brand} ${product.name}`) === wanted)
    || PHONE_PRODUCTS.find(product => normalizeKey(product.name) === wanted)
    || PHONE_PRODUCTS.find(product => wanted && normalizeKey(`${product.brand} ${product.name} ${product.variant}`).includes(wanted));
  if (!match || match.price == null) {
    alert(`${productName}\n\nThe price has not been confirmed yet.`);
    return;
  }
  addProductToCart(match.key, 1);
}

function addAccessoryToCart(productName, amount, quantity = 1) {
  const match = [...EARBUD_PRODUCTS, ...OTHER_ACCESSORIES].find(product => normalizeKey(product.name) === normalizeKey(productName));
  if (match) { addProductToCart(match.key, quantity); return; }
  const price = parsePrice(amount);
  if (!price) { alert(`The price for ${productName} has not been confirmed yet.`); return; }
  const key = normalizeKey(productName);
  const existing = phoneCart.find(item => item.cartKey === key);
  const count = Number(quantity);
  if (!Number.isInteger(count) || count < 1 || count > 10) { alert('Please select a quantity between 1 and 10.'); return; }
  if (existing) {
    if (syncCartItemQuantity(existing) + count > 10) { alert('Maximum quantity for one product is 10.'); return; }
    existing.quantity = syncCartItemQuantity(existing) + count;
  } else phoneCart.push({ cartKey: key, productKey: '', name: normalizeText(productName), price, quantity: count });
  updatePhoneCart();
  showCartNotice(`${productName} added to your cart.`);
}

function showAddedButtonFeedback(button) {
  if (!button || button.disabled) return;
  const originalText = button.textContent;
  button.textContent = 'Added ✓';
  button.classList.add('product-added-confirmation');
  button.disabled = true;
  window.setTimeout(() => {
    button.textContent = originalText;
    button.classList.remove('product-added-confirmation');
    button.disabled = false;
  }, 1100);
}

function showCartNotice(message) {
  const cart = byId('phoneCart');
  if (!cart) return;
  let notice = byId('cartStatusMessage');
  if (!notice) {
    notice = document.createElement('p');
    notice.id = 'cartStatusMessage';
    notice.className = 'cart-status-message';
    notice.setAttribute('role', 'status');
    cart.insertBefore(notice, cart.querySelector('#cartItems'));
  }
  notice.textContent = message;
}

function updatePhoneCart() {
  const cartItems = byId('cartItems');
  const cartCount = byId('cartCount');
  const cartTotal = byId('cartTotal');
  if (!cartItems) return;
  if (!phoneCart.length) {
    cartItems.innerHTML = '<p class="empty-cart">Your cart is empty.</p>';
    if (cartCount) cartCount.textContent = '0';
    if (cartTotal) cartTotal.textContent = '₦0';
    return;
  }

  cartItems.replaceChildren();
  let total = 0;
  let count = 0;
  phoneCart.forEach((item, index) => {
    const row = document.createElement('div');
    row.className = Array.isArray(item.variantItems) ? 'cart-item cart-model-group-item' : 'cart-item';
    const info = document.createElement('div'); info.className = 'cart-product-info';
    const name = document.createElement('strong'); name.textContent = item.name; info.appendChild(name);

    if (Array.isArray(item.variantItems)) {
      row.appendChild(info);
      const groupSubtotal = getCartEntryTotal(item);
      const groupQuantity = getCartEntryQuantity(item);
      total += groupSubtotal; count += groupQuantity;
      item.variantItems.forEach(line => {
        const variantRow = document.createElement('div'); variantRow.className = 'cart-variant-line';
        const details = document.createElement('div'); details.className = 'cart-variant-details';
        const variantName = document.createElement('strong'); variantName.textContent = line.variant || 'Standard configuration';
        const unit = document.createElement('small'); unit.textContent = `${formatMoney(line.price)} each`;
        details.append(variantName, unit);
        const controls = document.createElement('div'); controls.className = 'quantity-controls cart-variant-quantity';
        const colourEntries = getColourEntries(line);
        if (colourEntries.length) {
          const colourBox = document.createElement('div'); colourBox.className = 'cart-variant-colours';
          colourEntries.forEach(([colour, colourQuantity]) => {
            const colourRow = document.createElement('div'); colourRow.className = 'cart-variant-colour-row';
            const label = document.createElement('span'); label.textContent = `${colour}:`;
            const minus = document.createElement('button'); minus.type = 'button'; minus.textContent = '−';
            minus.setAttribute('aria-label', `Decrease ${colour} quantity for ${item.name}`);
            minus.addEventListener('click', () => changeCartVariantColourQuantity(index, line.productKey, colour, -1));
            const quantityText = document.createElement('span'); quantityText.textContent = String(colourQuantity);
            const plus = document.createElement('button'); plus.type = 'button'; plus.textContent = '+';
            plus.setAttribute('aria-label', `Increase ${colour} quantity for ${item.name}`);
            plus.addEventListener('click', () => changeCartVariantColourQuantity(index, line.productKey, colour, 1));
            colourRow.append(label, minus, quantityText, plus); colourBox.appendChild(colourRow);
          });
          controls.appendChild(colourBox);
        } else {
          const minus = document.createElement('button'); minus.type = 'button'; minus.textContent = '−';
          minus.setAttribute('aria-label', `Decrease ${line.variant} quantity`);
          minus.addEventListener('click', () => changeCartVariantQuantity(index, line.productKey, -1));
          const quantityText = document.createElement('span'); quantityText.textContent = String(getVariantCartQuantity(line));
          const plus = document.createElement('button'); plus.type = 'button'; plus.textContent = '+';
          plus.setAttribute('aria-label', `Increase ${line.variant} quantity`);
          plus.addEventListener('click', () => changeCartVariantQuantity(index, line.productKey, 1));
          controls.append(minus, quantityText, plus);
        }
        const lineTotal = document.createElement('strong'); lineTotal.className = 'cart-item-total';
        lineTotal.textContent = formatMoney((parsePrice(line.price) || 0) * getVariantCartQuantity(line));
        const removeVariant = document.createElement('button'); removeVariant.type = 'button'; removeVariant.className = 'remove-cart-item'; removeVariant.textContent = 'Remove option';
        removeVariant.addEventListener('click', () => removeCartVariant(index, line.productKey));
        variantRow.append(details, controls, lineTotal, removeVariant);
        row.appendChild(variantRow);
      });
      const groupFooter = document.createElement('div'); groupFooter.className = 'cart-model-group-footer';
      const subtotal = document.createElement('span'); subtotal.textContent = `${groupQuantity} total item${groupQuantity === 1 ? '' : 's'}`;
      const groupTotal = document.createElement('strong'); groupTotal.textContent = `Model total: ${formatMoney(groupSubtotal)}`;
      const removeModel = document.createElement('button'); removeModel.type = 'button'; removeModel.className = 'remove-cart-item'; removeModel.textContent = 'Remove model';
      removeModel.addEventListener('click', () => removeFromCart(index));
      groupFooter.append(subtotal, groupTotal, removeModel);
      // Keep the variant lines as direct children, beneath the one model heading.
      cartItems.appendChild(row);
      row.appendChild(groupFooter);
      return;
    }

    item.price = parsePrice(item.price) || 0;
    const colourEntries = getColourEntries(item);
    const quantity = colourEntries.length ? syncCartItemQuantity(item) : Math.max(1, Number(item.quantity) || 1);
    item.quantity = quantity;
    const rowTotal = item.price * quantity;
    total += rowTotal; count += quantity;
    const unit = document.createElement('p'); unit.textContent = formatMoney(item.price); info.appendChild(unit);
    const controls = document.createElement('div'); controls.className = 'cart-colour-quantities';
    if (colourEntries.length) {
      colourEntries.forEach(([colour, colourQuantity]) => {
        const colourRow = document.createElement('div'); colourRow.className = 'cart-colour-row';
        const label = document.createElement('span'); label.textContent = colour;
        const stepper = document.createElement('div'); stepper.className = 'quantity-controls';
        const minus = document.createElement('button'); minus.type = 'button'; minus.textContent = '−';
        minus.addEventListener('click', () => changeCartColourQuantity(index, colour, -1));
        const value = document.createElement('span'); value.textContent = String(colourQuantity);
        const plus = document.createElement('button'); plus.type = 'button'; plus.textContent = '+';
        plus.addEventListener('click', () => changeCartColourQuantity(index, colour, 1));
        stepper.append(minus, value, plus); colourRow.append(label, stepper); controls.appendChild(colourRow);
      });
    } else {
      const stepper = document.createElement('div'); stepper.className = 'quantity-controls';
      const minus = document.createElement('button'); minus.type = 'button'; minus.textContent = '−';
      minus.addEventListener('click', () => changeCartQuantity(index, -1));
      const value = document.createElement('span'); value.textContent = String(quantity);
      const plus = document.createElement('button'); plus.type = 'button'; plus.textContent = '+';
      plus.addEventListener('click', () => changeCartQuantity(index, 1));
      stepper.append(minus, value, plus); controls.appendChild(stepper);
    }
    const amount = document.createElement('strong'); amount.className = 'cart-item-total'; amount.textContent = formatMoney(rowTotal);
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'remove-cart-item'; remove.textContent = 'Remove';
    remove.addEventListener('click', () => removeFromCart(index));
    row.append(info, controls, amount, remove); cartItems.appendChild(row);
  });
  if (cartCount) cartCount.textContent = String(count);
  if (cartTotal) cartTotal.textContent = formatMoney(total);
}

function removeCartVariant(entryIndex, productKey) {
  const entry = phoneCart[entryIndex];
  if (!entry || !Array.isArray(entry.variantItems)) return;
  entry.variantItems = entry.variantItems.filter(line => line.productKey !== productKey);
  if (!syncVariantGroupCartEntry(entry)) phoneCart.splice(entryIndex, 1);
  updatePhoneCart();
}

function changeCartVariantQuantity(entryIndex, productKey, change) {
  const entry = phoneCart[entryIndex];
  const line = entry?.variantItems?.find(item => item.productKey === productKey);
  if (!entry || !line || getColourEntries(line).length) return;
  const next = getVariantCartQuantity(line) + Number(change);
  if (next < 1) removeCartVariant(entryIndex, productKey);
  else if (getCartEntryQuantity(entry) + Number(change) > 10) alert('Maximum total quantity for one model is 10 across all RAM/storage options.');
  else { line.quantity = next; syncVariantGroupCartEntry(entry); updatePhoneCart(); }
}

function changeCartVariantColourQuantity(entryIndex, productKey, colour, change) {
  const entry = phoneCart[entryIndex];
  const line = entry?.variantItems?.find(item => item.productKey === productKey);
  if (!entry || !line || !line.colourQuantities) return;
  const current = Number(line.colourQuantities[colour]) || 0;
  const next = current + Number(change);
  if (next < 0) return;
  if (getCartEntryQuantity(entry) + Number(change) > 10) { alert('Maximum total quantity for one model is 10 across all RAM/storage options.'); return; }
  if (next === 0) delete line.colourQuantities[colour];
  else line.colourQuantities[colour] = next;
  if (!getColourEntries(line).length) removeCartVariant(entryIndex, productKey);
  else { line.quantity = getVariantCartQuantity(line); syncVariantGroupCartEntry(entry); updatePhoneCart(); }
}

function removeFromCart(index) {
  if (index < 0 || index >= phoneCart.length) return;
  phoneCart.splice(index, 1);
  updatePhoneCart();
}

function changeCartQuantity(index, change) {
  const item = phoneCart[index];
  if (!item) return;
  if (getColourEntries(item).length) {
    const firstColour = getColourEntries(item)[0][0];
    changeCartColourQuantity(index, firstColour, change);
    return;
  }
  const next = Number(item.quantity) + Number(change);
  if (next < 1) phoneCart.splice(index, 1);
  else if (next > 10) { alert('Maximum quantity for one product is 10.'); return; }
  else item.quantity = next;
  updatePhoneCart();
}

function changeCartColourQuantity(index, colour, change) {
  const item = phoneCart[index];
  if (!item || !item.colourQuantities) return;
  const current = Number(item.colourQuantities[colour]) || 0;
  const next = current + Number(change);
  if (next < 0) return;
  if (syncCartItemQuantity(item) + Number(change) > 10) {
    alert('Maximum total quantity for this product is 10 across all colours.');
    return;
  }
  if (next === 0) delete item.colourQuantities[colour];
  else item.colourQuantities[colour] = next;
  if (!getColourEntries(item).length) phoneCart.splice(index, 1);
  else syncCartItemQuantity(item);
  updatePhoneCart();
}

function getCartCheckoutLines() {
  return phoneCart.flatMap(entry => {
    if (Array.isArray(entry.variantItems)) {
      return entry.variantItems.map(line => ({
        name: entry.name, variant: line.variant || '', price: Number(line.price) || 0,
        quantity: getVariantCartQuantity(line), productKey: line.productKey,
        colourQuantities: getColourEntries(line).length ? Object.fromEntries(getColourEntries(line)) : null
      }));
    }
    return [{
      name: entry.name, variant: '', price: Number(entry.price) || 0,
      quantity: getCartEntryQuantity(entry), productKey: entry.productKey || entry.cartKey,
      colourQuantities: getColourEntries(entry).length ? Object.fromEntries(getColourEntries(entry)) : null
    }];
  }).filter(line => line.quantity > 0);
}

function getPhoneCartTotal() {
  return phoneCart.reduce((sum, entry) => sum + getCartEntryTotal(entry), 0);
}

function formatOrderItemDescription(item) {
  const baseName = item?.name || 'Item';
  const variant = normalizeText(item?.variant || item?.configuration || '');
  const alreadyHasVariant = variant && baseName.toLowerCase().includes(variant.toLowerCase());
  const displayName = variant && !alreadyHasVariant ? `${baseName} (${variant})` : baseName;
  const colourMap = item?.colour_quantities || item?.colourQuantities;
  if (colourMap && typeof colourMap === 'object' && !Array.isArray(colourMap)) {
    const colours = Object.entries(colourMap).filter(([, quantity]) => Number(quantity) > 0).map(([colour, quantity]) => `${colour} × ${Number(quantity)}`);
    if (colours.length) return `${displayName} (${colours.join(', ')}) × ${item?.quantity || 1}`;
  }
  return `${displayName} × ${item?.quantity || 1}`;
}

function checkoutCart() {
  if (!phoneCart.length) { alert('Your cart is empty.'); return; }
  const summary = byId('checkoutItems'); const totalElement = byId('checkoutTotal');
  if (!summary || !totalElement) { alert('Checkout page is not ready.'); return; }
  summary.replaceChildren();
  const lines = getCartCheckoutLines();
  lines.forEach(item => {
    const line = document.createElement('div'); line.className = 'checkout-item';
    const config = item.variant ? ` (${item.variant})` : '';
    const colourText = item.colourQuantities ? ` · ${Object.entries(item.colourQuantities).map(([colour, qty]) => `${colour} × ${qty}`).join(', ')}` : '';
    const label = document.createElement('span'); label.textContent = `${item.name}${config} × ${item.quantity}${colourText}`;
    const amount = document.createElement('strong'); amount.textContent = formatMoney(item.price * item.quantity);
    line.append(label, amount); summary.appendChild(line);
  });
  totalElement.textContent = formatMoney(getPhoneCartTotal());
  showSection('checkout');
  if (byId('checkoutName') && !byId('checkoutName').value) getCurrentUser().then(account => {
    if (account) byId('checkoutName').value = normalizeText(account.user_metadata?.full_name || '');
  });
}

async function placeOrder() {
  if (!phoneCart.length) { alert('Your cart is empty.'); return; }
  const user = await getCurrentUser();
  if (!user) { pendingService = 'phones'; showLogin(); alert('Please log in before placing your order. Your cart will remain available.'); return; }
  const name = normalizeText(byId('checkoutName')?.value);
  const phone = normalizeText(byId('checkoutPhone')?.value);
  const address = normalizeText(byId('checkoutAddress')?.value);
  if (!name) { alert('Please enter your full name.'); return; }
  if (!/^\+?[0-9\s()-]{10,16}$/.test(phone)) { alert('Please enter a valid phone number.'); return; }
  if (!address) { alert('Please enter your delivery address.'); return; }
  const total = getPhoneCartTotal();
  if (!Number.isFinite(total) || total <= 0) { alert('The order total is invalid.'); return; }
  const trackingId = 'GEM-' + (window.crypto?.randomUUID ? crypto.randomUUID().replace(/-/g, '').slice(0, 10).toUpperCase() : Math.random().toString(36).slice(2, 12).toUpperCase());
  const orderButton = document.querySelector('#checkout .place-order-button');
  if (orderButton) { orderButton.disabled = true; orderButton.textContent = 'Placing Order...'; }
  try {
    const orderItems = getCartCheckoutLines().map(item => ({ name: item.variant ? `${item.name} (${item.variant})` : item.name, ...(item.variant ? { variant: item.variant, configuration: item.variant } : {}), quantity: item.quantity, price: item.price, product_key: item.productKey, ...(item.colourQuantities ? { colour_quantities: item.colourQuantities } : {}) }));
    const { data, error } = await supabaseClient.from('phone_orders').insert([{
      tracking_id: trackingId, user_id: user.id, customer_name: name, customer_phone: phone,
      delivery_address: address, items: orderItems, total_amount: total, status: 'Processing'
    }]).select('tracking_id,status').single();
    if (error) throw error;
    currentTrackingId = data.tracking_id || trackingId;
    try { sessionStorage.setItem('gemmestores_tracking_id', currentTrackingId); }
    catch (error) { console.warn('Unable to save tracking ID:', error); }
    phoneCart = []; updatePhoneCart();
    ['checkoutName','checkoutPhone','checkoutAddress'].forEach(id => { if (byId(id)) byId(id).value = ''; });
    if (byId('trackingInput')) byId('trackingInput').value = currentTrackingId;
    if (byId('displayTrackingId')) byId('displayTrackingId').textContent = currentTrackingId;
    showSection('tracking');
    if (byId('trackingResult')) byId('trackingResult').style.display = 'block';
    updateTrackingStatus('Processing');
    alert(`Order placed successfully!\n\nThank you, ${name}.\n\nYour Tracking ID is:\n${currentTrackingId}\n\nKeep this ID to track your delivery.`);
  } catch (error) {
    console.error('Order placement error:', error);
    alert('Unable to place your order right now. ' + (error.message || 'Please try again.'));
  } finally {
    if (orderButton) { orderButton.disabled = false; orderButton.textContent = 'Place Order'; }
  }
}

// ---------------------------------------------------------
// TRACKING — status names align with the Admin Portal
// ---------------------------------------------------------
function updateTrackingStatus(status) {
  const normalized = ORDER_STATUSES.includes(String(status || '').trim()) ? String(status).trim() : 'Processing';
  const steps = [...document.querySelectorAll('#tracking .tracking-step')];
  const lines = [...document.querySelectorAll('#tracking .tracking-line')];
  const progress = document.querySelector('#tracking .tracking-progress-bar');
  const currentText = byId('trackingCurrentStatus');
  const deliveryInfo = document.querySelector('#tracking .delivery-info');
  if (currentText) currentText.textContent = normalized;
  steps.forEach((step, index) => {
    step.classList.remove('completed','current','cancelled');
    step.querySelector('small')?.remove();
  });
  lines.forEach(line => line.classList.remove('completed-line'));
  if (normalized === 'Cancelled') {
    steps.forEach(step => step.classList.add('cancelled'));
    if (progress) { progress.style.width = '0%'; progress.style.background = '#dc2626'; progress.style.display = 'block'; }
    if (deliveryInfo) {
      const estimated = deliveryInfo.querySelectorAll('p')[1];
      if (estimated) estimated.textContent = 'Delivery stopped: this order has been cancelled.';
    }
    return;
  }
  const currentIndex = PROGRESS_STATUSES.indexOf(normalized);
  steps.forEach((step, index) => {
    if (index < currentIndex) step.classList.add('completed');
    if (index === currentIndex) {
      step.classList.add('current');
      const marker = document.createElement('small'); marker.textContent = 'Current status'; step.appendChild(marker);
    }
  });
  lines.forEach((line, index) => { if (index < currentIndex) line.classList.add('completed-line'); });
  const widths = [0, 33.333, 66.667, 100];
  if (progress) { progress.style.display = 'block'; progress.style.width = `${widths[currentIndex] ?? 0}%`; progress.style.background = '#111827'; }
  if (deliveryInfo) {
    const estimated = deliveryInfo.querySelectorAll('p')[1];
    if (estimated) estimated.textContent = 'Estimated Delivery: 2–4 business days';
  }
}

async function trackOrder() {
  const trackingInput = byId('trackingInput'); const trackingResult = byId('trackingResult');
  const trackingId = normalizeText(trackingInput?.value).toUpperCase();
  if (!trackingId) { alert('Please enter your tracking ID.'); return; }
  if (!/^GEM-[A-Z0-9-]{5,40}$/.test(trackingId)) { alert('Please check the tracking ID format and try again.'); return; }
  try {
    const { data, error } = await supabaseClient.rpc('track_phone_order', { p_tracking_id: trackingId });
    if (error) throw error;
    const order = Array.isArray(data) ? data[0] : data;
    if (!order) { if (trackingResult) trackingResult.style.display = 'none'; alert('Order not found. Please check your tracking ID.'); return; }
    currentTrackingId = order.tracking_id || trackingId;
    try { sessionStorage.setItem('gemmestores_tracking_id', currentTrackingId); }
    catch (error) { console.warn('Unable to save tracking ID:', error); }
    if (byId('displayTrackingId')) byId('displayTrackingId').textContent = currentTrackingId;
    if (trackingResult) trackingResult.style.display = 'block';
    updateTrackingStatus(order.status);
    trackingResult?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    console.error('Tracking error:', error);
    alert('Unable to track this order right now. Please check your tracking ID or contact Admin.');
  }
}

// ---------------------------------------------------------
// PRODUCT REQUEST FORM — uses the supplied SQL table
// ---------------------------------------------------------
async function submitProductRequest(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const message = byId('productRequestMessage');
  const button = byId('submitProductRequestButton');
  const user = await getCurrentUser();
  if (!user) { pendingService = 'phones'; setMessage('productRequestMessage', 'Please log in before sending a product request.', true); showLogin(); return; }
  const payload = {
    user_id: user.id,
    customer_name: normalizeText(byId('requestCustomerName')?.value),
    customer_phone: normalizeText(byId('requestCustomerPhone')?.value),
    model_name: normalizeText(byId('requestModelName')?.value),
    preferred_specs: normalizeText(byId('requestPreferredSpecs')?.value),
    customer_note: normalizeText(byId('requestNote')?.value)
  };
  if (!payload.customer_name || !/^\+?[0-9\s()-]{10,16}$/.test(payload.customer_phone) || !payload.model_name) {
    setMessage('productRequestMessage', 'Enter your name, a valid phone number and the model you are looking for.', true); return;
  }
  if (button) { button.disabled = true; button.textContent = 'Sending...'; }
  try {
    const { error } = await supabaseClient.from('product_requests').insert(payload);
    if (error) throw error;
    form.reset(); setMessage('productRequestMessage', 'Your product request has been sent successfully. Gemmestores will review it.');
  } catch (error) {
    console.error('Product request error:', error);
    setMessage('productRequestMessage', error.message || 'Unable to save the request. Make sure the supplied product-features SQL has been run in Supabase.', true);
  } finally { if (button) { button.disabled = false; button.textContent = 'Send Product Request'; } }
}

// ---------------------------------------------------------
// ACCOUNT PROFILE / TRANSACTIONS / CONTACT
// ---------------------------------------------------------
async function showAccount() {
  showSection('account');
  if (byId('accountMenuGrid')) byId('accountMenuGrid').style.display = 'grid';
  ['accountProfilePanel','accountTransactionsPanel','accountContactPanel'].forEach(id => { if (byId(id)) byId(id).style.display = 'none'; });
  const targets = ['profileFullName','profileEmail','profilePhone','accountUserId','accountFullName','accountEmail'];
  targets.forEach(id => { if (byId(id)) byId(id).textContent = 'Loading...'; });
  const user = await getCurrentUser();
  if (!user) { showLogin(); return; }
  const fullName = normalizeText(user.user_metadata?.full_name || user.user_metadata?.name || 'Name not provided');
  const email = user.email || 'Email unavailable';
  const phone = normalizeText(user.user_metadata?.phone || '');
  if (byId('profileFullName')) byId('profileFullName').textContent = fullName;
  if (byId('profileEmail')) byId('profileEmail').textContent = email;
  if (byId('profilePhone')) byId('profilePhone').textContent = phone || 'Not added';
  if (byId('accountUserId')) byId('accountUserId').textContent = user.id;
  if (byId('accountFullName')) byId('accountFullName').textContent = fullName;
  if (byId('accountEmail')) byId('accountEmail').textContent = email;
  if (byId('profilePhoneInput')) byId('profilePhoneInput').value = phone;
  if (byId('profilePhoneEditor')) byId('profilePhoneEditor').style.display = 'none';
  if (byId('editProfilePhoneButton')) {
    byId('editProfilePhoneButton').textContent = phone ? 'Change' : 'Add Phone Number';
    byId('editProfilePhoneButton').style.display = 'inline-flex';
  }
}

async function saveProfilePhone() {
  const input = byId('profilePhoneInput'); const phone = normalizeText(input?.value);
  const saveButton = byId('saveProfilePhoneButton');
  if (!phone || !/^\+?[0-9\s()-]{10,16}$/.test(phone)) { alert('Please enter a valid phone number.'); return; }
  const user = await getCurrentUser(); if (!user) { showLogin(); return; }
  if (saveButton) { saveButton.disabled = true; saveButton.textContent = 'Saving...'; }
  try {
    const { data, error } = await supabaseClient.auth.updateUser({ data: { phone } });
    if (error) throw error;
    const savedPhone = data.user?.user_metadata?.phone || phone;
    if (byId('profilePhone')) byId('profilePhone').textContent = savedPhone;
    if (byId('profilePhoneEditor')) byId('profilePhoneEditor').style.display = 'none';
    if (byId('editProfilePhoneButton')) { byId('editProfilePhoneButton').textContent = 'Change'; byId('editProfilePhoneButton').style.display = 'inline-flex'; }
    alert('Phone number saved to your account.');
  } catch (error) { console.error('Phone update error:', error); alert(error.message || 'Unable to save your phone number.'); }
  finally { if (saveButton) { saveButton.disabled = false; saveButton.textContent = 'Save'; } }
}

function editProfilePhone() {
  const current = byId('profilePhone')?.textContent || '';
  if (byId('profilePhoneInput')) byId('profilePhoneInput').value = current === 'Not added' ? '' : current;
  if (byId('profilePhoneEditor')) byId('profilePhoneEditor').style.display = 'block';
  if (byId('editProfilePhoneButton')) byId('editProfilePhoneButton').style.display = 'none';
  byId('profilePhoneInput')?.focus();
}

function cancelProfilePhone() {
  const current = byId('profilePhone')?.textContent || '';
  if (byId('profilePhoneInput')) byId('profilePhoneInput').value = current === 'Not added' ? '' : current;
  if (byId('profilePhoneEditor')) byId('profilePhoneEditor').style.display = 'none';
  if (byId('editProfilePhoneButton')) {
    byId('editProfilePhoneButton').textContent = current && current !== 'Not added' ? 'Change' : 'Add Phone Number';
    byId('editProfilePhoneButton').style.display = 'inline-flex';
  }
}

function openAccountPanel(panel) {
  ['accountProfilePanel','accountTransactionsPanel','accountContactPanel'].forEach(id => { if (byId(id)) byId(id).style.display = 'none'; });
  const map = { profile: 'accountProfilePanel', transactions: 'accountTransactionsPanel', contact: 'accountContactPanel' };
  if (byId('accountMenuGrid')) byId('accountMenuGrid').style.display = 'none';
  if (map[panel] && byId(map[panel])) byId(map[panel]).style.display = 'block';
  if (panel === 'transactions') loadAccountTransactions();
}
function closeAccountPanel() {
  ['accountProfilePanel','accountTransactionsPanel','accountContactPanel'].forEach(id => { if (byId(id)) byId(id).style.display = 'none'; });
  if (byId('accountMenuGrid')) byId('accountMenuGrid').style.display = 'grid';
}

async function loadAccountTransactions() {
  const container = byId('accountTransactionsList'); if (!container) return;
  container.innerHTML = '<p>Loading Phone Store order history...</p>';
  const user = await getCurrentUser(); if (!user) { container.textContent = 'Please log in to view your account history.'; return; }
  try {
    const { data, error } = await supabaseClient.from('phone_orders').select('tracking_id,items,total_amount,status,created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(50);
    if (error) throw error;
    if (!data?.length) { container.innerHTML = '<div class="account-empty-state"><div>🧾</div><h4>No Phone Store orders yet</h4><p>Your Phone Store orders will appear here. Wallet funding and withdrawals remain in My Wallet.</p></div>'; return; }
    container.replaceChildren();
    data.forEach(order => {
      const card = document.createElement('article'); card.className = 'account-transaction-card';
      const top = document.createElement('div'); top.className = 'account-transaction-head';
      const id = document.createElement('strong'); id.textContent = order.tracking_id || 'Phone Store order';
      const status = document.createElement('span'); status.textContent = order.status || 'Processing';
      top.append(id, status);
      const items = document.createElement('p'); items.textContent = (Array.isArray(order.items) ? order.items.map(formatOrderItemDescription).join(', ') : 'Phone Store purchase');
      const amount = document.createElement('strong'); amount.textContent = formatMoney(order.total_amount || 0);
      const date = document.createElement('small'); date.textContent = order.created_at ? new Date(order.created_at).toLocaleString('en-NG') : '';
      card.append(top, items, amount, date); container.appendChild(card);
    });
  } catch (error) { console.error('Account order history error:', error); container.textContent = 'Unable to load Phone Store order history.'; }
}

function contactGemmestoresAdmin() {
  const msg = 'Hello Gemmestores Admin, I need assistance with my account.';
  safeOpen(`https://wa.me/${ADMIN_WHATSAPP_NUMBERS[0]}?text=${encodeURIComponent(msg)}`);
}
function contactGemmestoresAdminSecondary() {
  const msg = 'Hello Gemmestores Admin, I need assistance with my order or product enquiry.';
  safeOpen(`https://wa.me/${ADMIN_WHATSAPP_NUMBERS[1]}?text=${encodeURIComponent(msg)}`);
}
function showSettings() { showSection('settings'); initializePasswordToggles(); }
function showAccountSettings() { window.gemmestoresSettingsFromAccount = true; showSettings(); }
function returnFromSettings() {
  if (window.gemmestoresSettingsFromAccount) {
    window.gemmestoresSettingsFromAccount = false;
    showAccount();
  } else {
    showDashboard();
  }
}

async function changeAccountPassword() {
  const password = byId('newAccountPassword')?.value || '';
  const confirm = byId('confirmAccountPassword')?.value || '';
  const button = byId('changePasswordButton');
  if (password.length < 6) { setMessage('passwordChangeMessage', 'Your password must contain at least 6 characters.', true); return; }
  if (password !== confirm) { setMessage('passwordChangeMessage', 'The passwords do not match. Please try again.', true); return; }
  const user = await getCurrentUser(); if (!user) { setMessage('passwordChangeMessage', 'Please log in before changing your password.', true); return; }
  if (button) { button.disabled = true; button.textContent = 'Updating Password...'; }
  try {
    const { error } = await supabaseClient.auth.updateUser({ password }); if (error) throw error;
    byId('newAccountPassword').value = ''; byId('confirmAccountPassword').value = '';
    setMessage('passwordChangeMessage', 'Password changed successfully.');
  } catch (error) { console.error('Password change error:', error); setMessage('passwordChangeMessage', error.message || 'Unable to change your password.', true); }
  finally { if (button) { button.disabled = false; button.textContent = 'Change Password'; } }
}

async function loadNotificationPreferences() {
  const user = await getCurrentUser();
  if (!user) { setMessage('notificationPreferencesMessage', 'Please log in to manage your preferences.', true); return; }
  try {
    const { data, error } = await supabaseClient.from('notification_preferences').select('order_updates,account_alerts,promotions').eq('user_id', user.id).maybeSingle();
    if (error) throw error;
    if (byId('notifyOrderUpdates')) byId('notifyOrderUpdates').checked = data ? Boolean(data.order_updates) : true;
    if (byId('notifyAccountAlerts')) byId('notifyAccountAlerts').checked = data ? Boolean(data.account_alerts) : true;
    if (byId('notifyPromotions')) byId('notifyPromotions').checked = data ? Boolean(data.promotions) : false;
    setMessage('notificationPreferencesMessage', '');
  } catch (error) { console.error('Notification preferences load error:', error); setMessage('notificationPreferencesMessage', 'Unable to load preferences. Check the notification_preferences table and policies.', true); }
}

async function saveNotificationPreferences() {
  const user = await getCurrentUser(); if (!user) { setMessage('notificationPreferencesMessage', 'Please log in before saving your preferences.', true); return; }
  const button = byId('saveNotificationPreferencesButton');
  if (button) { button.disabled = true; button.textContent = 'Saving Preferences...'; }
  try {
    const payload = {
      user_id: user.id,
      order_updates: Boolean(byId('notifyOrderUpdates')?.checked),
      account_alerts: Boolean(byId('notifyAccountAlerts')?.checked),
      promotions: Boolean(byId('notifyPromotions')?.checked),
      updated_at: new Date().toISOString()
    };
    const { error } = await supabaseClient.from('notification_preferences').upsert(payload, { onConflict: 'user_id' });
    if (error) throw error;
    setMessage('notificationPreferencesMessage', 'Your notification preferences have been saved.');
  } catch (error) { console.error('Notification preferences save error:', error); setMessage('notificationPreferencesMessage', error.message || 'Unable to save preferences.', true); }
  finally { if (button) { button.disabled = false; button.textContent = 'Save Notification Preferences'; } }
}

// ---------------------------------------------------------
// ADMIN PORTAL FUNCTIONS — same five statuses as customer tracking
// ---------------------------------------------------------
async function adminLogin() {
  try {
    const email = prompt('Enter Admin Email:'); if (!email) return;
    const password = prompt('Enter Admin Password:'); if (!password) return;
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email: normalizeText(email), password });
    if (error) throw error;
    const user = data.user; if (!user) throw new Error('Unable to identify the logged-in user.');
    const { data: admin, error: adminError } = await supabaseClient.from('admin_users').select('id,role').eq('id', user.id).eq('role', 'admin').maybeSingle();
    if (adminError) throw adminError;
    if (!admin) { await supabaseClient.auth.signOut(); alert('Access denied. This account is not an Admin.'); return; }
    if (byId('adminLoginPage')) byId('adminLoginPage').style.display = 'none';
    if (byId('adminDashboard')) byId('adminDashboard').style.display = 'block';
    await loadPhoneOrders();
    await loadProductRequests();
  } catch (error) { console.error('Admin login error:', error); alert(error.message || 'Admin login failed.'); }
}

async function resetAdminPassword() {
  const email = prompt('Enter the Admin email address:'); if (!email) return;
  try {
    const { error } = await supabaseClient.auth.resetPasswordForEmail(normalizeText(email), { redirectTo: window.location.origin });
    if (error) throw error;
    alert('Password reset email sent.');
  } catch (error) { console.error('Admin reset error:', error); alert(error.message || 'Unable to send password reset email.'); }
}

async function adminLogout() {
  try {
    const { error } = await supabaseClient.auth.signOut(); if (error) throw error;
    if (byId('adminDashboard')) byId('adminDashboard').style.display = 'none';
    if (byId('adminLoginPage')) byId('adminLoginPage').style.display = 'block';
    if (byId('phoneOrdersSection')) byId('phoneOrdersSection').style.display = 'none';
  } catch (error) { console.error('Admin logout error:', error); alert('Unable to logout.'); }
}

async function checkAdminAccess(showAlert = true) {
  const user = await getCurrentUser();
  if (!user) { if (showAlert) alert('Please log in as Admin.'); return false; }
  const { data, error } = await supabaseClient.from('admin_users').select('role').eq('id', user.id).eq('role', 'admin').maybeSingle();
  if (error || !data) { if (showAlert) alert(error?.message || 'Access denied. Admin account required.'); return false; }
  return true;
}

async function loadPhoneOrders() {
  if (!(await checkAdminAccess(false))) { console.warn('Admin access is required to load phone orders.'); return; }
  const list = byId('phoneOrdersList'); const section = byId('phoneOrdersSection');
  if (!list) return;
  if (section) section.style.display = 'block';
  list.textContent = 'Loading orders...';
  try {
    const { data, error } = await supabaseClient.from('phone_orders').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    lastLoadedOrders = data || [];
    if (!data?.length) { list.textContent = 'No phone orders found.'; return; }
    list.replaceChildren();
    data.forEach(order => {
      const card = document.createElement('article'); card.className = 'admin-order-card';
      const header = document.createElement('div'); header.className = 'admin-order-header';
      const title = document.createElement('h3'); title.textContent = `Order #${order.id}`;
      const statusBadge = document.createElement('span'); statusBadge.textContent = order.status || 'Processing';
      header.append(title, statusBadge);
      const details = document.createElement('div');
      const rows = [
        ['Tracking ID', order.tracking_id], ['Customer', order.customer_name], ['Phone', order.customer_phone],
        ['Address', order.delivery_address], ['Items', Array.isArray(order.items) ? order.items.map(formatOrderItemDescription).join(', ') : 'Phone order'],
        ['Total', formatMoney(order.total_amount || 0)]
      ];
      rows.forEach(([label, value]) => { const p = document.createElement('p'); const strong = document.createElement('strong'); strong.textContent = `${label}: `; p.append(strong, document.createTextNode(String(value || 'N/A'))); details.appendChild(p); });
      const label = document.createElement('label'); label.textContent = 'Update status';
      const select = document.createElement('select'); select.className = 'admin-status-select'; select.dataset.orderId = String(order.id);
      ORDER_STATUSES.forEach(value => { const option = document.createElement('option'); option.value = value; option.textContent = value; option.selected = (order.status || 'Processing') === value; select.appendChild(option); });
      const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Update Status'; button.addEventListener('click', () => updatePhoneOrderStatus(order.id, button));
      card.append(header, details, label, select, button); list.appendChild(card);
    });
  } catch (error) { console.error('Load orders error:', error); list.textContent = error.message || 'Unable to load phone orders.'; }
}

async function updatePhoneOrderStatus(orderId, button) {
  const allowed = await checkAdminAccess(); if (!allowed) return;
  const card = button?.closest('.admin-order-card'); const select = card?.querySelector('.admin-status-select');
  if (!select || !ORDER_STATUSES.includes(select.value)) { alert('Select a valid order status.'); return; }
  if (button) { button.disabled = true; button.textContent = 'Updating...'; }
  try {
    const { data: updatedOrder, error } = await supabaseClient.from('phone_orders').update({ status: select.value }).eq('id', orderId).select('id,status').maybeSingle();
    if (error) throw error;
    if (!updatedOrder) throw new Error('No order was updated. Check the Admin permissions and order ID.');
    alert(`Order status updated to ${select.value}. Customer tracking uses the same status.`);
    await loadPhoneOrders();
  } catch (error) { console.error('Status update error:', error); alert(error.message || 'Unable to update order status.'); if (button) { button.disabled = false; button.textContent = 'Update Status'; } }
}

// Admin product-request queue (used when the separate Admin Portal has these containers).
async function loadProductRequests() {
  if (!(await checkAdminAccess(false))) return;
  const container = byId('productRequestsList');
  if (!container) return;
  container.textContent = 'Loading product requests...';
  try {
    const { data, error } = await supabaseClient.from('product_requests').select('*').order('created_at', { ascending: false }).limit(100);
    if (error) throw error;
    if (!data?.length) { container.textContent = 'No product requests found.'; return; }
    container.replaceChildren();
    data.forEach(request => {
      const card = document.createElement('article'); card.className = 'admin-order-card';
      const heading = document.createElement('h3'); heading.textContent = request.model_name || 'Product request';
      const details = document.createElement('p'); details.textContent = `${request.customer_name || 'Customer'} · ${request.customer_phone || 'No phone'} · ${request.preferred_specs || 'No specifications supplied'}`;
      const note = document.createElement('p'); note.textContent = request.customer_note || '';
      const status = document.createElement('select'); status.className = 'product-request-status'; status.dataset.requestId = String(request.id);
      ['Pending','Reviewed','Contacted','Closed'].forEach(value => { const option = document.createElement('option'); option.value = value; option.textContent = value; option.selected = (request.status || 'Pending') === value; status.appendChild(option); });
      const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Update Request'; button.addEventListener('click', () => updateProductRequestStatus(request.id, button));
      card.append(heading, details, note, status, button); container.appendChild(card);
    });
  } catch (error) { console.error('Product requests load error:', error); container.textContent = error.message || 'Unable to load product requests.'; }
}

async function updateProductRequestStatus(requestId, button) {
  if (!(await checkAdminAccess())) return;
  const card = button?.closest('.admin-order-card'); const select = card?.querySelector('.product-request-status');
  if (!select || !['Pending','Reviewed','Contacted','Closed'].includes(select.value)) return;
  button.disabled = true; button.textContent = 'Updating...';
  try {
    const { data, error } = await supabaseClient.from('product_requests').update({ status: select.value }).eq('id', requestId).select('id,status').maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('No product request was updated.');
    alert(`Product request updated to ${select.value}.`);
    await loadProductRequests();
  } catch (error) { console.error('Product request update error:', error); alert(error.message || 'Unable to update the request.'); button.disabled = false; button.textContent = 'Update Request'; }
}

// ---------------------------------------------------------
// INITIALIZATION
// ---------------------------------------------------------
document.addEventListener('DOMContentLoaded', async () => {
  const notificationAccordion = byId('notificationSettingsAccordion');
  if (notificationAccordion && !notificationAccordion.dataset.loadBound) {
    notificationAccordion.dataset.loadBound = 'true';
    notificationAccordion.addEventListener('toggle', () => {
      if (notificationAccordion.open) loadNotificationPreferences();
    });
  }

  console.log('Gemmestores JavaScript loaded.');
  initializePasswordToggles();
  const paymintKycNumberInput = byId('paymintKycNumber');
  if (paymintKycNumberInput && !paymintKycNumberInput.dataset.numericBound) {
    paymintKycNumberInput.dataset.numericBound = 'true';
    paymintKycNumberInput.addEventListener('input', () => {
      paymintKycNumberInput.value = paymintKycNumberInput.value.replace(/\D/g, '').slice(0, 11);
    });
  }
  renderProductCatalog();
  showPhoneCategory('phones');
  updatePhoneCart();
  byId('productRequestForm')?.addEventListener('submit', submitProductRequest);
  const user = await getCurrentUser();
  await restoreLastPage(user);
  // Payment callbacks take priority and may redirect the customer to Wallet.
  await handleFlutterwaveReturn();
});

// Request a Live PayMint virtual account through the authenticated Supabase Edge Function.
// BVN/NIN is used only in this request: it is not written to browser storage or the Gemmestores database.
async function createPaymintVirtualAccount() {
  const typeInput = byId('paymintKycType');
  const numberInput = byId('paymintKycNumber');
  const consentInput = byId('paymintKycConsent');
  const button = byId('paymintCreateAccountButton');
  const message = byId('paymintAccountMessage');
  if (!typeInput || !numberInput || !consentInput || !button || !message) return;

  const kycType = String(typeInput.value || '').trim().toLowerCase();
  let kycNumber = String(numberInput.value || '').trim();

  if (!['bvn', 'nin'].includes(kycType)) {
    message.textContent = 'Please choose BVN or NIN.';
    typeInput.focus();
    return;
  }
  if (!/^\d{11}$/.test(kycNumber)) {
    message.textContent = 'Enter exactly 11 digits for your selected BVN or NIN.';
    numberInput.focus();
    return;
  }
  if (!consentInput.checked) {
    message.textContent = 'Please read the privacy notice and tick the consent box before continuing.';
    consentInput.focus();
    return;
  }

  const user = await getCurrentUser();
  if (!user) {
    numberInput.value = '';
    message.textContent = 'Please log in before requesting a virtual account.';
    showLogin();
    return;
  }

  button.disabled = true;
  button.textContent = 'Connecting securely to PayMint...';
  message.textContent = 'Your identity number is being sent securely for verification. Please do not tap again.';

  // Keep the identity number out of the DOM while the network request is in progress.
  numberInput.value = '';
  const requestBody = { action: 'create_virtual_account', consent: true };
  requestBody[kycType] = kycNumber;

  try {
    // Pass the signed-in customer's Supabase access token explicitly.
    // Without this header, paymint-api may mistake a customer request for a webhook.
    let { data: sessionData, error: sessionError } =
      await supabaseClient.auth.getSession();

    let accessToken = sessionData?.session?.access_token || null;

    // Recover an expired/missing session token before calling the Edge Function.
    if (!accessToken) {
      const refreshed = await supabaseClient.auth.refreshSession();
      accessToken = refreshed?.data?.session?.access_token || null;
      sessionError = refreshed?.error || sessionError;
    }

    if (!accessToken) {
      throw new Error(
        sessionError?.message ||
        'Your login session has expired. Please log in again.'
      );
    }

    const { data, error } = await supabaseClient.functions.invoke('paymint-api', {
      headers: {
        Authorization: `Bearer ${accessToken}`
      },
      body: requestBody
    });

    if (error) {
      let detail = error.message || 'The PayMint request could not be completed.';
      try {
        const response = error.context;
        if (response && typeof response.clone === 'function') {
          const payload = await response.clone().json();
          if (payload?.error) detail = String(payload.error);
        }
      } catch (_) { /* Keep the safe generic function error. */ }
      throw new Error(detail);
    }

    if (!data || data.error) {
      throw new Error(String(data?.error || 'PayMint did not return an account response.'));
    }

    if (data.pending) {
      message.textContent = data.message || 'Your virtual-account request is still being processed. Please do not submit another request.';
      await loadPaymintVirtualAccount();
      return;
    }

    if (data.success) {
      message.textContent = data.existing
        ? 'Your existing Live virtual account was found. Refreshing the account details...'
        : (data.message || 'PayMint confirmed your Live account request. Refreshing the account details...');
      await loadPaymintVirtualAccount();
      return;
    }

    message.textContent = data.message || 'PayMint received the request but has not confirmed an account yet.';
  } catch (error) {
    const detail = String(error?.message || 'The request could not be completed.');
    if (/phone number/i.test(detail)) {
      message.textContent = 'Please add a valid Nigerian phone number to your Gemmestores profile, save it, and request the Live account again.';
    } else if (/full name/i.test(detail)) {
      message.textContent = 'Please make sure your full name is saved in your Gemmestores profile before requesting the Live account.';
    } else if (/enter either your BVN or your NIN|BVN or NIN must contain/i.test(detail)) {
      message.textContent = 'PayMint did not accept the identity details. Please check that you selected one identity type and entered exactly 11 digits.';
    } else {
      message.textContent = detail;
    }
  } finally {
    // Remove the identity value from the temporary request object and browser field.
    delete requestBody.bvn;
    delete requestBody.nin;
    kycNumber = '';
    numberInput.value = '';
    button.disabled = false;
    button.textContent = 'Create Live Virtual Account';
  }
}

// Expose functions used by HTML onclick/oninput handlers.
window.showSignup = showSignup;
window.showLogin = showLogin;
window.showDashboard = showDashboard;
window.showWallet = showWallet;
window.createPaymintVirtualAccount = createPaymintVirtualAccount;
window.openPaymintAccountRequest = openPaymintAccountRequest;
window.topUpWallet = topUpWallet;
window.submitWalletTopUp = submitWalletTopUp;
window.closeWalletFundModal = closeWalletFundModal;
window.showWalletWithdrawal = showWalletWithdrawal;
window.showWithdrawSection = showWithdrawSection;
window.closeWithdrawSection = closeWithdrawSection;
window.showBuyData = showBuyData;
window.showBuyAirtime = showBuyAirtime;
window.showBills = showBills;
window.showBillForm = showBillForm;
window.verifyElectricityMeter = verifyElectricityMeter;
window.payBill = payBill;
window.showPhones = showPhones;
window.showSection = showSection;
window.showPhoneCategory = showPhoneCategory;
window.searchProducts = searchProducts;
window.checkoutCart = checkoutCart;
window.trackOrder = trackOrder;
window.logoutUser = logoutUser;
window.contactGemmestoresAdmin = contactGemmestoresAdmin;
window.contactGemmestoresAdminSecondary = contactGemmestoresAdminSecondary;

// Keep the WhatsApp Channel URL available to other UI elements.
window.GEMMESTORES_WHATSAPP_CHANNEL = WHATSAPP_CHANNEL_URL;

